"""
Smart Food Recommendation App
Main entry point - Quản lý chuyển tab và khởi tạo ứng dụng
"""
import customtkinter as ctk
from tabs.recommend_tab import RecommendTab
from tabs.menu_tab import MenuTab
from tabs.profile_tab import ProfileTab
from utils.theme import COLORS, FONTS, APP_CONFIG


class SmartFoodApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Cấu hình cửa sổ - kích thước điện thoại
        self.title(APP_CONFIG["title"])
        self.geometry(f"{APP_CONFIG['width']}x{APP_CONFIG['height']}")
        self.resizable(False, False)
        self.configure(fg_color=COLORS["bg_white"])

        # Set light mode
        ctk.set_appearance_mode("light")

        # Tab hiện tại
        self.current_tab = "recommend"

        # Cache các tab đã tạo (tránh tạo lại mỗi lần chuyển)
        self._tab_cache = {}

        # Tạo layout chính
        self.create_layout()

        # Tạo sẵn tất cả tab và ẩn đi, chỉ hiện tab mặc định
        self._init_all_tabs()
        self.show_tab("recommend")

    def create_layout(self):
        """Tạo layout: content area + bottom navigation"""
        # Container chính
        self.main_container = ctk.CTkFrame(
            self,
            fg_color=COLORS["bg_white"],
            corner_radius=0
        )
        self.main_container.pack(fill="both", expand=True)

        # Content area (nơi hiển thị nội dung tab)
        self.content_frame = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS["bg_white"],
            corner_radius=0
        )
        self.content_frame.pack(fill="both", expand=True, side="top")

        # Bottom navigation bar
        self.create_bottom_nav()

    def create_bottom_nav(self):
        """Tạo thanh điều hướng dưới cùng"""
        self.bottom_nav = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS["green_light"],
            height=50,
            corner_radius=0
        )
        self.bottom_nav.pack(fill="x", side="bottom")
        self.bottom_nav.pack_propagate(False)

        # Đường viền trên
        top_border = ctk.CTkFrame(
            self.bottom_nav,
            fg_color=COLORS["green_primary"],
            height=2,
            corner_radius=0
        )
        top_border.pack(fill="x", side="top")

        # Container cho các nút
        nav_container = ctk.CTkFrame(
            self.bottom_nav,
            fg_color="transparent"
        )
        nav_container.pack(fill="both", expand=True, padx=10, pady=5)

        # Cấu hình grid - 3 cột bằng nhau
        nav_container.grid_columnconfigure(0, weight=1)
        nav_container.grid_columnconfigure(1, weight=1)
        nav_container.grid_columnconfigure(2, weight=1)

        # Tạo 3 nút tab
        self.nav_buttons = {}

        # Tab 1: Gợi ý món
        self.nav_buttons["recommend"] = self.create_nav_button(
            nav_container, "🍽️", "recommend", 0
        )

        # Tab 2: Danh sách món
        self.nav_buttons["menu"] = self.create_nav_button(
            nav_container, "📋", "menu", 1
        )

        # Tab 3: Profile
        self.nav_buttons["profile"] = self.create_nav_button(
            nav_container, "👤", "profile", 2
        )

    def create_nav_button(self, parent, icon, tab_name, column):
        """Tạo một nút điều hướng"""
        btn_frame = ctk.CTkFrame(
            parent,
            fg_color="transparent",
            cursor="hand2"
        )
        btn_frame.grid(row=0, column=column, sticky="nsew", padx=5)

        # Icon
        icon_label = ctk.CTkLabel(
            btn_frame,
            text=icon,
            font=("Segoe UI Emoji", 22),
            text_color=COLORS["text_gray"]
        )
        icon_label.pack(pady=(8, 0))

        # Bind click event cho cả frame và các label con
        for widget in [btn_frame, icon_label]:
            widget.bind("<Button-1>", lambda e, t=tab_name: self.show_tab(t))

        return {
            "frame": btn_frame,
            "icon": icon_label
        }

    def _init_all_tabs(self):
        """Tạo sẵn tất cả tab một lần duy nhất khi khởi động"""
        self._tab_cache["recommend"] = RecommendTab(self.content_frame)
        self._tab_cache["menu"]      = MenuTab(self.content_frame)
        self._tab_cache["profile"]   = ProfileTab(self.content_frame)
        # Ẩn tất cả, show_tab sẽ hiện đúng tab
        for tab in self._tab_cache.values():
            tab.pack_forget()

    def show_tab(self, tab_name):
        """Hiển thị tab được chọn (hide/show, không destroy/recreate)"""
        # Ẩn tab đang hiển thị
        if self.current_tab in self._tab_cache:
            self._tab_cache[self.current_tab].pack_forget()

        # Cập nhật trạng thái active của nav buttons
        self.update_nav_state(tab_name)

        # Hiện tab mới
        self._tab_cache[tab_name].pack(fill="both", expand=True)
        self.current_tab = tab_name

    def update_nav_state(self, active_tab):
        """Cập nhật màu của nav buttons - tab active sẽ có màu xanh"""
        for tab_name, button_widgets in self.nav_buttons.items():
            if tab_name == active_tab:
                # Tab active - màu xanh đậm
                button_widgets["icon"].configure(text_color=COLORS["green_primary"])
            else:
                # Tab không active - màu xám
                button_widgets["icon"].configure(text_color=COLORS["text_gray"])


if __name__ == "__main__":
    app = SmartFoodApp()
    app.mainloop()
