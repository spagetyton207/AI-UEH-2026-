# backend/main.py
"""
Smart Food Recommendation – Pipeline v6
========================================
Pipeline:
1.  Lấy thời tiết hiện tại (Open-Meteo).
2.  Chạy fuzzy T1 → (weather_sev, meal_score, cal_score, price_tier).
3.  Chạy fuzzy T2 → ideal_distance (km).
4.  Hard-filter food.csv theo:
       - Ngân sách     (đảm bảo trong khả năng chi trả, có cơ chế nới).
       - Sức khoẻ      (Diet KHÔNG nhận greasy + cao calo; Bulking ưu tiên protein).
       - Meal_size     (đói thấp + diet không cho hearty/full_meal lớn).
5.  Tính routing distance thật bằng OSRM (hoặc Haversine × 1.3 fallback).
6.  Composite scoring 6 chiều (mỗi chiều ∈ [0,1], thấp hơn = tốt hơn):
       - distance_fit    : sai lệch so với ideal_distance
       - meal_fit        : meal_size có khớp meal_score không
       - cal_fit         : calories_estimate có khớp cal_score không
       - nutrition_fit   : nutrition_profile có phù hợp với mục tiêu sức khoẻ
       - budget_fit      : giá so với ngân sách (và so với price_tier)
       - weather_fit     : món có phù hợp với thời tiết (canh nóng/đồ mát/...)
7.  Diversification (MMR-lite): TOP 3 phải KHÁC nhau về food_name & cuisine.
8.  Convert match → %, build reasons giải thích, trả output cho UI.

LƯU Ý quan trọng:
- Output keys giữ NGUYÊN tương thích với result_screen / food_detail_screen / map_screen
  (food_name, shop_name, cuisine, cuisine_country, flag, dot_colors, price,
   price_vnd, kcal, match, route_km, actual_route_km, lat, lon, image_url,
   meal_size, meal_form, nutrition_profile, taste_vector, reasons, tags,
   ingredients, cost_score, score_breakdown).
- Trả thêm fuzzy_outputs (meal_score, cal_score, expected_meal_size, expected_cal).
"""
import os
import math
import pandas as pd
import numpy as np

from backend.utils import (
    get_weather_data, get_routing_distances, get_user_location, cosine_sim,
)
from backend.fuzzy_engine import build_fuzzy_systems, total_rule_count
from backend.cuisine_vectors import (
    get_food_vector, cuisine_display_name, map_cuisine_code,
)


# ════════════════════════════════════════════════════════════════════
#  KHỞI TẠO FUZZY + LOAD CSV (1 LẦN)
# ════════════════════════════════════════════════════════════════════
_sim1, _sim2 = build_fuzzy_systems()

# Warm-up: chạy 1 lần để JIT compile membership functions
try:
    _sim1.input['temperature'] = 32.0
    _sim1.input['rainfall']    = 0.0
    _sim1.input['time']        = 30.0
    _sim1.input['hunger']      = 5.0
    _sim1.input['health']      = 5.0
    _sim1.input['budget']      = 100.0
    _sim1.compute()
    _sim2.input['wsev_in']   = float(_sim1.output['weather_severity'])
    _sim2.input['time_in']   = 30.0
    _sim2.input['hunger_in'] = 5.0
    _sim2.compute()
except Exception as e:
    print(f'[Fuzzy Warmup Error] {e}')


# ── Load & chuẩn hoá CSV ──────────────────────────────────────────
_CSV = os.path.join(os.path.dirname(__file__), 'food.csv')
try:
    FOOD_DF = pd.read_csv(_CSV, encoding='utf-8', on_bad_lines='skip')
except UnicodeDecodeError:
    FOOD_DF = pd.read_csv(_CSV, encoding='latin-1', on_bad_lines='skip')

# Strip whitespace + lowercase một số cột (DỮ LIỆU CÓ 'chn ' với space → fix)
for c in ('cuisine', 'meal_size', 'meal_form', 'nutrition_profile',
          'calories_estimate', 'price_range'):
    if c in FOOD_DF.columns:
        FOOD_DF[c] = FOOD_DF[c].astype(str).str.strip().str.lower()

# Chuẩn hoá calories category
_CAL_MAP = {'low': 'low', 'medium': 'medium', 'high': 'high', 'normal': 'medium'}
FOOD_DF['cal_cat'] = FOOD_DF['calories_estimate'].map(_CAL_MAP).fillna('medium')

# Đảm bảo có cột price_vnd
if 'price_vnd' not in FOOD_DF.columns and 'price' in FOOD_DF.columns:
    FOOD_DF['price_vnd'] = FOOD_DF['price']

# Numeric ép kiểu
for c in ('price_vnd', 'lat', 'lon', 'do_cay', 'do_ngot', 'do_man'):
    if c in FOOD_DF.columns:
        FOOD_DF[c] = pd.to_numeric(FOOD_DF[c], errors='coerce')

FOOD_DF = FOOD_DF.dropna(subset=['lat', 'lon', 'price_vnd']).reset_index(drop=True)


# ════════════════════════════════════════════════════════════════════
#  HELPERS – CHUYỂN ĐỔI INPUT
# ════════════════════════════════════════════════════════════════════
def _health_to_float(goal: str) -> float:
    """Convert health goal string → float on 0–10 scale.
       0 = bulking, 5 = balanced, 10 = diet."""
    g = str(goal).strip().lower()
    table = {
        'diet': 9.0, 'ăn kiêng': 9.0, 'an kieng': 9.0,
        'cân bằng': 5.0, 'can bang': 5.0, 'balanced': 5.0, 'normal': 5.0,
        'bulking': 1.0, 'tăng cơ': 1.0, 'tang co': 1.0,
    }
    return table.get(g, 5.0)


# ════════════════════════════════════════════════════════════════════
#  HELPERS – CHUYỂN ĐỔI OUTPUT FUZZY → CATEGORY MONG ĐỢI
# ════════════════════════════════════════════════════════════════════
def _meal_score_to_size(meal_score: float) -> str:
    """meal_score (0–10) → category meal_size mong đợi."""
    if meal_score < 2.8:  return 'snack'
    if meal_score < 5.5:  return 'light_meal'
    return 'full_meal'


def _cal_score_to_cat(cal_score: float) -> str:
    if cal_score < 3.8:  return 'low'
    if cal_score < 6.5:  return 'medium'
    return 'high'


def _price_tier_to_cat(price_tier: float) -> str:
    if price_tier < 3.8:  return 'cheap'
    if price_tier < 6.5:  return 'standard'
    return 'premium'


# ════════════════════════════════════════════════════════════════════
#  PENALTY FUNCTIONS – mỗi cái trả về [0,1], thấp hơn = tốt hơn
# ════════════════════════════════════════════════════════════════════
def _nutrition_penalty(nutrition: str, health_float: float) -> float:
    """
    Penalty 0–1 dựa trên (nutrition_profile, mục tiêu sức khoẻ).
    Penalty rất MẠNH khi không phù hợp để hệ thống thực sự lọc bỏ.
    """
    n = str(nutrition).lower().strip()

    if health_float >= 7.0:   # ===== DIET =====
        return {
            'greasy':       0.95,  # gần như loại bỏ
            'sweet':        0.75,
            'high_protein': 0.25,
            'normal':       0.35,
            'vegetarian':   0.05,
        }.get(n, 0.45)

    elif health_float <= 3.0:  # ===== BULKING =====
        return {
            'high_protein': 0.05,
            'greasy':       0.25,
            'normal':       0.30,
            'vegetarian':   0.70,  # bulking khó đủ đạm với chay
            'sweet':        0.80,
        }.get(n, 0.40)

    else:                      # ===== BALANCED =====
        return {
            'high_protein': 0.15,
            'normal':       0.10,
            'vegetarian':   0.20,
            'greasy':       0.55,
            'sweet':        0.45,
        }.get(n, 0.30)


def _meal_size_match(meal_size: str, expected: str) -> float:
    """Penalty cho meal_size mismatch (3 cấp: snack < light_meal < full_meal)."""
    order = ['snack', 'light_meal', 'full_meal']
    try:
        d = abs(order.index(meal_size) - order.index(expected))
        return {0: 0.0, 1: 0.50, 2: 0.95}[d]  # mismatch 2 cấp → gần như loại
    except ValueError:
        return 0.50


def _cal_match(cal_cat: str, expected_cat: str) -> float:
    order = ['low', 'medium', 'high']
    try:
        d = abs(order.index(cal_cat) - order.index(expected_cat))
        return {0: 0.0, 1: 0.40, 2: 0.85}[d]
    except ValueError:
        return 0.40


def _price_tier_match(price_vnd: float, expected_tier: str) -> float:
    """Phạt nếu giá nằm xa khỏi tier mong đợi.
       Tier (theo TPHCM): cheap ≤ 50k, standard 40–120k, premium ≥ 100k."""
    p = float(price_vnd)
    if expected_tier == 'cheap':
        if p <= 45000:   return 0.0
        if p <= 70000:   return 0.25
        if p <= 100000:  return 0.55
        return 0.80
    if expected_tier == 'standard':
        if 40000 <= p <= 130000:  return 0.0
        if p < 40000:             return 0.15
        if p <= 200000:           return 0.30
        return 0.65
    # premium
    if p >= 90000:   return 0.0
    if p >= 50000:   return 0.25
    return 0.55


def _distance_fit(km: float, ideal: float) -> float:
    """Mượt: 0 nếu bằng ideal, tăng dần khi xa hơn (và nhẹ hơn khi gần hơn)."""
    if ideal <= 0.1:
        return min(1.0, km / 5.0)
    if km <= ideal:
        # nhẹ hơn ideal vẫn ổn (gần càng tốt)
        return 0.5 * (1.0 - km / ideal)         # 0 → 0.5
    # xa hơn ideal: phạt tuyến tính, cap ở 1
    overflow = (km - ideal) / ideal
    return min(1.0, 0.3 + overflow * 0.5)


def _budget_penalty(price: float, budget: float) -> float:
    """Phạt nếu vượt budget hoặc gần chạm trần. Rẻ hơn → tốt nhưng không cộng điểm vô tận."""
    if budget <= 0:
        return 1.0
    ratio = price / budget
    if ratio <= 0.5:   return 0.0          # rất hợp lý
    if ratio <= 0.8:   return 0.15
    if ratio <= 1.0:   return 0.35
    if ratio <= 1.2:   return 0.65
    return 0.95                            # vượt 20% → gần như loại


def _weather_penalty(meal_form: str, nutrition: str,
                     temp: float, rain: float) -> float:
    """Penalty nhẹ theo thời tiết để gợi ý phù hợp khẩu vị mùa."""
    mf = str(meal_form).lower()
    nu = str(nutrition).lower()
    pen = 0.0

    # Mưa lớn → ưu tiên đồ nước/canh nóng
    if rain >= 5:
        if mf == 'liquid':       pen -= 0.10
        elif mf == 'finger':     pen += 0.20
    # Nóng (≥34) → tránh đồ chiên rán đậm vị
    if temp >= 34:
        if nu == 'greasy':       pen += 0.25
        if mf == 'liquid' and nu != 'greasy':
            pen -= 0.05          # canh thanh / nước thanh đạm
    # Mát (<24) → đồ ấm / món nước nhẹ tốt hơn
    if temp < 24:
        if mf == 'liquid':       pen -= 0.08
    return max(0.0, min(1.0, 0.30 + pen))


# ════════════════════════════════════════════════════════════════════
#  HELPERS – HIỂN THỊ
# ════════════════════════════════════════════════════════════════════
def _cuisine_flag(code: str) -> str:
    flags = {
        'vie': '🇻🇳', 'kh': '🇻🇳',
        'jpn': '🇯🇵', 'kor': '🇰🇷',
        'us':  '🇺🇸', 'tha': '🇹🇭',
        'chn': '🇨🇳', 'veg': '🥗',
        'ind': '🇮🇳',
    }
    return flags.get(str(code).strip().lower(), '🍽')


def _cuisine_colors(code: str) -> list[str]:
    colors = {
        'vie': ['#E53E3E', '#F5C842'], 'kh': ['#E53E3E', '#F5C842'],
        'jpn': ['#E53E3E', '#FFFFFF'], 'kor': ['#4A90D9', '#E53E3E'],
        'us':  ['#4A90D9', '#F5C842'], 'tha': ['#4A90D9', '#E53E3E'],
        'chn': ['#E53E3E', '#F5C842'],
        'veg': ['#4CAF85', '#A8D8A8'],
    }
    return colors.get(str(code).strip().lower(), ['#4CAF85', '#1A3A2A'])


def _estimate_kcal(meal_size: str, cal_cat: str, nutrition: str) -> int:
    """
    Ước tính kcal tốt hơn: kết hợp meal_size × cal_cat × nutrition.
    Bảng giá trị thực tế cho ẩm thực Việt/Á:
    """
    base_table = {
        ('snack',      'low'):    180,
        ('snack',      'medium'): 280,
        ('snack',      'high'):   420,
        ('light_meal', 'low'):    320,
        ('light_meal', 'medium'): 450,
        ('light_meal', 'high'):   600,
        ('full_meal',  'low'):    480,
        ('full_meal',  'medium'): 650,
        ('full_meal',  'high'):   880,
    }
    base = base_table.get((meal_size, cal_cat), 550)
    # Tinh chỉnh nhẹ theo nutrition
    if nutrition == 'greasy':       base = int(base * 1.10)
    elif nutrition == 'vegetarian': base = int(base * 0.85)
    elif nutrition == 'sweet':      base = int(base * 0.95)
    return base


def _build_reasons(food: dict, weather: dict, ideal_dist: float,
                   meal_score: float, cal_score: float,
                   health_float: float, budget_vnd: float,
                   score_breakdown: dict) -> list[str]:
    """Sinh 3–4 lý do giải thích, ưu tiên những thành phần đóng góp ÍT (tốt) nhất."""
    reasons = []
    temp = weather.get('temperature', 32)
    rain = weather.get('rainfall', 0)
    km   = float(food.get('route_km', 0))
    price = int(food.get('price_vnd', 0))
    nut   = str(food.get('nutrition_profile', '')).lower()
    ms    = str(food.get('meal_size', '')).lower()
    mf    = str(food.get('meal_form', '')).lower()

    # 1. Thời tiết
    if rain >= 5:
        if mf == 'liquid':
            reasons.append(f"🌧 Mưa → món nước ấm bụng")
        else:
            reasons.append(f"🌧 Mưa → quán cách {km:.1f}km, đỡ ướt")
    elif temp >= 34:
        if mf == 'liquid':
            reasons.append(f"☀ Nóng {temp:.0f}°C → món nước thanh nhiệt")
        elif nut == 'greasy':
            reasons.append(f"☀ Nóng {temp:.0f}°C nhưng vẫn hợp khẩu vị")
        else:
            reasons.append(f"☀ Nóng {temp:.0f}°C → món nhẹ, dễ ăn")
    elif temp < 24:
        reasons.append(f"❄ Mát {temp:.0f}°C → ấm bụng")
    else:
        reasons.append(f"⛅ {temp:.0f}°C dễ chịu")

    # 2. Mục tiêu sức khoẻ (cá nhân hoá theo health)
    if health_float >= 7:    # diet
        if nut == 'vegetarian':
            reasons.append("🥗 Thanh đạm, đúng chế độ Diet")
        elif nut == 'high_protein':
            reasons.append("💪 Giàu đạm, ít chất béo")
        elif nut == 'normal':
            reasons.append("🍃 Cân bằng cho người ăn kiêng")
    elif health_float <= 3:  # bulking
        if nut == 'high_protein':
            reasons.append("💪 Nhiều đạm, hỗ trợ tăng cơ")
        elif nut == 'greasy':
            reasons.append("🔥 Đậm đà, bù năng lượng tốt")
        else:
            reasons.append("🍱 Đủ năng lượng cho Bulking")
    else:                    # balanced
        if nut == 'high_protein':
            reasons.append("🍱 Đủ đạm – cân bằng tốt")
        elif nut == 'vegetarian':
            reasons.append("🥗 Thanh đạm – ít gánh nặng")
        else:
            reasons.append("🍽 Vừa đủ – không thiếu không thừa")

    # 3. Giá
    if price <= budget_vnd * 0.5:
        reasons.append(f"💰 Tiết kiệm – chỉ {price:,}đ")
    elif price <= budget_vnd * 0.85:
        reasons.append(f"💰 Hợp ngân sách – {price:,}đ")
    elif price <= budget_vnd:
        reasons.append(f"💰 Sát ngân sách – {price:,}đ")
    else:
        reasons.append(f"💰 Hơi quá tay – {price:,}đ")

    # 4. Khoảng cách
    if km < 1.0:
        reasons.append(f"📍 Rất gần – chỉ {km:.1f}km")
    elif km <= max(ideal_dist, 0.5):
        reasons.append(f"📍 Trong tầm lý tưởng – {km:.1f}km")
    else:
        reasons.append(f"📍 Cách {km:.1f}km")

    return reasons[:4]


def _build_tags(row: pd.Series, cuisine_disp: str) -> list[str]:
    tags = [cuisine_disp]
    nut = str(row.get('nutrition_profile', '')).lower()
    ms  = str(row.get('meal_size', '')).lower()
    mf  = str(row.get('meal_form', '')).lower()
    if nut == 'vegetarian':   tags.append('Chay')
    if nut == 'high_protein': tags.append('Nhiều đạm')
    if nut == 'greasy':       tags.append('Đậm vị')
    if nut == 'sweet':        tags.append('Ngọt')
    if ms == 'snack':         tags.append('Ăn vặt')
    if ms == 'light_meal':    tags.append('Bữa nhẹ')
    if ms == 'full_meal':     tags.append('Bữa chính')
    if mf == 'liquid':        tags.append('Nước/canh')
    return tags[:5]


def _ingredients_for(food_name: str) -> list[str]:
    fn = str(food_name).lower()
    table = [
        ('phở',         ['Bánh phở', 'Nước dùng xương', 'Thịt bò/gà', 'Hành lá', 'Rau thơm', 'Chanh ớt']),
        ('bún bò',      ['Bún', 'Thịt bò', 'Chả', 'Mắm ruốc', 'Sả', 'Rau muống']),
        ('bún riêu',    ['Bún', 'Cua đồng', 'Cà chua', 'Đậu hũ', 'Huyết', 'Rau sống']),
        ('bún chả',     ['Bún', 'Chả lá lốt', 'Thịt nướng', 'Nước chấm', 'Rau thơm']),
        ('bún đậu',     ['Bún lá', 'Đậu hũ chiên', 'Chả cốm', 'Mắm tôm', 'Rau thơm']),
        ('bún thái',    ['Bún', 'Hải sản', 'Lá chanh', 'Riềng', 'Ớt thái', 'Sả']),
        ('bún',         ['Bún tươi', 'Nước dùng', 'Rau sống', 'Ớt', 'Chanh']),
        ('cơm tấm',     ['Cơm tấm', 'Sườn nướng', 'Bì', 'Chả', 'Nước mắm chua ngọt']),
        ('cơm trộn',    ['Cơm trắng', 'Thịt bò', 'Trứng', 'Kim chi', 'Rau củ', 'Sốt gochujang']),
        ('cơm',         ['Cơm trắng', 'Thức ăn mặn', 'Rau xào', 'Canh', 'Nước mắm']),
        ('mì cay',      ['Mì Hàn', 'Nước dùng cay', 'Hải sản', 'Rau', 'Phô mai']),
        ('mì trộn',     ['Mì', 'Thịt', 'Rau', 'Sốt mè', 'Hành phi']),
        ('mì sủi cảo',  ['Mì', 'Sủi cảo tôm thịt', 'Cải xanh', 'Hành lá']),
        ('mỳ ý', ['Mì spaghetti', 'Sốt bolognese', 'Phô mai parmesan', 'Húng quế']),
        ('mì ý', ['Mì spaghetti', 'Sốt bolognese', 'Phô mai parmesan', 'Húng quế']),
        ('mì',          ['Mì', 'Nước dùng', 'Thịt/hải sản', 'Hành phi', 'Gia vị']),
        ('bánh mì',     ['Ổ bánh mì', 'Patê', 'Thịt nguội', 'Dưa leo', 'Hành ngò']),
        ('bánh cuốn',   ['Bột gạo', 'Thịt băm', 'Nấm mèo', 'Hành phi', 'Nước chấm']),
        ('bánh canh',   ['Bánh canh', 'Nước dùng', 'Cua/giò heo', 'Hành lá']),
        ('pizza',       ['Đế bánh', 'Sốt cà chua', 'Phô mai mozzarella', 'Topping', 'Oregano']),
        ('gà rán',      ['Gà', 'Bột chiên giòn', 'Gia vị đặc trưng', 'Sốt chấm']),
        ('sushi',       ['Cơm cuộn', 'Cá sống', 'Rong biển', 'Wasabi', 'Gừng ngâm']),
        ('ramen',       ['Mì ramen', 'Nước dùng tonkotsu', 'Chashu', 'Trứng lòng đào', 'Nori']),
        ('pad thái',    ['Bún gạo', 'Tôm/gà', 'Giá đỗ', 'Lạc rang', 'Nước sốt thái']),
        ('lẩu',         ['Nước lẩu', 'Rau', 'Thịt/hải sản', 'Nấm', 'Bún/mì']),
        ('chè',         ['Đường', 'Đậu', 'Thạch', 'Nước cốt dừa', 'Đá bào']),
        ('xôi',         ['Nếp', 'Nhân (mặn/ngọt)', 'Lá dứa', 'Đậu xanh']),
        ('gỏi',         ['Rau', 'Tôm/thịt', 'Đậu phộng', 'Nước mắm chua ngọt', 'Húng quế']),
        ('súp',         ['Nước dùng', 'Thịt cua/gà', 'Trứng', 'Nấm', 'Hành ngò']),
        ('salad',       ['Rau xà lách', 'Cà chua', 'Dưa leo', 'Sốt salad', 'Hạt']),
        ('cuốn',        ['Bánh tráng', 'Tôm/thịt', 'Bún', 'Rau sống', 'Nước chấm']),
    ]
    for kw, items in table:
        if kw in fn:
            return items
    return ['Nguyên liệu tươi sạch', 'Gia vị đặc trưng']


def _match_pct_by_rank(rank: int, total: int = 3) -> int:
    """Match% theo THỨ TỰ HIỂN THỊ (rank=0 là top pick).
       Đảm bảo top 1 > top 2 > top 3, không bao giờ bị đảo."""
    # Mapping cố định để spread mượt và đẹp
    table = {0: 95, 1: 82, 2: 70}
    return table.get(rank, 60)


def _adjust_match_by_composite(base_pct: int, cost: float,
                                best_cost: float, worst_cost: float) -> int:
    """Tinh chỉnh ±3% dựa trên độ tốt của composite so với top1."""
    if worst_cost - best_cost < 1e-6:
        return base_pct
    rel = (cost - best_cost) / (worst_cost - best_cost)   # 0=như top1, 1=như tệ nhất
    adj = -3 * rel  # tốt → +0, tệ hơn top1 → tới -3
    return int(round(max(40, min(99, base_pct + adj))))


# ════════════════════════════════════════════════════════════════════
#  DIVERSIFICATION (MMR-LITE)
# ════════════════════════════════════════════════════════════════════
def _diversify_top_n(scored_df: pd.DataFrame, n: int = 3,
                     lambda_diverse: float = 0.45) -> pd.DataFrame:
    """
    Chọn n món có cost thấp NHƯNG đa dạng:
    - Không trùng food_name.
    - Hạn chế trùng cuisine + meal_size.
    Dùng heuristic MMR-lite: chọn món có (cost + λ × similarity_to_picked) nhỏ nhất.
    """
    if scored_df.empty:
        return scored_df

    pool = scored_df.sort_values('composite').copy().reset_index(drop=True)
    picked_idx = []
    picked_rows = []

    # Pick #1: món có composite thấp nhất
    picked_idx.append(0)
    picked_rows.append(pool.iloc[0])

    while len(picked_rows) < n and len(picked_rows) < len(pool):
        best_i = None
        best_score = float('inf')

        for i in range(len(pool)):
            if i in picked_idx:
                continue
            row = pool.iloc[i]
            base_cost = row['composite']

            # Similarity penalty: cộng thêm vào cost nếu giống món đã chọn
            sim_pen = 0.0
            for p in picked_rows:
                # Trùng food_name → loại hẳn (skip)
                if str(row.get('food_name', '')).lower() == str(p.get('food_name', '')).lower():
                    sim_pen = 999
                    break
                # Trùng cuisine → +0.15
                if str(row.get('cuisine', '')) == str(p.get('cuisine', '')):
                    sim_pen += 0.15
                # Trùng cả meal_size → +0.05
                if str(row.get('meal_size', '')) == str(p.get('meal_size', '')):
                    sim_pen += 0.05
                # Trùng nutrition_profile → +0.05
                if str(row.get('nutrition_profile', '')) == str(p.get('nutrition_profile', '')):
                    sim_pen += 0.05

            score = base_cost + lambda_diverse * sim_pen
            if score < best_score:
                best_score = score
                best_i = i

        if best_i is None or best_score >= 999:
            break
        picked_idx.append(best_i)
        picked_rows.append(pool.iloc[best_i])

    return pool.iloc[picked_idx].reset_index(drop=True)


# ════════════════════════════════════════════════════════════════════
#  MAIN FUNCTION
# ════════════════════════════════════════════════════════════════════
def get_recommendation(
    user_lat: float,
    user_lon: float,
    user_time: float,          # phút
    user_hunger: float,        # 0–10
    user_budget_vnd: float,    # VND
    user_health_str: str,      # 'Diet' | 'Cân bằng' | 'Bulking'
    city: str = 'Ho Chi Minh',
    top_n: int = 40,
    user_taste_pref: np.ndarray | None = None,   # (spicy, sweet, salty) 0–1
) -> dict:
    """
    Returns
    -------
    {
        'results':          list[dict] (top 3),
        'weather':          {'temperature', 'rainfall'},
        'weather_severity': float,
        'ideal_distance':   float,
        'fuzzy_outputs': {
            'meal_score', 'cal_score', 'price_tier',
            'expected_meal_size', 'expected_cal', 'expected_price_tier',
        },
        'rule_count':       int,
    }
    """
    # ───────── 1. THỜI TIẾT ─────────
    weather = get_weather_data(city)
    temp = float(weather.get('temperature', 32))
    rain = float(weather.get('rainfall', 0))

    # ───────── 2. CHUẨN HOÁ INPUTS ─────────
    health_float = _health_to_float(user_health_str)
    budget_k = min(float(user_budget_vnd) / 1000.0, 500.0)  # cap 500k cho fuzzy universe
    time_clip   = max(0.0,  min(120.0, float(user_time)))
    hunger_clip = max(0.0,  min(10.0,  float(user_hunger)))

    # ───────── 3. FUZZY TẦNG 1 ─────────
    try:
        _sim1.input['temperature'] = max(15.0, min(45.0, temp))
        _sim1.input['rainfall']    = max(0.0,  min(25.0, rain))
        _sim1.input['time']        = time_clip
        _sim1.input['hunger']      = hunger_clip
        _sim1.input['health']      = max(0.0,  min(10.0, health_float))
        _sim1.input['budget']      = max(0.0,  min(500.0, budget_k))
        _sim1.compute()
        weather_sev = float(_sim1.output['weather_severity'])
        meal_score  = float(_sim1.output['meal_score'])
        cal_score   = float(_sim1.output['cal_score'])
        price_tier_v= float(_sim1.output['price_tier'])
    except Exception as e:
        print(f'[Fuzzy T1 Error] {e}')
        weather_sev = 4.0; meal_score = 5.5; cal_score = 5.0; price_tier_v = 5.0

    # ───────── 4. FUZZY TẦNG 2 ─────────
    try:
        _sim2.input['wsev_in']   = weather_sev
        _sim2.input['time_in']   = time_clip
        _sim2.input['hunger_in'] = hunger_clip
        _sim2.compute()
        ideal_dist = float(_sim2.output['ideal_dist'])
        if ideal_dist < 0.5:
            ideal_dist = 0.5
    except Exception as e:
        print(f'[Fuzzy T2 Error] {e}')
        ideal_dist = 2.0

    expected_meal  = _meal_score_to_size(meal_score)
    expected_cal   = _cal_score_to_cat(cal_score)
    expected_price = _price_tier_to_cat(price_tier_v)

    # ───────── 5. HARD FILTER ─────────
    df = FOOD_DF.copy()

    # 5a. Ngân sách (với hệ số tolerant 1.15 để không quá khắt khe)
    budget_cap = user_budget_vnd * 1.15
    df_budget = df[df['price_vnd'] <= budget_cap]
    if len(df_budget) < 8:
        # Nới lên 1.5× nếu quá ít món
        budget_cap = max(user_budget_vnd * 1.5, 50000)
        df_budget = df[df['price_vnd'] <= budget_cap]
        if df_budget.empty:
            df_budget = df.nsmallest(15, 'price_vnd')   # fallback: 15 món rẻ nhất
        print(f'[Budget relaxed] {user_budget_vnd:,.0f} → {budget_cap:,.0f} ({len(df_budget)} món)')
    df = df_budget.copy()

    # 5b. Diet KHÔNG cho phép greasy/sweet+high; Bulking KHÔNG cho phép pure sweet
    if health_float >= 7.0:  # Diet
        df = df[~((df['nutrition_profile'] == 'greasy') & (df['cal_cat'] == 'high'))]
        df = df[~((df['nutrition_profile'] == 'sweet')  & (df['cal_cat'] == 'high'))]
    elif health_float <= 3.0:  # Bulking
        df = df[df['nutrition_profile'] != 'sweet']

    # 5c. Nếu meal_score rất thấp (snack), loại bỏ full_meal lớn quá
    if expected_meal == 'snack':
        df = df[df['meal_size'].isin(['snack', 'light_meal'])]
    elif expected_meal == 'light_meal':
        # giữ tất cả nhưng full_meal sẽ bị phạt qua _meal_size_match
        pass

    # Fallback nếu filter quá chặt
    if df.empty:
        df = df_budget.copy()
        print('[Health filter relaxed] empty → fallback budget only')

    if df.empty:
        return {
            'results': [], 'weather': weather,
            'weather_severity': weather_sev,
            'ideal_distance': ideal_dist,
            'fuzzy_outputs': {
                'meal_score': meal_score, 'cal_score': cal_score,
                'price_tier': price_tier_v,
                'expected_meal_size': expected_meal,
                'expected_cal': expected_cal,
                'expected_price_tier': expected_price,
            },
            'rule_count': total_rule_count(),
        }

    # ───────── 6. ROUTING ─────────
    df = get_routing_distances(user_lat, user_lon, df, top_n=top_n)
    df['route_km'] = df['route_km'].clip(lower=0.1, upper=15.0)

    # ───────── 7. TASTE VECTOR ─────────
    def _item_vector(row) -> np.ndarray:
        try:
            vals = [row.get('do_cay'), row.get('do_ngot'), row.get('do_man')]
            if all(pd.notna(v) for v in vals):
                return np.array([float(v) / 9.0 for v in vals])
        except Exception:
            pass
        return get_food_vector(row.get('cuisine', 'vie'),
                               row.get('nutrition_profile', ''),
                               row.get('meal_size', ''))
    df['taste_vec'] = df.apply(_item_vector, axis=1)

    # ───────── 8. COMPOSITE SCORING ─────────
    # Trọng số scoring (tổng = 1.0)
    WEIGHTS = {
        'distance':  0.18,   # ↓ từ 0.22 (khoảng cách quan trọng nhưng không lấn át)
        'meal':      0.18,
        'cal':       0.12,
        'nutrition': 0.25,   # ↑ từ 0.22 (sức khoẻ ưu tiên hơn)
        'budget':    0.10,
        'price_fit': 0.07,   # MỚI: thưởng nếu giá khớp tier mong đợi
        'weather':   0.06,
        'taste':     0.04,
    }

    scores = []
    for _, row in df.iterrows():
        dist_s    = _distance_fit(float(row['route_km']), ideal_dist)
        meal_s    = _meal_size_match(str(row.get('meal_size', 'full_meal')), expected_meal)
        cal_s     = _cal_match(str(row.get('cal_cat', 'medium')), expected_cal)
        nutr_s    = _nutrition_penalty(str(row.get('nutrition_profile', '')), health_float)
        budget_s  = _budget_penalty(float(row['price_vnd']), float(user_budget_vnd))
        price_s   = _price_tier_match(float(row['price_vnd']), expected_price)
        weather_s = _weather_penalty(str(row.get('meal_form', '')),
                                     str(row.get('nutrition_profile', '')),
                                     temp, rain)
        if user_taste_pref is not None:
            taste_s = 1.0 - cosine_sim(row['taste_vec'], user_taste_pref)
        else:
            taste_s = 0.3   # neutral

        composite = (
            WEIGHTS['distance']  * dist_s   +
            WEIGHTS['meal']      * meal_s   +
            WEIGHTS['cal']       * cal_s    +
            WEIGHTS['nutrition'] * nutr_s   +
            WEIGHTS['budget']    * budget_s +
            WEIGHTS['price_fit'] * price_s  +
            WEIGHTS['weather']   * weather_s+
            WEIGHTS['taste']     * taste_s
        )

        # Penalty cứng nếu vượt ngân sách
        if float(row['price_vnd']) > user_budget_vnd * 1.0:
            composite += 0.15

        scores.append({
            '_idx': row.name, 'composite': composite,
            'dist_s': dist_s, 'meal_s': meal_s, 'cal_s': cal_s,
            'nutr_s': nutr_s, 'budget_s': budget_s,
            'price_s': price_s, 'weather_s': weather_s,
        })

    score_df = pd.DataFrame(scores).set_index('_idx')
    df = df.join(score_df, how='inner')

    # ───────── 9. DIVERSIFICATION ─────────
    top_pool = df.nsmallest(min(20, len(df)), 'composite')
    top3 = _diversify_top_n(top_pool, n=3, lambda_diverse=0.45)

    # ───────── 10. BUILD OUTPUT ─────────
    if not top3.empty:
        best_cost  = float(top3['composite'].min())
        worst_cost = float(top3['composite'].max())
    else:
        best_cost = worst_cost = 0.0

    results = []
    for rank, (_, row) in enumerate(top3.iterrows()):
        price_vnd = int(row['price_vnd'])
        cuisine_c = str(row.get('cuisine', 'vie'))
        cuisine_disp = cuisine_display_name(cuisine_c)
        kcal_val  = _estimate_kcal(str(row.get('meal_size', '')),
                                   str(row.get('cal_cat', 'medium')),
                                   str(row.get('nutrition_profile', '')))

        # Match% theo RANK (top1 > top2 > top3 luôn luôn) + nudge nhỏ theo composite
        base_match = _match_pct_by_rank(rank)
        match_val  = _adjust_match_by_composite(
            base_match, float(row['composite']), best_cost, worst_cost,
        )

        food_dict = {
            'food_name':         str(row.get('food_name', '')),
            'shop_name':         str(row.get('shop_name', '')),
            'cuisine':           cuisine_c,
            'cuisine_country':   cuisine_disp,
            'flag':              _cuisine_flag(cuisine_c),
            'dot_colors':        _cuisine_colors(cuisine_c),
            'price':             f"{price_vnd:,}đ",
            'price_vnd':         price_vnd,
            'kcal':              f"{kcal_val} kcal",
            'kcal_value':        kcal_val,
            'match':             match_val,
            'route_km':          float(row['route_km']),
            'actual_route_km':   float(row['route_km']),
            'lat':               float(row.get('lat', user_lat)),
            'lon':               float(row.get('lon', user_lon)),
            'image_url':         str(row.get('image_url', '')),
            'meal_size':         str(row.get('meal_size', '')),
            'meal_form':         str(row.get('meal_form', '')),
            'nutrition_profile': str(row.get('nutrition_profile', '')),
            'cal_cat':           str(row.get('cal_cat', 'medium')),
            'taste_vector':      [float(x) for x in (row['taste_vec'].tolist()
                                  if hasattr(row['taste_vec'], 'tolist')
                                  else row['taste_vec'])],
            'tags':              _build_tags(row, cuisine_disp),
            'ingredients':       _ingredients_for(row.get('food_name', '')),
            'cost_score':        float(row['composite']),
            'score_breakdown': {
                'distance':  round(float(row['dist_s']),    3),
                'meal_fit':  round(float(row['meal_s']),    3),
                'cal_fit':   round(float(row['cal_s']),     3),
                'nutrition': round(float(row['nutr_s']),    3),
                'budget':    round(float(row['budget_s']),  3),
                'price_fit': round(float(row['price_s']),   3),
                'weather':   round(float(row['weather_s']), 3),
            },
        }
        food_dict['reasons'] = _build_reasons(
            food_dict, weather, ideal_dist, meal_score, cal_score,
            health_float, user_budget_vnd, food_dict['score_breakdown'],
        )
        results.append(food_dict)

    return {
        'results':          results,
        'weather':          weather,
        'weather_severity': weather_sev,
        'ideal_distance':   ideal_dist,
        'fuzzy_outputs': {
            'meal_score':           round(meal_score, 2),
            'cal_score':            round(cal_score, 2),
            'price_tier':           round(price_tier_v, 2),
            'expected_meal_size':   expected_meal,
            'expected_cal':         expected_cal,
            'expected_price_tier':  expected_price,
        },
        'rule_count': total_rule_count(),
    }
