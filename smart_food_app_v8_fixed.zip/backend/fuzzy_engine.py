# backend/fuzzy_engine.py
"""
Hệ thống Fuzzy Logic 2 tầng (đã refactor)
==========================================
TẦNG 1: (temperature, rainfall, hunger, health, budget, time)
        → (weather_severity, meal_score, cal_score, price_tier)

TẦNG 2: (weather_sev_in, time_in, hunger_in) → ideal_distance

Thiết kế:
- Mỗi consequent có hệ rule rõ ràng, phủ đầy đủ vùng input.
- Thêm price_tier để gợi ý ngưỡng giá phù hợp (cheap/standard/premium).
- T2 dùng antecedent RIÊNG (suffix _in) để không bị "đan chéo" với T1.

Universe:
- temperature: 15–45°C  | rainfall: 0–25 mm/h
- hunger:      0–10     | health:   0–10 (0=bulking, 5=balanced, 10=diet)
- budget:      0–500 nghìn VND | time: 0–120 phút
- Outputs:     weather_severity, meal_score, cal_score, price_tier : 0–10
- ideal_dist:  0–8 km
"""
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl


def build_fuzzy_systems():
    # ================================================================
    # ANTECEDENTS – TẦNG 1
    # ================================================================
    temperature = ctrl.Antecedent(np.arange(15, 46, 1), 'temperature')
    temperature['cool'] = fuzz.trapmf(temperature.universe, [15, 15, 22, 26])
    temperature['warm'] = fuzz.trapmf(temperature.universe, [24, 27, 31, 34])
    temperature['hot']  = fuzz.trapmf(temperature.universe, [32, 35, 45, 45])

    rainfall = ctrl.Antecedent(np.arange(0, 26, 1), 'rainfall')
    rainfall['none']  = fuzz.trapmf(rainfall.universe, [0, 0, 0.5, 1.5])
    rainfall['light'] = fuzz.trapmf(rainfall.universe, [1, 2.5, 4, 7])
    rainfall['heavy'] = fuzz.trapmf(rainfall.universe, [5, 9, 25, 25])

    hunger = ctrl.Antecedent(np.arange(0, 11, 1), 'hunger')
    hunger['low']    = fuzz.trapmf(hunger.universe, [0, 0, 2.5, 4])
    hunger['medium'] = fuzz.trimf(hunger.universe,  [3, 5, 7])
    hunger['high']   = fuzz.trapmf(hunger.universe, [6, 7.5, 10, 10])

    # health: 0=bulking, 5=balanced, 10=diet
    health = ctrl.Antecedent(np.arange(0, 11, 1), 'health')
    health['bulking']  = fuzz.trapmf(health.universe, [0, 0, 2, 4])
    health['balanced'] = fuzz.trapmf(health.universe, [3, 4.5, 5.5, 7])
    health['diet']     = fuzz.trapmf(health.universe, [6, 8, 10, 10])

    budget = ctrl.Antecedent(np.arange(0, 501, 1), 'budget')
    budget['tight']    = fuzz.trapmf(budget.universe, [0,   0,   30,  55])
    budget['moderate'] = fuzz.trapmf(budget.universe, [40,  70,  110, 150])
    budget['generous'] = fuzz.trapmf(budget.universe, [120, 170, 260, 350])
    budget['lavish']   = fuzz.trapmf(budget.universe, [280, 380, 500, 500])

    time = ctrl.Antecedent(np.arange(0, 121, 1), 'time')
    time['short']  = fuzz.trapmf(time.universe, [0,  0,  12, 22])
    time['medium'] = fuzz.trapmf(time.universe, [18, 28, 45, 60])
    time['long']   = fuzz.trapmf(time.universe, [50, 70, 120, 120])

    # ================================================================
    # CONSEQUENTS – TẦNG 1
    # ================================================================
    weather_sev = ctrl.Consequent(np.arange(0, 11, 1), 'weather_severity')
    weather_sev['pleasant']     = fuzz.trapmf(weather_sev.universe, [0, 0, 2, 3.5])
    weather_sev['uncomfortable']= fuzz.trimf(weather_sev.universe,  [2.5, 4.5, 6.5])
    weather_sev['harsh']        = fuzz.trimf(weather_sev.universe,  [5.5, 7, 8.5])
    weather_sev['extreme']      = fuzz.trapmf(weather_sev.universe, [7.5, 9, 10, 10])

    meal_score = ctrl.Consequent(np.arange(0, 11, 1), 'meal_score')
    meal_score['snack']   = fuzz.trapmf(meal_score.universe, [0, 0, 1.5, 3])
    meal_score['light']   = fuzz.trimf(meal_score.universe,  [2, 4, 5.5])
    meal_score['regular'] = fuzz.trimf(meal_score.universe,  [4.5, 6.5, 8])
    meal_score['hearty']  = fuzz.trapmf(meal_score.universe, [7, 8.5, 10, 10])

    cal_score = ctrl.Consequent(np.arange(0, 11, 1), 'cal_score')
    cal_score['low']    = fuzz.trapmf(cal_score.universe, [0, 0, 2, 4])
    cal_score['medium'] = fuzz.trimf(cal_score.universe,  [3, 5, 7])
    cal_score['high']   = fuzz.trapmf(cal_score.universe, [6, 8, 10, 10])

    price_tier = ctrl.Consequent(np.arange(0, 11, 1), 'price_tier')
    price_tier['cheap']    = fuzz.trapmf(price_tier.universe, [0, 0, 2, 4])
    price_tier['standard'] = fuzz.trimf(price_tier.universe,  [3, 5, 7])
    price_tier['premium']  = fuzz.trapmf(price_tier.universe, [6, 8, 10, 10])

    # ================================================================
    # RULES T1 – WEATHER SEVERITY (8 luật)
    # ================================================================
    rules_w = [
        ctrl.Rule(temperature['cool'] & rainfall['none'],  weather_sev['pleasant']),
        ctrl.Rule(temperature['warm'] & rainfall['none'],  weather_sev['pleasant']),
        ctrl.Rule(temperature['hot']  & rainfall['none'],  weather_sev['harsh']),
        ctrl.Rule(temperature['cool'] & rainfall['light'], weather_sev['uncomfortable']),
        ctrl.Rule(temperature['warm'] & rainfall['light'], weather_sev['uncomfortable']),
        ctrl.Rule(temperature['hot']  & rainfall['light'], weather_sev['harsh']),
        ctrl.Rule(rainfall['heavy'],                       weather_sev['extreme']),
        ctrl.Rule(temperature['hot']  & rainfall['heavy'], weather_sev['extreme']),
    ]

    # ================================================================
    # RULES T1 – MEAL SCORE (18 luật)
    # Phủ mọi tổ hợp (hunger × health) + override bởi (time, budget).
    # ================================================================
    rules_m = [
        # --- BULKING ---
        ctrl.Rule(hunger['high']   & health['bulking'] & (budget['generous'] | budget['lavish']),
                  meal_score['hearty']),
        ctrl.Rule(hunger['high']   & health['bulking'] & (budget['tight'] | budget['moderate']),
                  meal_score['regular']),
        ctrl.Rule(hunger['medium'] & health['bulking'],
                  meal_score['regular']),
        ctrl.Rule(hunger['low']    & health['bulking'],
                  meal_score['light']),

        # --- BALANCED ---
        ctrl.Rule(hunger['high']   & health['balanced'] & (budget['generous'] | budget['lavish']),
                  meal_score['hearty']),
        ctrl.Rule(hunger['high']   & health['balanced'] & (budget['tight'] | budget['moderate']),
                  meal_score['regular']),
        ctrl.Rule(hunger['medium'] & health['balanced'],
                  meal_score['regular']),
        ctrl.Rule(hunger['low']    & health['balanced'],
                  meal_score['light']),

        # --- DIET (không bao giờ hearty) ---
        ctrl.Rule(hunger['high']   & health['diet'],
                  meal_score['regular']),
        ctrl.Rule(hunger['medium'] & health['diet'],
                  meal_score['light']),
        ctrl.Rule(hunger['low']    & health['diet'],
                  meal_score['snack']),

        # --- TIME OVERRIDE: gấp thì giảm 1 cấp ---
        ctrl.Rule(time['short'] & hunger['high'],
                  meal_score['regular']),
        ctrl.Rule(time['short'] & hunger['medium'],
                  meal_score['light']),
        ctrl.Rule(time['short'] & hunger['low'],
                  meal_score['snack']),

        # --- BUDGET OVERRIDE: rất ít tiền thì không hearty ---
        ctrl.Rule(budget['tight'] & hunger['high'],
                  meal_score['regular']),
        ctrl.Rule(budget['tight'] & hunger['medium'],
                  meal_score['light']),
        ctrl.Rule(budget['tight'] & hunger['low'],
                  meal_score['snack']),

        # --- Fallback rộng ---
        ctrl.Rule(hunger['medium'] & budget['moderate'],
                  meal_score['regular']),
    ]

    # ================================================================
    # RULES T1 – CAL SCORE (9 luật, phủ đủ 3×3)
    # ================================================================
    rules_c = [
        ctrl.Rule(health['diet']     & hunger['low'],    cal_score['low']),
        ctrl.Rule(health['diet']     & hunger['medium'], cal_score['low']),
        ctrl.Rule(health['diet']     & hunger['high'],   cal_score['medium']),

        ctrl.Rule(health['balanced'] & hunger['low'],    cal_score['low']),
        ctrl.Rule(health['balanced'] & hunger['medium'], cal_score['medium']),
        ctrl.Rule(health['balanced'] & hunger['high'],   cal_score['high']),

        ctrl.Rule(health['bulking']  & hunger['low'],    cal_score['medium']),
        ctrl.Rule(health['bulking']  & hunger['medium'], cal_score['high']),
        ctrl.Rule(health['bulking']  & hunger['high'],   cal_score['high']),
    ]

    # ================================================================
    # RULES T1 – PRICE TIER (6 luật)
    # ================================================================
    rules_p = [
        ctrl.Rule(budget['tight'],                         price_tier['cheap']),
        ctrl.Rule(budget['moderate'] & ~health['diet'],    price_tier['standard']),
        ctrl.Rule(budget['moderate'] & health['diet'],     price_tier['cheap']),
        ctrl.Rule(budget['generous'] & health['bulking'],  price_tier['premium']),
        ctrl.Rule(budget['generous'] & ~health['bulking'], price_tier['standard']),
        ctrl.Rule(budget['lavish'],                        price_tier['premium']),
    ]

    sys1 = ctrl.ControlSystem(rules_w + rules_m + rules_c + rules_p)
    sim1 = ctrl.ControlSystemSimulation(sys1)

    # ================================================================
    # TẦNG 2 – IDEAL DISTANCE (km)
    # ================================================================
    wsev_in = ctrl.Antecedent(np.arange(0, 11, 1), 'wsev_in')
    wsev_in['pleasant']      = fuzz.trapmf(wsev_in.universe, [0, 0, 2, 3.5])
    wsev_in['uncomfortable'] = fuzz.trimf(wsev_in.universe,  [2.5, 4.5, 6.5])
    wsev_in['harsh']         = fuzz.trimf(wsev_in.universe,  [5.5, 7, 8.5])
    wsev_in['extreme']       = fuzz.trapmf(wsev_in.universe, [7.5, 9, 10, 10])

    time_in = ctrl.Antecedent(np.arange(0, 121, 1), 'time_in')
    time_in['short']  = fuzz.trapmf(time_in.universe, [0,  0,  12, 22])
    time_in['medium'] = fuzz.trapmf(time_in.universe, [18, 28, 45, 60])
    time_in['long']   = fuzz.trapmf(time_in.universe, [50, 70, 120, 120])

    hunger_in = ctrl.Antecedent(np.arange(0, 11, 1), 'hunger_in')
    hunger_in['low']    = fuzz.trapmf(hunger_in.universe, [0, 0, 2.5, 4])
    hunger_in['medium'] = fuzz.trimf(hunger_in.universe,  [3, 5, 7])
    hunger_in['high']   = fuzz.trapmf(hunger_in.universe, [6, 7.5, 10, 10])

    ideal_dist = ctrl.Consequent(np.arange(0, 8.1, 0.1), 'ideal_dist')
    ideal_dist['nearby'] = fuzz.trapmf(ideal_dist.universe, [0.0, 0.0, 0.8, 1.6])
    ideal_dist['close']  = fuzz.trimf(ideal_dist.universe,  [1.0, 2.2, 3.5])
    ideal_dist['medium'] = fuzz.trimf(ideal_dist.universe,  [2.8, 4.0, 5.5])
    ideal_dist['far']    = fuzz.trapmf(ideal_dist.universe, [4.8, 6.0, 8.0, 8.0])

    rules_d = [
        ctrl.Rule(wsev_in['extreme'],                                            ideal_dist['nearby']),
        ctrl.Rule(wsev_in['harsh'],                                              ideal_dist['nearby']),
        ctrl.Rule(wsev_in['uncomfortable'] & time_in['short'],                   ideal_dist['nearby']),
        ctrl.Rule(wsev_in['uncomfortable'] & time_in['medium'],                  ideal_dist['close']),
        ctrl.Rule(wsev_in['uncomfortable'] & time_in['long'],                    ideal_dist['close']),
        ctrl.Rule(wsev_in['pleasant'] & time_in['short'],                        ideal_dist['close']),
        ctrl.Rule(wsev_in['pleasant'] & time_in['medium'] & hunger_in['high'],   ideal_dist['close']),
        ctrl.Rule(wsev_in['pleasant'] & time_in['medium'] & ~hunger_in['high'],  ideal_dist['medium']),
        ctrl.Rule(wsev_in['pleasant'] & time_in['long']   & hunger_in['high'],   ideal_dist['medium']),
        ctrl.Rule(wsev_in['pleasant'] & time_in['long']   & ~hunger_in['high'],  ideal_dist['far']),
    ]

    sys2 = ctrl.ControlSystem(rules_d)
    sim2 = ctrl.ControlSystemSimulation(sys2)

    return sim1, sim2


def total_rule_count() -> int:
    """Tổng số luật mờ trong toàn hệ – dùng cho UI hiển thị."""
    # T1: weather(8) + meal(18) + cal(9) + price(6) = 41
    # T2: distance(10)
    return 41 + 10  # = 51
