# backend/utils.py
import requests
import numpy as np
import pandas as pd
from geopy.geocoders import Nominatim
from scipy.spatial.distance import cosine

_HCMC_LAT = 10.7769
_HCMC_LON = 106.7009

_CITY_COORDS = {
    'ho chi minh': (_HCMC_LAT, _HCMC_LON),
    'hcmc':        (_HCMC_LAT, _HCMC_LON),
    'hanoi':       (21.0285, 105.8542),
    'ha noi':      (21.0285, 105.8542),
    'da nang':     (16.0544, 108.2022),
}


def get_weather_data(city: str = 'Ho Chi Minh') -> dict:
    lat, lon = _CITY_COORDS.get(city.lower().strip(), (_HCMC_LAT, _HCMC_LON))
    url = (
        f'https://api.open-meteo.com/v1/forecast'
        f'?latitude={lat}&longitude={lon}'
        f'&current=apparent_temperature,precipitation'
        f'&timezone=Asia%2FHo_Chi_Minh'
    )
    try:
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            cur = r.json().get('current', {})
            return {
                'temperature': cur.get('apparent_temperature', 33),
                'rainfall':    cur.get('precipitation', 0),
            }
    except Exception:
        pass
    return {'temperature': 33, 'rainfall': 0}


def get_user_location(address: str | None = None) -> tuple[float, float]:
    if address is None:
        address = 'University of Economics Ho Chi Minh City'
    try:
        geo = Nominatim(user_agent='smart_food_v3', timeout=5)
        loc = geo.geocode(address)
        if loc:
            return (loc.latitude, loc.longitude)
    except Exception:
        pass
    return (10.762622, 106.660172)


def haversine(lat1: float, lon1: float, lat2, lon2) -> np.ndarray:
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    a = np.sin((lat2-lat1)/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin((lon2-lon1)/2)**2
    return R * 2 * np.arcsin(np.sqrt(a))


def get_routing_distances(user_lat: float, user_lon: float, df: pd.DataFrame, top_n: int = 40) -> pd.DataFrame:
    """Haversine pre-filter → OSRM actual road distance."""
    df = df.copy()
    df['lat'] = pd.to_numeric(df['lat'], errors='coerce')
    df['lon'] = pd.to_numeric(df['lon'], errors='coerce')
    df = df.dropna(subset=['lat', 'lon'])

    df['haversine_km'] = haversine(user_lat, user_lon, df['lat'].values, df['lon'].values)
    df_near = df.nsmallest(top_n, 'haversine_km').copy()

    coords = [f'{user_lon},{user_lat}'] + [f'{r.lon},{r.lat}' for _, r in df_near.iterrows()]
    url = f'http://router.project-osrm.org/table/v1/driving/{";".join(coords)}?sources=0&annotations=distance'
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            meters = resp.json()['distances'][0][1:]
            df_near['route_km'] = [m / 1000.0 for m in meters]
            return df_near
    except Exception:
        pass
    # Fallback: Haversine × 1.3
    df_near['route_km'] = df_near['haversine_km'] * 1.3
    return df_near


def cosine_sim(a, b) -> float:
    try:
        a, b = np.array(a, dtype=float), np.array(b, dtype=float)
        if a.size == 0 or np.all(a == 0) or np.all(b == 0):
            return 0.5
        return float(1.0 - cosine(a, b))
    except Exception:
        return 0.5


def get_route_polyline(
    src_lat: float, src_lon: float,
    dst_lat: float, dst_lon: float,
    timeout: float = 8.0,
) -> dict:
    """
    Lấy tuyến đường thực tế từ OSRM Route API.

    Returns
    -------
    {
        'points':    list[(lat, lon)]   # các điểm vẽ polyline (đã reorder thành lat,lon)
        'distance':  float              # km
        'duration':  float              # phút
        'success':   bool
    }
    Nếu lỗi network/API → trả về 'points'=[src, dst] (đường thẳng) và success=False.
    """
    fallback = {
        'points':   [(src_lat, src_lon), (dst_lat, dst_lon)],
        'distance': haversine(src_lat, src_lon, dst_lat, dst_lon) * 1.3,
        'duration': 0.0,
        'success':  False,
    }
    url = (
        f'http://router.project-osrm.org/route/v1/driving/'
        f'{src_lon},{src_lat};{dst_lon},{dst_lat}'
        f'?overview=full&geometries=geojson&steps=false'
    )
    try:
        resp = requests.get(url, timeout=timeout)
        if resp.status_code != 200:
            return fallback
        data = resp.json()
        routes = data.get('routes') or []
        if not routes:
            return fallback
        route = routes[0]
        coords_lonlat = route.get('geometry', {}).get('coordinates', [])
        if not coords_lonlat:
            return fallback
        # OSRM trả về [lon, lat] – tkintermapview cần (lat, lon)
        points = [(float(c[1]), float(c[0])) for c in coords_lonlat]
        return {
            'points':   points,
            'distance': float(route.get('distance', 0)) / 1000.0,
            'duration': float(route.get('duration', 0)) / 60.0,
            'success':  True,
        }
    except Exception as e:
        print(f'[OSRM Route Error] {e}')
        return fallback
