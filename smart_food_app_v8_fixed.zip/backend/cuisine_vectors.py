# backend/cuisine_vectors.py
"""
Taste vectors (spicy, sweet, salty) normalized 0–1
Dùng cho cosine similarity với user preference
"""
import numpy as np

# (spicy, sweet, salty) – cả 3 trong [0,1]
CUISINE_VECTORS = {
    'Vietnam':          np.array([0.35, 0.25, 0.65]),
    'Vietnam_grilled':  np.array([0.30, 0.35, 0.65]),
    'Vietnam_soup':     np.array([0.25, 0.20, 0.70]),
    'Vietnam_veg':      np.array([0.15, 0.30, 0.50]),
    'Korea':            np.array([0.80, 0.25, 0.55]),
    'Japan':            np.array([0.10, 0.25, 0.70]),
    'Thailand':         np.array([0.85, 0.45, 0.55]),
    'Western':          np.array([0.15, 0.20, 0.55]),
    'China_spicy':      np.array([0.90, 0.15, 0.65]),
    'China_mild':       np.array([0.20, 0.30, 0.60]),
    'Vegetarian':       np.array([0.20, 0.35, 0.45]),
    'Dessert':          np.array([0.05, 0.90, 0.10]),
    'Snack':            np.array([0.30, 0.20, 0.60]),
}

CODE_TO_CUISINE = {
    'vie': 'Vietnam',
    'vietnam': 'Vietnam',
    'jpn': 'Japan',
    'japan': 'Japan',
    'kor': 'Korea',
    'korea': 'Korea',
    'us':  'Western',
    'western': 'Western',
    'tha': 'Thailand',
    'thailand': 'Thailand',
    'chn': 'China_mild',
    'chn ': 'China_mild',
    'china': 'China_mild',
    'kh':  'Vietnam',
    'veg': 'Vegetarian',
    'ind': 'Thailand',   # closest spice profile
}

# Map meal_size + nutrition → cuisine sub-type
NUTRITION_OVERRIDE = {
    ('vie', 'sweet'):      'Dessert',
    ('vie', 'vegetarian'): 'Vietnam_veg',
    ('vie', 'greasy'):     'Vietnam_grilled',
}


def get_food_vector(cuisine_code: str, nutrition_profile: str = '', meal_size: str = '') -> np.ndarray:
    """Trả về taste vector (spicy, sweet, salty) cho 1 món ăn cụ thể."""
    key = str(cuisine_code).strip().lower()

    # Override theo nutrition
    override_key = (key, str(nutrition_profile).lower())
    if override_key in NUTRITION_OVERRIDE:
        name = NUTRITION_OVERRIDE[override_key]
        return CUISINE_VECTORS[name].copy()

    mapped = CODE_TO_CUISINE.get(key)
    if mapped and mapped in CUISINE_VECTORS:
        return CUISINE_VECTORS[mapped].copy()

    return CUISINE_VECTORS['Vietnam'].copy()  # default


def get_country_vector(code: str) -> np.ndarray | None:
    mapped = CODE_TO_CUISINE.get(str(code).strip().lower())
    if mapped:
        return CUISINE_VECTORS.get(mapped)
    return CUISINE_VECTORS.get(code)


def map_cuisine_code(code: str) -> str | None:
    return CODE_TO_CUISINE.get(str(code).strip().lower())


def cuisine_display_name(code: str) -> str:
    mapping = {
        'vie': 'Việt Nam', 'kh': 'Việt Nam',
        'jpn': 'Nhật Bản',
        'kor': 'Hàn Quốc',
        'us':  'Phương Tây',
        'tha': 'Thái Lan',
        'chn': 'Trung Quốc', 'chn ': 'Trung Quốc',
        'veg': 'Chay',
        'ind': 'Ấn Độ',
    }
    return mapping.get(str(code).strip().lower(), 'Quốc tế')
