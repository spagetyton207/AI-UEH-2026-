# 🍽 Smart Food Recommendation App
**Môn học:** Fuzzy Logic – Giảng viên: Nguyễn Trường Thịnh

---

## 📦 Cài đặt

```bash
cd smart_food_app
pip install -r requirements.txt
```

---

## 🚀 Chạy app

```bash
python main.py
```

---

## 🏗 Cấu trúc dự án

```
smart_food_app/
├── main.py                     # Entry point – App chính
├── requirements.txt
├── backend/
│   ├── main.py                 # Pipeline tích hợp: Fuzzy → OSRM → Ranking
│   ├── fuzzy_engine.py         # Hệ suy diễn mờ 2 tầng (38 luật)
│   ├── utils.py                # Weather API (Open-Meteo), OSRM routing, Geocoding
│   ├── cuisine_vectors.py      # Vector khẩu vị (Sweet, Salty, Spicy)
│   └── food.csv                # 111 món ăn TPHCM (lat/lon thực)
├── tabs/
│   ├── recommend_tab.py        # Tab trang chủ
│   ├── suggest_wizard.py       # Wizard nhập điều kiện (2 bước)
│   ├── result_screen.py        # Màn hình kết quả (dữ liệu thực từ backend)
│   ├── food_detail_screen.py   # Chi tiết món + giải thích fuzzy
│   ├── map_screen.py           # Bản đồ: user → quán ăn + tuyến đường
│   ├── menu_tab.py             # Tab khám phá món
│   ├── profile_tab.py          # Tab profile
│   └── loading_screen.py       # Màn hình loading
└── utils/
    ├── theme.py                # Màu sắc, font
    └── widgets.py              # Widget tái sử dụng
```

---

## 🧠 Fuzzy Logic System

### Tầng 1 – Phân tích Nhu cầu & Môi trường
| Input | Phân loại |
|-------|-----------|
| Nhiệt độ | Cold / Normal / Hot |
| Lượng mưa | Dry / Light / Heavy |
| Thời gian chờ | Short / Medium / Long |
| Độ đói | Low / Medium / High |
| Ngân sách | Low / Medium / High / Very High / Exorbitant |
| Mục tiêu sức khoẻ | None / Normal / Strict |

**Output tầng 1:** Weather Severity, Price Range, Type Food, Calories

### Tầng 2 – Tính Khoảng Cách Lý Tưởng
**Input:** Weather Severity (từ tầng 1) + Time + Hunger  
**Output:** Ideal Distance (km)

### Cost Function
```
cost = dist                                    nếu dist ≤ ideal
     = dist + 5 × (dist − ideal) / ideal       nếu dist > ideal
```

Sau đó nhân với **taste penalty** dựa trên cosine similarity vector (Sweet, Salty, Spicy).

---

## 🌐 APIs sử dụng

| API | Dùng cho | Key |
|-----|----------|-----|
| Open-Meteo | Thời tiết thực (nhiệt độ, mưa) | Miễn phí, không cần key |
| OSRM | Khoảng cách đường thực tế | Miễn phí, public server |
| Nominatim (OSM) | Geocoding địa chỉ → tọa độ | Miễn phí, không cần key |
| CartoDB Tiles | Bản đồ nền (tkintermapview) | Miễn phí |

---

## 📊 Dữ liệu

`backend/food.csv` – 111 món ăn tại TPHCM:
- `shop_name`, `food_name`, `cuisine` (vie/kor/jpn/us/...)
- `lat`, `lon` – tọa độ thực của quán
- `price_vnd` – giá (VND)
- `do_cay`, `do_ngot`, `do_man` – vector khẩu vị
- `calories_estimate`, `nutrition_profile`

---

## 🎯 Luồng hoạt động

1. User nhập: ngân sách, độ đói, mục tiêu, thời gian chờ
2. App lấy **thời tiết thực** từ Open-Meteo (Ho Chi Minh)
3. **Fuzzy tầng 1** tính: weather severity, price range, calories
4. **Fuzzy tầng 2** tính: khoảng cách lý tưởng (km)
5. Lọc món trong `food.csv` theo ngân sách
6. **OSRM** tính khoảng cách đường thực tế từ vị trí user
7. **Cost function** xếp hạng và chọn Top 3
8. Hiển thị kết quả + giải thích + **bản đồ tuyến đường**
