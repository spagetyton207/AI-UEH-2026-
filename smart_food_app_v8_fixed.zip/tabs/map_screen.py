"""
Map Screen – Hiển thị tuyến đường THỰC TẾ từ vị trí user → quán ăn được chọn.
Chỉ vẽ 2 marker (user + quán focus) để không lẫn các quán khác.
Đường đi lấy từ OSRM /route service (polyline theo đường thật).
"""
import customtkinter as ctk
import tkintermapview
import threading

BG        = "#F5F0E8"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_ACT   = "#6FCF97"
GRN_LIGHT = "#E8F4EE"
WHITE     = "#FFFFFF"

# Vị trí mặc định: ĐH Kinh tế TP.HCM
DEFAULT_LAT = 10.762622
DEFAULT_LON = 106.660172
DEFAULT_ZOOM = 15


class MapScreen(ctk.CTkFrame):
    """
    Tham số
    -------
    parent       : widget cha
    on_close     : callback khi đóng
    results      : list[dict] - top 3 món (dùng làm danh sách chip chọn focus)
    focused_food : dict - quán đang được focus (mặc định: top 1)
    """

    def __init__(self, parent, on_close, results=None, focused_food=None):
        super().__init__(parent, fg_color=BG, corner_radius=0)
        self.on_close   = on_close
        self.results    = results or []
        self.focused    = focused_food or (results[0] if results else None)
        self._user_lat  = DEFAULT_LAT
        self._user_lon  = DEFAULT_LON
        self._path_obj  = None
        self._markers   = []          # các marker đã đặt (để xoá khi đổi focus)
        self._route_info_label = None
        self._after_ids = []

        self._build_ui()

        # Fetch vị trí user (background) – khi xong sẽ tự refresh
        threading.Thread(target=self._fetch_user_location, daemon=True).start()

    # ─────────────────────────────────────────────────────────────
    #  AFTER HELPERS
    # ─────────────────────────────────────────────────────────────
    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def destroy(self):
        for aid in self._after_ids:
            try: self.after_cancel(aid)
            except Exception: pass
        super().destroy()

    def _fetch_user_location(self):
        try:
            from backend.utils import get_user_location
            lat, lon = get_user_location()
            self._user_lat, self._user_lon = lat, lon
        except Exception:
            pass
        # Update UI trên main thread
        try:
            self.after(0, self._refresh_after_user_location)
        except Exception:
            pass

    def _refresh_after_user_location(self):
        """Đã có vị trí user thật → vẽ lại markers + đường đi."""
        try:
            self._redraw_for_focused()
        except Exception as e:
            print(f"[Map Refresh Error] {e}")

    # ─────────────────────────────────────────────────────────────
    #  BUILD UI
    # ─────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Top bar
        topbar = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        topbar.pack(fill="x")
        self._topbar(topbar)

        # Info bar (tên món + khoảng cách)
        self._info_bar()

        # Chips chọn quán focus
        self._food_chips_bar()

        # Map area (chiếm toàn bộ phần còn lại)
        map_frame = ctk.CTkFrame(self, fg_color=GRN_DRK, corner_radius=16)
        map_frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        self.map_widget = tkintermapview.TkinterMapView(
            map_frame, corner_radius=14,
        )
        self.map_widget.pack(fill="both", expand=True, padx=2, pady=2)

        # CartoDB Positron - clean minimal style
        self.map_widget.set_tile_server(
            "https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png"
        )

        # Vị trí khởi tạo
        if self.focused:
            self.map_widget.set_position(
                self.focused.get("lat", DEFAULT_LAT),
                self.focused.get("lon", DEFAULT_LON),
            )
        else:
            self.map_widget.set_position(DEFAULT_LAT, DEFAULT_LON)
        self.map_widget.set_zoom(DEFAULT_ZOOM)

        # Vẽ ngay với vị trí mặc định, sau khi geocode xong sẽ redraw
        self._redraw_for_focused()

    def _topbar(self, parent):
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(14, 10))

        ctk.CTkButton(
            bar, text="←", font=("Segoe UI", 16, "bold"),
            width=36, height=36, corner_radius=18,
            fg_color="#EEEEEE", hover_color="#DDDDDD", text_color=GRN_DRK,
            command=self.on_close,
        ).pack(side="left")
        ctk.CTkLabel(bar, text="Bản đồ quán ăn",
                     font=("Segoe UI", 16, "bold"), text_color=GRN_DRK,
                     ).pack(side="left", padx=14)

        # Tile switcher (Minimal / Vệ tinh)
        switch = ctk.CTkFrame(bar, fg_color="transparent")
        switch.pack(side="right")
        self._btn_street = ctk.CTkButton(
            switch, text="☁ Minimal",
            font=("Segoe UI", 10, "bold"), height=30, width=88,
            corner_radius=14, fg_color=GRN_DRK, hover_color=GRN_MID,
            text_color=WHITE, command=self._use_street,
        )
        self._btn_street.pack(side="left", padx=(0, 4))
        self._btn_sat = ctk.CTkButton(
            switch, text="🛰 Vệ tinh",
            font=("Segoe UI", 10, "bold"), height=30, width=78,
            corner_radius=14, fg_color="#DDDDDD", hover_color="#CCCCCC",
            text_color=GRN_DRK, command=self._use_satellite,
        )
        self._btn_sat.pack(side="left")

    def _info_bar(self):
        self._info_frame = ctk.CTkFrame(self, fg_color="transparent")
        self._info_frame.pack(fill="x", padx=16, pady=(0, 6))

        pill = ctk.CTkFrame(self._info_frame, fg_color=GRN_LIGHT, corner_radius=16)
        pill.pack(side="left")

        name = (self.focused or {}).get("food_name", "")
        shop = (self.focused or {}).get("shop_name", "")
        text = f"📍 {name[:20]}"
        if shop:
            text += f"  ·  {shop[:18]}"
        ctk.CTkLabel(pill, text=text,
                     font=("Segoe UI", 11, "bold"), text_color=GRN_DRK,
                     padx=12, pady=6).pack()

        # Khoảng cách hiển thị (sẽ được cập nhật khi OSRM trả về)
        dist_init = (self.focused or {}).get("actual_route_km", 0.0)
        self._dist_pill = ctk.CTkFrame(self._info_frame, fg_color=GRN_DRK, corner_radius=16)
        self._dist_pill.pack(side="left", padx=(8, 0))
        self._route_info_label = ctk.CTkLabel(
            self._dist_pill, text=f"🛣 {dist_init:.1f} km",
            font=("Segoe UI", 11, "bold"), text_color=GRN_ACT,
            padx=12, pady=6,
        )
        self._route_info_label.pack()

    def _food_chips_bar(self):
        """Chip list để chuyển focus giữa các quán."""
        if not self.results:
            return
        scroll = ctk.CTkScrollableFrame(
            self, orientation="horizontal", fg_color="transparent",
            height=48, scrollbar_button_color=BG,
        )
        scroll.pack(fill="x", padx=16, pady=(0, 6))

        self._chip_buttons = []
        for i, food in enumerate(self.results):
            is_focused = self._is_same_food(food, self.focused)
            name = food.get("food_name", "")
            dist = food.get("actual_route_km", 0)
            label = f"{'⭐ ' if i == 0 else ''}{name[:14]}{'…' if len(name) > 14 else ''}  {dist:.1f}km"

            btn = ctk.CTkButton(
                scroll, text=label,
                font=("Segoe UI", 11, "bold"),
                height=34, corner_radius=17,
                fg_color=GRN_DRK if is_focused else WHITE,
                hover_color=GRN_MID,
                text_color=GRN_ACT if is_focused else GRN_DRK,
                border_width=0 if is_focused else 1, border_color="#DDDDDD",
                command=lambda f=food: self._focus_food(f),
            )
            btn.pack(side="left", padx=(0, 6))
            self._chip_buttons.append((food, btn))

    def _update_chip_styles(self):
        if not hasattr(self, "_chip_buttons"):
            return
        for food, btn in self._chip_buttons:
            is_focused = self._is_same_food(food, self.focused)
            btn.configure(
                fg_color=GRN_DRK if is_focused else WHITE,
                text_color=GRN_ACT if is_focused else GRN_DRK,
                border_width=0 if is_focused else 1,
            )

    @staticmethod
    def _is_same_food(a, b):
        if a is None or b is None:
            return False
        if a is b:
            return True
        return (a.get("food_name") == b.get("food_name")
                and a.get("shop_name") == b.get("shop_name"))

    # ─────────────────────────────────────────────────────────────
    #  MARKERS & PATH  (CHỈ user + 1 quán focus)
    # ─────────────────────────────────────────────────────────────
    def _clear_map(self):
        # Xoá tất cả marker hiện tại
        try:
            self.map_widget.delete_all_marker()
        except Exception:
            pass
        self._markers.clear()
        # Xoá path nếu có
        if self._path_obj is not None:
            try:
                self._path_obj.delete()
            except Exception:
                pass
            self._path_obj = None

    def _redraw_for_focused(self):
        """Vẽ lại map với CHỈ user marker + 1 quán focus + đường đi thật."""
        if not self.focused:
            return
        self._clear_map()

        dst_lat = float(self.focused.get("lat", DEFAULT_LAT))
        dst_lon = float(self.focused.get("lon", DEFAULT_LON))

        # User marker (xanh dương) – text ngắn để không che bản đồ
        try:
            m_user = self.map_widget.set_marker(
                self._user_lat, self._user_lon,
                text="Bạn",
                font=("Segoe UI", 10, "bold"),
                text_color="#1F4A82",
                marker_color_circle="#1F4A82",
                marker_color_outside="#3B7DD8",
            )
            self._markers.append(m_user)
        except Exception as e:
            print(f"[User Marker] {e}")

        # Quán focus marker (xanh lá đậm) – text là tên món ngắn
        food_name = str(self.focused.get("food_name", ""))[:18]
        try:
            m_dst = self.map_widget.set_marker(
                dst_lat, dst_lon,
                text=food_name,
                font=("Segoe UI", 10, "bold"),
                text_color=GRN_DRK,
                marker_color_circle=GRN_DRK,
                marker_color_outside=GRN_MID,
            )
            self._markers.append(m_dst)
        except Exception as e:
            print(f"[Dest Marker] {e}")

        # Fit map vừa cả 2 điểm
        self._fit_to_two_points(self._user_lat, self._user_lon, dst_lat, dst_lon)

        # Vẽ đường thẳng tạm thời (sẽ thay bằng đường thực khi OSRM trả về)
        try:
            self._path_obj = self.map_widget.set_path(
                [(self._user_lat, self._user_lon), (dst_lat, dst_lon)],
                color="#7BB098", width=3,
            )
        except Exception:
            pass

        # Lấy đường đi thật trong background
        threading.Thread(target=self._fetch_real_route,
                         args=(self._user_lat, self._user_lon, dst_lat, dst_lon),
                         daemon=True).start()

    def _fit_to_two_points(self, lat1, lon1, lat2, lon2):
        """Đặt map để nhìn thấy cả 2 điểm với padding."""
        try:
            # tkintermapview có method set_position; ta tính center và zoom phù hợp
            mid_lat = (lat1 + lat2) / 2
            mid_lon = (lon1 + lon2) / 2
            self.map_widget.set_position(mid_lat, mid_lon)

            # Tính khoảng cách thô để chọn zoom
            d_lat = abs(lat1 - lat2)
            d_lon = abs(lon1 - lon2)
            spread = max(d_lat, d_lon)
            if spread < 0.005:    zoom = 16
            elif spread < 0.01:   zoom = 15
            elif spread < 0.025:  zoom = 14
            elif spread < 0.05:   zoom = 13
            elif spread < 0.1:    zoom = 12
            else:                 zoom = 11
            self.map_widget.set_zoom(zoom)
        except Exception as e:
            print(f"[Fit Map] {e}")

    def _fetch_real_route(self, src_lat, src_lon, dst_lat, dst_lon):
        """Gọi OSRM lấy đường đi thật, sau đó vẽ lại path trên main thread."""
        try:
            from backend.utils import get_route_polyline
            route = get_route_polyline(src_lat, src_lon, dst_lat, dst_lon)
        except Exception as e:
            print(f"[Route Fetch] {e}")
            return

        # Đẩy về main thread để cập nhật UI
        try:
            self.after(0, lambda: self._apply_route(route, src_lat, src_lon, dst_lat, dst_lon))
        except Exception:
            pass

    def _apply_route(self, route, src_lat, src_lon, dst_lat, dst_lon):
        """Áp dụng polyline đường thật vào map (chạy trên main thread)."""
        # Nếu user đã chuyển focus rồi thì bỏ qua kết quả cũ
        if not self.focused:
            return
        cur_lat = float(self.focused.get("lat", 0))
        cur_lon = float(self.focused.get("lon", 0))
        if abs(cur_lat - dst_lat) > 1e-6 or abs(cur_lon - dst_lon) > 1e-6:
            return  # response cho focus cũ – bỏ

        points = route.get("points") or []
        if len(points) < 2:
            return

        # Xoá path cũ
        if self._path_obj is not None:
            try:
                self._path_obj.delete()
            except Exception:
                pass
            self._path_obj = None

        # Vẽ path mới với màu đậm
        try:
            self._path_obj = self.map_widget.set_path(
                points,
                color=GRN_DRK, width=4,
            )
        except Exception as e:
            print(f"[Set Path] {e}")
            return

        # Cập nhật label khoảng cách + thời gian
        if route.get("success") and self._route_info_label is not None:
            dist_km = route.get("distance", 0.0)
            dur_min = route.get("duration", 0.0)
            try:
                self._route_info_label.configure(
                    text=f"🛣 {dist_km:.1f} km  ·  {dur_min:.0f} phút"
                )
            except Exception:
                pass

    # ─────────────────────────────────────────────────────────────
    #  FOCUS SWITCHING
    # ─────────────────────────────────────────────────────────────
    def _focus_food(self, food):
        if self._is_same_food(food, self.focused):
            return
        self.focused = food
        # Cập nhật info pill
        try:
            for w in self._info_frame.winfo_children():
                w.destroy()
            self._info_bar_rebuild_into_existing_frame()
        except Exception:
            pass
        self._update_chip_styles()
        # Redraw markers + path
        self._redraw_for_focused()

    def _info_bar_rebuild_into_existing_frame(self):
        """Vẽ lại nội dung info pill (vì focused đã đổi)."""
        pill = ctk.CTkFrame(self._info_frame, fg_color=GRN_LIGHT, corner_radius=16)
        pill.pack(side="left")
        name = (self.focused or {}).get("food_name", "")
        shop = (self.focused or {}).get("shop_name", "")
        text = f"📍 {name[:20]}"
        if shop:
            text += f"  ·  {shop[:18]}"
        ctk.CTkLabel(pill, text=text,
                     font=("Segoe UI", 11, "bold"), text_color=GRN_DRK,
                     padx=12, pady=6).pack()

        dist_init = (self.focused or {}).get("actual_route_km", 0.0)
        self._dist_pill = ctk.CTkFrame(self._info_frame, fg_color=GRN_DRK, corner_radius=16)
        self._dist_pill.pack(side="left", padx=(8, 0))
        self._route_info_label = ctk.CTkLabel(
            self._dist_pill, text=f"🛣 {dist_init:.1f} km",
            font=("Segoe UI", 11, "bold"), text_color=GRN_ACT,
            padx=12, pady=6,
        )
        self._route_info_label.pack()

    # ─────────────────────────────────────────────────────────────
    #  TILE MODES
    # ─────────────────────────────────────────────────────────────
    def _use_street(self):
        self.map_widget.set_tile_server(
            "https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png"
        )
        try:
            self._btn_street.configure(fg_color=GRN_DRK, text_color=WHITE)
            self._btn_sat.configure(fg_color="#DDDDDD", text_color=GRN_DRK)
        except Exception:
            pass

    def _use_satellite(self):
        self.map_widget.set_tile_server(
            "https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga",
            max_zoom=22,
        )
        try:
            self._btn_street.configure(fg_color="#DDDDDD", text_color=GRN_DRK)
            self._btn_sat.configure(fg_color=GRN_DRK, text_color=WHITE)
        except Exception:
            pass
