"""
Tab 2: Khám phá món ăn
- Card khẩu vị đã học (giữ nguyên)
- Danh sách TOÀN BỘ món từ food.csv (có filter theo loại + tìm kiếm)
- Click vào món → mở food_detail_screen
"""
import customtkinter as ctk
import tkinter as tk

BG        = "#F5F0E8"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_ACT   = "#6FCF97"
GRN_LIGHT = "#E8F4EE"
WHITE     = "#FFFFFF"
ORANGE    = "#F4845F"
RED_BAR   = "#E05C4B"
YELLOW    = "#F4A261"

TASTE_PROFILE = [
    ("Cay nhẹ",   0.72, GRN_MID),
    ("Nước/canh", 0.86, GRN_MID),
    ("Thanh đạm", 0.81, GRN_MID),
    ("Đồ chiên",  0.21, RED_BAR),
    ("Ngọt",      0.34, YELLOW),
]

# Các nhóm filter — mỗi nhóm là (label, predicate trên 1 row dict)
# row keys: cuisine, meal_size, meal_form, nutrition_profile, price_vnd, cal_cat
CATEGORIES = [
    ("Tất cả",     lambda r: True),
    ("Việt Nam",   lambda r: r.get("cuisine") == "vie"),
    ("Hàn Quốc",   lambda r: r.get("cuisine") == "kor"),
    ("Nhật Bản",   lambda r: r.get("cuisine") == "jpn"),
    ("Thái Lan",   lambda r: r.get("cuisine") == "tha"),
    ("Trung Quốc", lambda r: r.get("cuisine") == "chn"),
    ("Phương Tây", lambda r: r.get("cuisine") == "us"),
    ("Healthy",    lambda r: r.get("nutrition_profile") in ("vegetarian", "high_protein")),
    ("Diet",       lambda r: r.get("cal_cat") == "low"),
    ("Nhanh",      lambda r: r.get("meal_size") in ("snack", "light_meal")),
    ("Đồ ngọt",    lambda r: r.get("nutrition_profile") == "sweet"),
]

# Mapping nhãn nutrition → tag pill
NUTRITION_TAGS = {
    "vegetarian":   ("Thanh đạm",    GRN_MID),
    "high_protein": ("Nhiều đạm",    "#3873A8"),
    "normal":       ("Cân bằng",     GRN_MID),
    "greasy":       ("Đậm vị",       "#C56F2D"),
    "sweet":        ("Ngọt",         "#C2509C"),
}

CUISINE_NAME = {
    "vie": "Việt Nam", "kor": "Hàn Quốc", "jpn": "Nhật Bản",
    "tha": "Thái Lan", "chn": "Trung Quốc", "us":  "Phương Tây",
}

# Màu dot icon theo cuisine (dùng cho icon mini bên trái)
CUISINE_COLORS = {
    "vie": ["#E53E3E", "#F5C842"],
    "kor": ["#4A90D9", "#E53E3E"],
    "jpn": ["#E53E3E", "#FFFFFF"],
    "tha": ["#4A90D9", "#E53E3E"],
    "chn": ["#E53E3E", "#F5C842"],
    "us":  ["#4A90D9", "#F5C842"],
}


def _estimate_kcal(meal_size: str, cal_cat: str, nutrition: str) -> int:
    """Ước tính kcal y hệt backend/main.py để hiển thị nhất quán."""
    base = {
        ("snack",      "low"):    180, ("snack",      "medium"): 280, ("snack",      "high"):   420,
        ("light_meal", "low"):    320, ("light_meal", "medium"): 450, ("light_meal", "high"):   600,
        ("full_meal",  "low"):    480, ("full_meal",  "medium"): 650, ("full_meal",  "high"):   880,
    }.get((meal_size, cal_cat), 550)
    if nutrition == "greasy":       base = int(base * 1.10)
    elif nutrition == "vegetarian": base = int(base * 0.85)
    elif nutrition == "sweet":      base = int(base * 0.95)
    return base


class MenuTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=BG, corner_radius=0)
        self._after_ids   = []
        self._active_cat  = "Tất cả"
        self._search_text = ""
        self._all_foods   = self._load_foods_from_csv()
        self._list_container = None       # frame chứa danh sách (refresh khi đổi filter)
        self._build_ui()

    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def pack_forget(self):
        for aid in self._after_ids:
            try: self.after_cancel(aid)
            except Exception: pass
        self._after_ids.clear()
        super().pack_forget()

    # ─────────────────────────────────────────────────────────────────
    #  LOAD FOODS FROM CSV
    # ─────────────────────────────────────────────────────────────────
    def _load_foods_from_csv(self) -> list[dict]:
        """Load toàn bộ món từ food.csv, dedupe theo food_name, chuẩn hoá fields."""
        try:
            from backend.main import FOOD_DF
        except Exception as e:
            print(f"[MenuTab] Cannot load FOOD_DF: {e}")
            return []

        seen_names = set()
        items: list[dict] = []
        for _, row in FOOD_DF.iterrows():
            name = str(row.get("food_name", "")).strip()
            if not name or name in seen_names:
                continue
            seen_names.add(name)

            cuisine = str(row.get("cuisine", "vie")).strip().lower()
            meal_size = str(row.get("meal_size", "full_meal")).strip().lower()
            meal_form = str(row.get("meal_form", "dry")).strip().lower()
            nutrition = str(row.get("nutrition_profile", "normal")).strip().lower()
            cal_cat   = str(row.get("cal_cat", "medium")).strip().lower()
            price_vnd = int(row.get("price_vnd", 0) or 0)
            kcal_est  = _estimate_kcal(meal_size, cal_cat, nutrition)

            items.append({
                "food_name":         name,
                "shop_name":         str(row.get("shop_name", "")),
                "cuisine":           cuisine,
                "cuisine_country":   CUISINE_NAME.get(cuisine, cuisine.upper()),
                "meal_size":         meal_size,
                "meal_form":         meal_form,
                "nutrition_profile": nutrition,
                "cal_cat":           cal_cat,
                "price_vnd":         price_vnd,
                "price":             f"{price_vnd:,}đ",
                "kcal":              f"{kcal_est} kcal",
                "kcal_value":        kcal_est,
                "lat":               float(row.get("lat", 10.7769) or 10.7769),
                "lon":               float(row.get("lon", 106.7009) or 106.7009),
                "image_url":         str(row.get("image_url", "")),
                "dot_colors":        CUISINE_COLORS.get(cuisine, ["#4CAF85", "#1A3A2A"]),
            })

        # Sắp xếp: Việt Nam trước, sau đó theo cuisine, sau đó alpha theo tên
        cuisine_order = {"vie": 0, "kor": 1, "jpn": 2, "tha": 3, "chn": 4, "us": 5}
        items.sort(key=lambda x: (cuisine_order.get(x["cuisine"], 9), x["food_name"]))
        return items

    # ─────────────────────────────────────────────────────────────────
    #  BUILD UI
    # ─────────────────────────────────────────────────────────────────
    def _build_ui(self):
        topbar = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        topbar.pack(fill="x")
        self._topbar(topbar)

        self._scroll = ctk.CTkScrollableFrame(
            self, fg_color=BG,
            scrollbar_button_color="#D6CFBE",
            scrollbar_button_hover_color="#B8B0A0",
        )
        self._scroll.pack(fill="both", expand=True)

        self._taste_card(self._scroll)
        self._category_row(self._scroll)
        self._list_header(self._scroll)
        self._list_container = ctk.CTkFrame(self._scroll, fg_color="transparent")
        self._list_container.pack(fill="x")
        self._render_food_list()
        ctk.CTkFrame(self._scroll, fg_color="transparent", height=24).pack()

    # ── topbar (có search) ────────────────────────────────────────────
    def _topbar(self, parent):
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.pack(fill="x", padx=18, pady=(18, 8))
        left = ctk.CTkFrame(bar, fg_color="transparent")
        left.pack(side="left")
        ctk.CTkLabel(left, text="🍽", font=("Segoe UI Emoji", 18)).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(left, text="Khám phá món ăn",
                     font=("Segoe UI", 17, "bold"), text_color=GRN_DRK).pack(side="left")

        # Search box (ẩn ban đầu, toggle khi bấm 🔍)
        self._search_visible = False
        self._search_btn = ctk.CTkButton(
            bar, text="🔍", font=("Segoe UI Emoji", 15),
            width=36, height=36, corner_radius=18,
            fg_color=GRN_LIGHT, hover_color="#D0EAD8", text_color=GRN_DRK,
            command=self._toggle_search,
        )
        self._search_btn.pack(side="right")

        self._search_frame = ctk.CTkFrame(self, fg_color="transparent")
        self._search_entry = ctk.CTkEntry(
            self._search_frame, placeholder_text="Tìm món, quán, ẩm thực...",
            font=("Segoe UI", 12), height=36, corner_radius=18,
            fg_color=WHITE, border_color="#DDDDDD",
        )
        self._search_entry.pack(fill="x", padx=18, pady=(0, 8))
        self._search_entry.bind("<KeyRelease>", self._on_search)
        # mặc định ẩn

    def _toggle_search(self):
        if self._search_visible:
            self._search_frame.pack_forget()
            self._search_entry.delete(0, "end")
            self._search_text = ""
            self._render_food_list()
        else:
            # Đặt search frame ngay sau topbar (trước scroll)
            self._search_frame.pack(fill="x", before=self._scroll)
            self._search_entry.focus_set()
        self._search_visible = not self._search_visible

    def _on_search(self, _evt=None):
        self._search_text = self._search_entry.get().strip().lower()
        self._render_food_list()

    # ── taste card (giữ nguyên) ───────────────────────────────────────
    def _taste_card(self, parent):
        card = ctk.CTkFrame(parent, fg_color=GRN_DRK, corner_radius=20)
        card.pack(fill="x", padx=16, pady=(0, 6))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=(14, 8))

        hdr = ctk.CTkFrame(inner, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 8))
        star_bg = ctk.CTkFrame(hdr, fg_color=GRN_MID, width=24, height=24, corner_radius=12)
        star_bg.pack(side="left", padx=(0, 8))
        star_bg.pack_propagate(False)
        ctk.CTkLabel(star_bg, text="✦", font=("Segoe UI", 10, "bold"),
                     text_color=WHITE).place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(hdr, text="KHẨU VỊ ĐÃ HỌC",
                     font=("Segoe UI", 9, "bold"), text_color=GRN_ACT).pack(side="left")

        sub = ctk.CTkFrame(inner, fg_color="transparent")
        sub.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(sub, text="Bạn thích món ",
                     font=("Segoe UI", 14, "bold"), text_color=WHITE).pack(side="left")
        ctk.CTkLabel(sub, text="nước, ít chiên",
                     font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold", slant="italic"),
                     text_color=GRN_ACT).pack(side="left")

        for label, val, color in TASTE_PROFILE:
            self._bar_row(inner, label, val, color)

        note = ctk.CTkFrame(card, fg_color="#152E1E", corner_radius=12)
        note.pack(fill="x", pady=(6, 0))
        ctk.CTkLabel(note,
                     text="✓  Đã điều chỉnh trọng số luật mờ từ 14 đơn gần nhất",
                     font=("Segoe UI", 9), text_color=GRN_ACT, pady=8).pack()

    def _bar_row(self, parent, label, val, color):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=3)
        ctk.CTkLabel(row, text=label, font=("Segoe UI", 10),
                     text_color="#A8C8B0", width=68, anchor="w").pack(side="left")
        bar_bg = ctk.CTkFrame(row, fg_color="#2A4A38", height=8, corner_radius=4)
        bar_bg.pack(side="left", fill="x", expand=True, padx=(6, 10))
        bar_bg.pack_propagate(False)
        ctk.CTkFrame(bar_bg, fg_color=color, height=8, corner_radius=4
                     ).place(relx=0, rely=0, relwidth=val, relheight=1)
        ctk.CTkLabel(row, text=f"{int(val*100)}%", font=("Segoe UI", 10, "bold"),
                     text_color=WHITE, width=30, anchor="e").pack(side="left")

    # ── category pills (động theo CATEGORIES) ─────────────────────────
    def _category_row(self, parent):
        self._cat_scroll = ctk.CTkScrollableFrame(
            parent, orientation="horizontal", fg_color="transparent",
            height=48, scrollbar_button_color=BG,
        )
        self._cat_scroll.pack(fill="x", padx=16, pady=(14, 4))
        self._cat_btns = {}
        for cat, _pred in CATEGORIES:
            btn = ctk.CTkButton(
                self._cat_scroll, text=cat,
                font=("Segoe UI", 11, "bold"),
                height=32, corner_radius=16,
                command=lambda c=cat: self._select_cat(c),
            )
            btn.pack(side="left", padx=(0, 6))
            self._cat_btns[cat] = btn
        self._refresh_cats()

    def _select_cat(self, cat):
        self._active_cat = cat
        self._refresh_cats()
        self._render_food_list()
        # Scroll list về đầu
        try:
            self._scroll._parent_canvas.yview_moveto(0)
        except Exception:
            pass

    def _refresh_cats(self):
        for cat, btn in self._cat_btns.items():
            if cat == self._active_cat:
                btn.configure(fg_color=GRN_DRK, hover_color=GRN_MID,
                              text_color=WHITE, border_width=0)
            else:
                btn.configure(fg_color=WHITE, hover_color=GRN_LIGHT,
                              text_color=GRN_DRK, border_width=1,
                              border_color="#DDDDDD")

    # ── header bar ────────────────────────────────────────────────────
    def _list_header(self, parent):
        self._hdr_frame = ctk.CTkFrame(parent, fg_color="transparent")
        self._hdr_frame.pack(fill="x", padx=16, pady=(8, 6))
        self._hdr_label_left = ctk.CTkLabel(
            self._hdr_frame, text="TẤT CẢ MÓN ĂN",
            font=("Segoe UI", 10, "bold"), text_color="#8A9E8A", anchor="w")
        self._hdr_label_left.pack(side="left")
        self._hdr_label_right = ctk.CTkLabel(
            self._hdr_frame, text="",
            font=("Segoe UI", 10), text_color="#8A9E8A")
        self._hdr_label_right.pack(side="right")

    # ── food list (đầy đủ, scroll dài) ────────────────────────────────
    def _filtered_foods(self) -> list[dict]:
        pred = dict(CATEGORIES).get(self._active_cat, lambda r: True)
        items = [f for f in self._all_foods if pred(f)]
        if self._search_text:
            q = self._search_text
            items = [f for f in items
                     if q in f["food_name"].lower()
                     or q in f["shop_name"].lower()
                     or q in f["cuisine_country"].lower()]
        return items

    def _render_food_list(self):
        # Xoá danh sách cũ
        if self._list_container is None:
            return
        for w in self._list_container.winfo_children():
            try: w.destroy()
            except Exception: pass

        items = self._filtered_foods()

        # Update header text
        if self._active_cat == "Tất cả" and not self._search_text:
            self._hdr_label_left.configure(text="TẤT CẢ MÓN ĂN")
        elif self._search_text:
            self._hdr_label_left.configure(text=f"KẾT QUẢ TÌM KIẾM")
        else:
            self._hdr_label_left.configure(text=self._active_cat.upper())
        self._hdr_label_right.configure(text=f"{len(items)} món")

        if not items:
            empty = ctk.CTkFrame(self._list_container, fg_color="transparent")
            empty.pack(fill="x", padx=16, pady=(20, 20))
            ctk.CTkLabel(empty, text="🍽", font=("Segoe UI Emoji", 36),
                         text_color="#CCCCCC").pack()
            ctk.CTkLabel(empty, text="Không tìm thấy món nào",
                         font=("Segoe UI", 12), text_color="#8A9E8A").pack(pady=(8, 0))
            return

        for item in items:
            self._food_row(self._list_container, item)

    def _food_row(self, parent, item):
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18, cursor="hand2")
        card.pack(fill="x", padx=16, pady=(0, 8))
        card.bind("<Button-1>", lambda e, i=item: self._open_detail(i))

        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=12)
        inner.bind("<Button-1>", lambda e, i=item: self._open_detail(i))

        # ── Icon canvas (52×52) ────────────────────────────────────
        ICON = 52
        ic = tk.Canvas(inner, width=ICON, height=ICON,
                       bg=WHITE, highlightthickness=0, bd=0)
        ic.pack(side="left", padx=(0, 12))
        ic.bind("<Button-1>", lambda e, i=item: self._open_detail(i))
        self._draw_food_icon_simple(ic, ICON, item)

        # ── Info column ────────────────────────────────────────────
        info = ctk.CTkFrame(inner, fg_color="transparent")
        info.pack(side="left", fill="both", expand=True)
        info.bind("<Button-1>", lambda e, i=item: self._open_detail(i))

        # Tag pill (nutrition)
        nut = item["nutrition_profile"]
        tag_text, tag_color = NUTRITION_TAGS.get(nut, ("Món ăn", GRN_MID))
        tag_pill = ctk.CTkFrame(info, fg_color=GRN_LIGHT, corner_radius=8)
        tag_pill.pack(anchor="w", pady=(0, 3))
        ctk.CTkLabel(tag_pill, text=tag_text,
                     font=("Segoe UI", 8, "bold"), text_color=tag_color,
                     padx=7, pady=2).pack()

        # Tên món
        ctk.CTkLabel(info, text=item["food_name"],
                     font=("Segoe UI", 14, "bold"), text_color=GRN_DRK,
                     anchor="w", wraplength=210, justify="left").pack(fill="x")

        # Meta: cuisine · price · kcal
        meta = f"{item['cuisine_country']} · {item['price']} · {item['kcal']}"
        ctk.CTkLabel(info, text=meta,
                     font=("Segoe UI", 10), text_color="#8A9E8A",
                     anchor="w").pack(fill="x")

        # Shop (nhỏ, mờ)
        shop = item.get("shop_name", "")
        if shop:
            ctk.CTkLabel(info, text=f"🏪 {shop[:30]}",
                         font=("Segoe UI", 9), text_color="#AAAAAA",
                         anchor="w").pack(fill="x", pady=(1, 0))

        # Arrow
        ctk.CTkLabel(inner, text="›", font=("Segoe UI", 20, "bold"),
                     text_color="#CCCCCC").pack(side="right", padx=(8, 0))

    # ── icon vẽ tay (theo cuisine + nutrition) ────────────────────────
    def _draw_food_icon_simple(self, c, size, item):
        """Vẽ icon đơn giản: bát tròn nền pastel + 2 chấm màu cuisine + nutrition hint."""
        cx, cy = size / 2, size / 2

        # Nền tròn pastel theo cuisine
        pastel_map = {
            "vie": "#FCEBD8", "kor": "#FBE2EA", "jpn": "#FBE2E2",
            "tha": "#E8F4FE", "chn": "#FFF1D6", "us":  "#FFF8E0",
        }
        bg = pastel_map.get(item["cuisine"], "#EBF4EE")
        c.create_oval(2, 2, size-2, size-2, fill=bg, outline="")

        cols = item.get("dot_colors", ["#4CAF85", "#1A3A2A"])
        c1, c2 = cols[0], cols[1] if len(cols) > 1 else cols[0]

        # Hai chấm tròn lệch (gợi cảm giác món ăn)
        r = size / 2 - 4
        c.create_oval(cx - r*0.60, cy - r*0.20,
                      cx + r*0.15, cy + r*0.80, fill=c1, outline="")
        c.create_oval(cx - r*0.05, cy - r*0.65,
                      cx + r*0.65, cy + r*0.55, fill=c2, outline="")

        # Nutrition hint nhỏ: hình tam giác nhỏ phải trên
        nut = item["nutrition_profile"]
        hint_color = {
            "vegetarian":   "#4CAF85",
            "high_protein": "#3873A8",
            "greasy":       "#C56F2D",
            "sweet":        "#C2509C",
            "normal":       None,
        }.get(nut)
        if hint_color:
            c.create_oval(size-14, 2, size-2, 14,
                          fill=hint_color, outline=WHITE, width=1)

    # ── open detail ───────────────────────────────────────────────────
    def _open_detail(self, food_item):
        from tabs.food_detail_screen import FoodDetailScreen
        self.pack_forget()
        _ref = [None]

        def on_close():
            if _ref[0]:
                _ref[0].destroy()
                _ref[0] = None
            self.pack(fill="both", expand=True)

        # food_item đã có format đúng (food_name, shop_name, price, kcal, ...)
        # Bổ sung field mà food_detail_screen kỳ vọng
        nut = food_item["nutrition_profile"]
        tag_text, _ = NUTRITION_TAGS.get(nut, ("Món ăn", GRN_MID))
        food = dict(food_item)
        food.update({
            "match":   None,            # món duyệt, không có match%
            "flag":    {"vie":"🇻🇳","kor":"🇰🇷","jpn":"🇯🇵","tha":"🇹🇭",
                        "chn":"🇨🇳","us":"🇺🇸"}.get(food["cuisine"], "🍽"),
            "tags":    [food_item["cuisine_country"], tag_text,
                        {"snack":"Ăn vặt","light_meal":"Bữa nhẹ","full_meal":"Bữa chính"
                        }.get(food_item["meal_size"], "")],
            "reasons":     [],
            "ingredients": [],
            "actual_route_km": 0.0,
            "route_km": 0.0,
        })
        # Loại bỏ tags rỗng
        food["tags"] = [t for t in food["tags"] if t]

        d = FoodDetailScreen(self.master, food=food, on_close=on_close)
        _ref[0] = d
        d.pack(fill="both", expand=True)
