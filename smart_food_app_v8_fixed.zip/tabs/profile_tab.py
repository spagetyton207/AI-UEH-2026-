"""
Tab 3: Profile - Thông tin cá nhân và cài đặt
"""
import customtkinter as ctk
from utils.theme import COLORS, FONTS, SIZES
from utils.widgets import (
    GradientHeader, Card, PrimaryButton, SecondaryButton,
    SectionTitle, InfoRow
)


class ProfileTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=COLORS["bg_white"])

        self.create_ui()

    def create_ui(self):
        """Tạo giao diện tab profile"""
        # Header gradient với avatar
        self.create_profile_header()

        # Scrollable area
        self.scroll_frame = ctk.CTkScrollableFrame(
            self,
            fg_color=COLORS["bg_white"],
            scrollbar_button_color=COLORS["green_light"],
            scrollbar_button_hover_color=COLORS["green_secondary"]
        )
        self.scroll_frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        # Các section
        self.create_stats_section()
        self.create_info_section()
        self.create_preferences_section()
        self.create_settings_section()
        self.create_logout_section()

    def create_profile_header(self):
        """Header với avatar và tên"""
        self._header_draw_pending = False
        self._header_after_ids = []

        header_container = ctk.CTkFrame(
            self,
            fg_color=COLORS["green_primary"],
            height=180,
            corner_radius=0
        )
        header_container.pack(fill="x")
        header_container.pack_propagate(False)

        import tkinter as tk
        canvas = tk.Canvas(
            header_container,
            height=180,
            highlightthickness=0,
            bd=0
        )
        canvas.pack(fill="both", expand=True)

        def schedule_draw(event=None):
            if self._header_draw_pending:
                return
            self._header_draw_pending = True
            aid = self.after(16, lambda: self.draw_header_gradient(canvas))
            self._header_after_ids.append(aid)

        canvas.bind("<Configure>", schedule_draw)
        aid = self.after(10, lambda: self.draw_header_gradient(canvas))
        self._header_after_ids.append(aid)

        # Frame chứa avatar (đè lên canvas)
        avatar_frame = ctk.CTkFrame(
            self,
            fg_color="white",
            width=90,
            height=90,
            corner_radius=45,
            border_width=4,
            border_color="white"
        )
        avatar_frame.place(relx=0.5, y=30, anchor="n")
        avatar_frame.pack_propagate(False)

        avatar_label = ctk.CTkLabel(
            avatar_frame,
            text="👤",
            font=("Segoe UI Emoji", 40)
        )
        avatar_label.place(relx=0.5, rely=0.5, anchor="center")

        # Tên
        name_label = ctk.CTkLabel(
            self,
            text="Nguyễn Văn A",
            font=FONTS["title"],
            text_color="white",
            bg_color=COLORS["green_secondary"]
        )
        name_label.place(relx=0.5, y=125, anchor="n")

        # Email
        email_label = ctk.CTkLabel(
            self,
            text="vana.nguyen@example.com",
            font=FONTS["small"],
            text_color="white",
            bg_color=COLORS["green_secondary"]
        )
        email_label.place(relx=0.5, y=155, anchor="n")

    def draw_header_gradient(self, canvas):
        """
        Vẽ gradient cho header profile.
        FIX: 20 bước thay vì 100 (-80% canvas ops), không retry loop.
        """
        self._header_draw_pending = False
        canvas.delete("all")
        width = canvas.winfo_width()
        height = 180

        if width <= 1:
            # Không retry loop - Configure sẽ fire khi ready
            return

        # 20 bước đủ mịn cho mắt người
        STEPS = 20
        for i in range(STEPS):
            ratio = i / STEPS
            r1, g1, b1 = 0x2E, 0x8B, 0x57
            r2, g2, b2 = 0x66, 0xBB, 0x6A
            r = int(r1 + (r2 - r1) * ratio)
            g = int(g1 + (g2 - g1) * ratio)
            b = int(b1 + (b2 - b1) * ratio)
            color = f"#{r:02x}{g:02x}{b:02x}"
            x1 = int(width * i / STEPS)
            x2 = int(width * (i + 1) / STEPS)
            canvas.create_rectangle(x1, 0, x2, height, fill=color, outline=color)

    def create_stats_section(self):
        """Thống kê: số lần dùng, món yêu thích..."""
        stats_card = Card(self.scroll_frame)
        stats_card.pack(fill="x", pady=(16, 12))

        inner = ctk.CTkFrame(stats_card, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=12)

        # 3 cột stat
        inner.grid_columnconfigure(0, weight=1)
        inner.grid_columnconfigure(1, weight=1)
        inner.grid_columnconfigure(2, weight=1)

        stats = [
            ("42", "Lần dùng", "🍽️"),
            ("15", "Yêu thích", "❤️"),
            ("8", "Đặt hàng", "📦"),
        ]

        for i, (value, label, icon) in enumerate(stats):
            stat_frame = ctk.CTkFrame(inner, fg_color="transparent")
            stat_frame.grid(row=0, column=i, sticky="nsew", padx=4)

            icon_label = ctk.CTkLabel(
                stat_frame,
                text=icon,
                font=("Segoe UI Emoji", 20)
            )
            icon_label.pack()

            value_label = ctk.CTkLabel(
                stat_frame,
                text=value,
                font=FONTS["subtitle"],
                text_color=COLORS["green_primary"]
            )
            value_label.pack()

            text_label = ctk.CTkLabel(
                stat_frame,
                text=label,
                font=FONTS["small"],
                text_color=COLORS["text_gray"]
            )
            text_label.pack()

            # Đường kẻ phân cách (trừ cột cuối)
            if i < 2:
                separator = ctk.CTkFrame(
                    inner,
                    fg_color=COLORS["border_light"],
                    width=1,
                    height=60
                )
                separator.grid(row=0, column=i, sticky="e", padx=(0, 0))

    def create_info_section(self):
        """Section thông tin cá nhân"""
        title = SectionTitle(self.scroll_frame, text="ℹ️ Thông tin cá nhân")
        title.pack(fill="x", pady=(8, 8))

        info_card = Card(self.scroll_frame)
        info_card.pack(fill="x", pady=(0, 16))

        inner = ctk.CTkFrame(info_card, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=8)

        info_rows = [
            ("📞", "Số điện thoại", "0901 234 567"),
            ("📍", "Địa chỉ", "Quận 1, TP. HCM"),
            ("🎂", "Ngày sinh", "01/01/2000"),
            ("⚖️", "Cân nặng", "65 kg"),
            ("📏", "Chiều cao", "170 cm"),
        ]

        for i, (icon, label, value) in enumerate(info_rows):
            row = InfoRow(inner, label=label, value=value, icon=icon)
            row.pack(fill="x", pady=2)

            # Đường kẻ phân cách (trừ dòng cuối)
            if i < len(info_rows) - 1:
                sep = ctk.CTkFrame(
                    inner,
                    fg_color=COLORS["border_light"],
                    height=1
                )
                sep.pack(fill="x", padx=8)

    def create_preferences_section(self):
        """Section sở thích ẩm thực"""
        title = SectionTitle(self.scroll_frame, text="🍴 Sở thích ẩm thực")
        title.pack(fill="x", pady=(0, 8))

        pref_card = Card(self.scroll_frame)
        pref_card.pack(fill="x", pady=(0, 16))

        inner = ctk.CTkFrame(pref_card, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=12)

        # Label
        label = ctk.CTkLabel(
            inner,
            text="Loại ẩm thực yêu thích:",
            font=FONTS["body"],
            text_color=COLORS["text_medium"],
            anchor="w"
        )
        label.pack(fill="x", pady=(0, 8))

        # Các tag
        tags_frame = ctk.CTkFrame(inner, fg_color="transparent")
        tags_frame.pack(fill="x")

        tags = ["🇻🇳 Việt Nam", "🇯🇵 Nhật Bản", "🇰🇷 Hàn Quốc", "🥗 Healthy"]
        for tag in tags:
            tag_label = ctk.CTkLabel(
                tags_frame,
                text=tag,
                font=FONTS["small_bold"],
                text_color=COLORS["green_primary"],
                fg_color=COLORS["green_light"],
                corner_radius=SIZES["radius_xl"],
                padx=12,
                pady=4
            )
            tag_label.pack(side="left", padx=(0, 6), pady=2)

        # Mục tiêu sức khỏe
        health_label = ctk.CTkLabel(
            inner,
            text="Mục tiêu sức khỏe:",
            font=FONTS["body"],
            text_color=COLORS["text_medium"],
            anchor="w"
        )
        health_label.pack(fill="x", pady=(12, 8))

        health_tag = ctk.CTkLabel(
            inner,
            text="💪 Cân bằng dinh dưỡng",
            font=FONTS["small_bold"],
            text_color="white",
            fg_color=COLORS["green_primary"],
            corner_radius=SIZES["radius_xl"],
            padx=12,
            pady=6,
            anchor="w"
        )
        health_tag.pack(anchor="w")

    def create_settings_section(self):
        """Section cài đặt"""
        title = SectionTitle(self.scroll_frame, text="⚙️ Cài đặt")
        title.pack(fill="x", pady=(0, 8))

        settings_card = Card(self.scroll_frame)
        settings_card.pack(fill="x", pady=(0, 16))

        inner = ctk.CTkFrame(settings_card, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=8)

        settings = [
            ("🔔", "Thông báo", "Bật"),
            ("🌐", "Ngôn ngữ", "Tiếng Việt"),
            ("📍", "Vị trí", "Tự động"),
            ("🔒", "Bảo mật", "Đã bật"),
            ("ℹ️", "Về ứng dụng", "Version 1.0"),
        ]

        for i, (icon, label, value) in enumerate(settings):
            # Wrapper có hover effect
            wrapper = ctk.CTkFrame(inner, fg_color="transparent", cursor="hand2")
            wrapper.pack(fill="x")

            row = InfoRow(wrapper, label=label, value=value, icon=icon)
            row.pack(fill="x", pady=2)

            # Đường kẻ
            if i < len(settings) - 1:
                sep = ctk.CTkFrame(
                    inner,
                    fg_color=COLORS["border_light"],
                    height=1
                )
                sep.pack(fill="x", padx=8)

    def create_logout_section(self):
        """Section đăng xuất"""
        logout_btn = SecondaryButton(
            self.scroll_frame,
            text="🚪 Đăng xuất",
            command=self.on_logout
        )
        logout_btn.pack(fill="x", pady=(8, 16))

    def on_logout(self):
        """Xử lý đăng xuất"""
        print("Đăng xuất...")
