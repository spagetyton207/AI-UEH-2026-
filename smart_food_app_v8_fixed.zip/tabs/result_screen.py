"""
Result Screen - Nhận dữ liệu từ backend đã xử lý xong (qua LoadingScreen)
Không tự chạy loading nữa - suggest_wizard điều phối luồng.
"""
import customtkinter as ctk
import tkinter as tk
import threading

BG        = "#F5F0E8"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_LBL   = "#4A7A5A"
GRN_ACT   = "#6FCF97"
GRN_LIGHT = "#E8F4EE"
GRN_CARD  = "#1F4A32"
WHITE     = "#FFFFFF"
ORANGE    = "#F4845F"


def _match_color(pct):
    if pct >= 90: return "#1A3A2A"
    if pct >= 80: return GRN_MID
    return "#7FB794"


class ResultScreen(ctk.CTkFrame):
    """
    Tham số
    -------
    backend_result : dict từ get_recommendation_with_routing()
                     Nếu None → tự chạy backend (fallback).
    """
    def __init__(self, parent, on_back, on_home=None, on_order=None,
                 wizard_data=None, backend_result=None):
        super().__init__(parent, fg_color=BG, corner_radius=0)
        self.on_back  = on_back
        self.on_home  = on_home or on_back
        self.on_order = on_order or (lambda: None)
        self.wdata    = wizard_data or {}
        self._after_ids = []

        if backend_result is not None:
            self._results    = backend_result.get("results", [])
            self._weather    = backend_result.get("weather", {})
            self._ideal_dist = backend_result.get("ideal_distance", 0.0)
            self._fuzzy_out  = backend_result.get("fuzzy_outputs", {})
            self._rule_count = backend_result.get("rule_count", 51)
            self._build_ui_with_results()
        else:
            self._results = []; self._weather = {}
            self._ideal_dist = 0.0; self._fuzzy_out = {}
            self._rule_count = 51
            self._build_fallback_loading()
            threading.Thread(target=self._run_backend_fallback, daemon=True).start()

    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def _cancel_all_after(self):
        for aid in self._after_ids:
            try: self.after_cancel(aid)
            except Exception: pass
        self._after_ids.clear()

    def destroy(self):
        self._cancel_all_after()
        super().destroy()

    # ── fallback ───────────────────────────────────────────────────────
    def _run_backend_fallback(self):
        try:
            from backend.main import get_recommendation
            from backend.utils import get_user_location
            lat, lon = get_user_location()
            r = get_recommendation(
                user_lat=lat, user_lon=lon,
                user_time=float(self.wdata.get("wait", 30)),
                user_hunger=float(self.wdata.get("hunger", 7.0)),
                user_budget_vnd=float(self.wdata.get("budget", 120000)),
                user_health_str=self.wdata.get("goal", "Cân bằng"),
                city="Ho Chi Minh", top_n=40,
            )
            self._results = r["results"]; self._weather = r["weather"]
            self._ideal_dist = r["ideal_distance"]; self._fuzzy_out = r["fuzzy_outputs"]
            self._rule_count = r.get("rule_count", 51)
        except Exception as e:
            print(f"[Backend Fallback Error] {e}")
        self.after(0, self._on_fallback_done)

    def _on_fallback_done(self):
        try:
            for c in self.winfo_children(): c.destroy()
            self._build_ui_with_results()
        except Exception as e:
            print(f"[UI Error] {e}")

    def _build_fallback_loading(self):
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(12, 8))
        ctk.CTkButton(bar, text="⌂", font=("Segoe UI", 16, "bold"),
                      width=36, height=36, corner_radius=18,
                      fg_color="#EEEEEE", hover_color="#DDDDDD", text_color=GRN_DRK,
                      command=self.on_home).pack(side="left")
        ctk.CTkLabel(bar, text="Đang xử lý...",
                     font=("Segoe UI", 14, "bold"), text_color=GRN_LBL).pack(side="left", padx=12)
        c = ctk.CTkFrame(self, fg_color="transparent")
        c.pack(fill="both", expand=True)
        ctk.CTkLabel(c, text="🔍", font=("Segoe UI Emoji", 48)).pack(pady=(80, 16))
        ctk.CTkLabel(c, text="Đang tìm món ăn phù hợp...",
                     font=("Segoe UI", 16, "bold"), text_color=GRN_DRK).pack()

    # ── build results UI ───────────────────────────────────────────────
    def _build_ui_with_results(self):
        topbar_frame = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        topbar_frame.pack(fill="x")
        self._topbar(topbar_frame)

        scroll = ctk.CTkScrollableFrame(self, fg_color=BG,
                                         scrollbar_button_color="#D6CFBE",
                                         scrollbar_button_hover_color="#B8B0A0")
        scroll.pack(fill="both", expand=True)
        self._header(scroll)
        self._fuzzy_info_card(scroll)

        if not self._results:
            self._empty_state(scroll)
        else:
            self._top_pick_card(scroll, self._results[0])
            if len(self._results) > 1:
                self._other_picks_section(scroll, self._results[1:])

        ctk.CTkFrame(scroll, fg_color="transparent", height=24).pack()

    # ── topbar ─────────────────────────────────────────────────────────
    def _topbar(self, parent):
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(12, 8))
        ctk.CTkButton(bar, text="⌂", font=("Segoe UI", 16, "bold"),
                      width=36, height=36, corner_radius=18,
                      fg_color="#EEEEEE", hover_color="#DDDDDD", text_color=GRN_DRK,
                      command=self.on_home).pack(side="left")
        pill = ctk.CTkFrame(bar, fg_color="transparent")
        pill.pack(side="left", expand=True)
        info_row = ctk.CTkFrame(pill, fg_color=GRN_LIGHT, corner_radius=20)
        info_row.pack()
        ctk.CTkFrame(info_row, fg_color=GRN_MID, width=7, height=7,
                     corner_radius=4).pack(side="left", padx=(12, 4), pady=10)
        ctk.CTkLabel(info_row, text=f"{self._rule_count} LUẬT MỜ · {len(self._results)} MÓN PHÙ HỢP",
                     font=("Segoe UI", 10, "bold"), text_color=GRN_DRK,
                     padx=4).pack(side="left", pady=10)

    # ── header ──────────────────────────────────────────────────────────
    def _header(self, parent):
        import datetime
        f = ctk.CTkFrame(parent, fg_color="transparent")
        f.pack(fill="x", padx=20, pady=(14, 4))
        ctk.CTkLabel(f, text=f"GỢI Ý · {datetime.datetime.now().strftime('%H:%M')}",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A", anchor="w").pack(fill="x")
        title_row = ctk.CTkFrame(f, fg_color="transparent")
        title_row.pack(fill="x", pady=(6, 0))
        ctk.CTkLabel(title_row, text="Theo logic mờ, ",
                     font=("Georgia", 21, "bold"), text_color=GRN_DRK).pack(side="left")
        ctk.CTkLabel(title_row, text="nên ăn",
                     font=("Georgia", 21, "italic"), text_color=GRN_MID).pack(side="left")
        ctk.CTkLabel(f, text="những món này",
                     font=("Georgia", 21, "bold"), text_color=GRN_DRK, anchor="w").pack(fill="x")

    # ── fuzzy info card ─────────────────────────────────────────────────
    def _fuzzy_info_card(self, parent):
        temp  = self._weather.get('temperature', 33)
        rain  = self._weather.get('rainfall', 0)
        ideal = self._ideal_dist
        fo    = self._fuzzy_out

        if rain > 5:       wi, wd = "🌧", f"Mưa {rain:.1f}mm"
        elif temp >= 34:   wi, wd = "☀️", f"Nắng {temp:.0f}°C"
        elif temp < 24:    wi, wd = "❄", f"Mát {temp:.0f}°C"
        else:              wi, wd = "⛅", f"Dễ chịu {temp:.0f}°C"

        meal_lbl = {'snack': 'Ăn vặt 🍡', 'light_meal': 'Nhẹ 🥗',
                    'full_meal': 'Bữa chính 🍚'}.get(
                    fo.get('expected_meal_size', 'full_meal'), 'Bữa chính 🍚')
        cal_lbl  = {'low': 'Ít calo ⬇', 'medium': 'Vừa đủ ↔',
                    'high': 'Nhiều calo ⬆'}.get(fo.get('expected_cal', 'medium'), 'Vừa đủ ↔')

        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)
        ctk.CTkLabel(inner, text="ĐẦU RA FUZZY LOGIC",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(fill="x", pady=(0, 8))
        cols = ctk.CTkFrame(inner, fg_color="transparent")
        cols.pack(fill="x")
        for icon, val, lbl in [
            (wi, wd, "Thời tiết"),
            ("📍", f"{ideal:.1f} km", "Bán kính"),
            ("🍽", meal_lbl, "Loại bữa"),
            ("🔥", cal_lbl, "Calo"),
        ]:
            col = ctk.CTkFrame(cols, fg_color="transparent")
            col.pack(side="left", expand=True)
            ctk.CTkLabel(col, text=icon, font=("Segoe UI Emoji", 18)).pack()
            ctk.CTkLabel(col, text=val, font=("Segoe UI", 10, "bold"),
                         text_color=GRN_DRK, wraplength=85, justify="center").pack()
            ctk.CTkLabel(col, text=lbl, font=("Segoe UI", 8),
                         text_color="#AAAAAA").pack()

    # ── top pick card ────────────────────────────────────────────────────
    def _top_pick_card(self, parent, food):
        card = ctk.CTkFrame(parent, fg_color=GRN_DRK, corner_radius=24)
        card.pack(fill="x", padx=16, pady=(12, 8))

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=18, pady=(16, 4))
        badge = ctk.CTkFrame(hdr, fg_color="transparent")
        badge.pack(side="left")
        ctk.CTkLabel(badge, text="✦  TOP PICK",
                     font=("Segoe UI", 11, "bold"), text_color=GRN_ACT).pack(side="left")
        mr = ctk.CTkFrame(hdr, fg_color="transparent")
        mr.pack(side="right")
        ctk.CTkFrame(mr, fg_color=GRN_ACT, width=8, height=8,
                     corner_radius=4).pack(side="left", padx=(0, 5))
        ctk.CTkLabel(mr, text=f"{food['match']}% match",
                     font=("Segoe UI", 12, "bold"), text_color="white").pack(side="left")

        body = ctk.CTkFrame(card, fg_color="transparent")
        body.pack(fill="x", padx=18, pady=(4, 8))
        ic = tk.Canvas(body, width=70, height=70, bg=GRN_CARD, highlightthickness=0, bd=0)
        ic.pack(side="left", padx=(0, 14))
        self._track_after(60, lambda c=ic, cl=food.get("dot_colors",["#E53E3E","#4CAF85"]):
                          self._draw_food_icon(c, 70, cl))

        info = ctk.CTkFrame(body, fg_color="transparent")
        info.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(info, text=food["food_name"],
                     font=("Georgia", 19, "bold"), text_color="white",
                     anchor="w", wraplength=210).pack(fill="x")
        sub = ctk.CTkFrame(info, fg_color="transparent")
        sub.pack(fill="x")
        ctk.CTkLabel(sub, text=food.get("flag","🍽") + "  ",
                     font=("Segoe UI Emoji", 12)).pack(side="left")
        cuisine = food.get('cuisine_country','Vietnam')
        if food.get("meal_size"):
            cuisine += " · " + food["meal_size"].replace("_"," ").title()
        ctk.CTkLabel(sub, text=cuisine,
                     font=("Segoe UI", 11), text_color=GRN_ACT).pack(side="left")
        pr = ctk.CTkFrame(info, fg_color="transparent")
        pr.pack(fill="x", pady=(2,0))
        ctk.CTkLabel(pr, text=food["price"],
                     font=("Segoe UI", 12, "bold"), text_color="white").pack(side="left")
        ctk.CTkLabel(pr, text=f"  ·  {food['kcal']}  ·  📍{food.get('actual_route_km',0):.1f}km",
                     font=("Segoe UI", 11), text_color=GRN_ACT).pack(side="left")

        # Reasons
        why = ctk.CTkFrame(card, fg_color="transparent")
        why.pack(fill="x", padx=18, pady=(6, 6))
        ctk.CTkLabel(why, text="VÌ SAO HỢP VỚI BẠN",
                     font=("Segoe UI", 9, "bold"), text_color=GRN_ACT, anchor="w").pack(fill="x")
        tf = ctk.CTkFrame(card, fg_color="transparent")
        tf.pack(fill="x", padx=18, pady=(0, 12))
        r1 = ctk.CTkFrame(tf, fg_color="transparent"); r1.pack(fill="x", pady=(0,4))
        r2 = ctk.CTkFrame(tf, fg_color="transparent"); r2.pack(fill="x")
        for i, text in enumerate(food.get("reasons", [])[:4]):
            chip = ctk.CTkFrame([r1,r2][i//2], fg_color="#2E5240", corner_radius=14)
            chip.pack(side="left", padx=(0,6))
            ctk.CTkLabel(chip, text=f"✓  {str(text)[:22]}",
                         font=("Segoe UI", 10, "bold"), text_color=GRN_ACT,
                         padx=8, pady=5).pack()

        ctk.CTkLabel(card, text="🏪 " + food.get("shop_name",""),
                     font=("Segoe UI", 11), text_color=GRN_ACT,
                     anchor="w").pack(fill="x", padx=18, pady=(0,6))

        btns = ctk.CTkFrame(card, fg_color="transparent")
        btns.pack(fill="x", padx=16, pady=(4,18))
        ctk.CTkButton(btns, text="🍽  Xem chi tiết",
                      font=("Segoe UI", 14, "bold"), height=50, corner_radius=25,
                      fg_color=GRN_MID, hover_color="#1E6B42", text_color="white",
                      command=lambda f=food: self._open_detail(f),
                      ).pack(side="left", fill="x", expand=True, padx=(0,8))
        ctk.CTkButton(btns, text="🗺",
                      font=("Segoe UI", 18), height=50, width=50, corner_radius=25,
                      fg_color="#2E3D35", hover_color="#3A4D45", text_color="white",
                      command=lambda f=food: self._open_map_for(f),
                      ).pack(side="left", padx=(0,8))
        ctk.CTkButton(btns, text="✕",
                      font=("Segoe UI", 16, "bold"), height=50, width=50, corner_radius=25,
                      fg_color="#2E3D35", hover_color="#3A4D45", text_color="white",
                      command=self.on_back).pack(side="left")

    def _draw_food_icon(self, c, size, colors):
        try:
            if not c.winfo_ismapped(): return
        except Exception: return
        c.delete("all")
        cx, cy, r = size/2, size/2, size/2 - 2
        c1 = colors[0] if colors else "#E53E3E"
        c2 = colors[1] if len(colors) > 1 else "#4CAF85"
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill="#F5C842", outline="")
        c.create_oval(cx-r*.60, cy-r*.20, cx+r*.10, cy+r*.80, fill=c1, outline="")
        c.create_oval(cx-r*.05, cy-r*.55, cx+r*.55, cy+r*.55, fill=c2, outline="")

    # ── other picks ───────────────────────────────────────────────────────
    def _other_picks_section(self, parent, others):
        hdr = ctk.CTkFrame(parent, fg_color="transparent")
        hdr.pack(fill="x", padx=16, pady=(8, 4))
        ctk.CTkLabel(hdr, text="CÁC LỰA CHỌN KHÁC",
                     font=("Segoe UI", 10, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(side="left")
        for item in others:
            self._other_row(parent, item)

    def _other_row(self, parent, food):
        """Card với 2 nút rõ ràng: Chi tiết + Bản đồ – đảm bảo luôn click được."""
        outer = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        outer.pack(fill="x", padx=16, pady=(0, 8))

        inner = ctk.CTkFrame(outer, fg_color="transparent")
        inner.pack(fill="x", padx=14, pady=12)

        # ── icon
        ic = tk.Canvas(inner, width=52, height=52,
                       bg="#EBF4EE", highlightthickness=0, bd=0)
        ic.pack(side="left", padx=(0, 12))
        cl = food.get("dot_colors", [GRN_MID, GRN_DRK])
        self._track_after(80, lambda c=ic, colors=cl: self._draw_mini_icon(c, 52, colors))

        # ── text info
        info_col = ctk.CTkFrame(inner, fg_color="transparent")
        info_col.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(info_col, text=food["food_name"],
                     font=("Segoe UI", 14, "bold"), text_color=GRN_DRK,
                     anchor="w").pack(fill="x")
        meta_row = ctk.CTkFrame(info_col, fg_color="transparent")
        meta_row.pack(fill="x")
        ctk.CTkLabel(meta_row, text=food.get("flag","🍽"),
                     font=("Segoe UI Emoji", 11)).pack(side="left")
        dist = food.get("actual_route_km", 0)
        ctk.CTkLabel(meta_row,
                     text=f"  {food.get('cuisine_country','')} · {food['price']} · 📍{dist:.1f}km",
                     font=("Segoe UI", 11), text_color="#8A9E8A").pack(side="left")
        # match badge
        m_col = _match_color(food["match"])
        mbadge = ctk.CTkFrame(info_col, fg_color="transparent")
        mbadge.pack(anchor="w", pady=(4, 0))
        ctk.CTkFrame(mbadge, fg_color=m_col, width=7, height=7,
                     corner_radius=4).pack(side="left", padx=(0, 4))
        ctk.CTkLabel(mbadge, text=f"{food['match']}% phù hợp",
                     font=("Segoe UI", 11, "bold"), text_color=m_col).pack(side="left")

        # ── action buttons (luôn visible, luôn click được)
        btn_col = ctk.CTkFrame(inner, fg_color="transparent")
        btn_col.pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            btn_col, text="Chi tiết",
            font=("Segoe UI", 11, "bold"), height=36, width=80, corner_radius=18,
            fg_color=GRN_DRK, hover_color=GRN_MID, text_color=WHITE,
            command=lambda f=food: self._open_detail(f),
        ).pack(pady=(0, 6))
        ctk.CTkButton(
            btn_col, text="🗺 Bản đồ",
            font=("Segoe UI", 10, "bold"), height=30, width=80, corner_radius=15,
            fg_color=GRN_LIGHT, hover_color="#D0EAD8", text_color=GRN_DRK,
            command=lambda f=food: self._open_map_for(f),
        ).pack()

    def _draw_mini_icon(self, c, size, colors):
        try:
            if not c.winfo_ismapped(): return
        except Exception: return
        c.delete("all")
        cx, cy, r = size/2, size/2, size/2 - 2
        c1 = colors[0] if colors else GRN_MID
        c2 = colors[1] if len(colors) > 1 else GRN_DRK
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill="#EBF4EE", outline="")
        c.create_oval(cx-r*.5, cy-r*.5, cx+r*.5, cy+r*.5, fill=c1, outline="")
        c.create_oval(cx-r*.2, cy+r*.05, cx+r*.5, cy+r*.65, fill=c2, outline="")

    # ── empty state ──────────────────────────────────────────────────────
    def _empty_state(self, parent):
        f = ctk.CTkFrame(parent, fg_color="transparent")
        f.pack(fill="both", expand=True, pady=20)
        ctk.CTkLabel(f, text="🔍", font=("Segoe UI Emoji", 44)).pack(pady=(20, 8))
        ctk.CTkLabel(f, text="Chưa tìm thấy món phù hợp",
                     font=("Segoe UI", 15, "bold"), text_color=GRN_DRK).pack()

        # Hiện gợi ý cụ thể
        budget = self.wdata.get("budget", 0)
        hunger = self.wdata.get("hunger", 5)
        hints = []
        if budget < 50000:
            hints.append(f"• Ngân sách {budget:,}đ quá thấp – thử từ 50,000đ trở lên")
        if hunger < 3:
            hints.append("• Độ đói thấp → thử chọn mục tiêu 'Ăn nhẹ' hoặc tăng độ đói")

        if hints:
            hint_frame = ctk.CTkFrame(f, fg_color=GRN_LIGHT, corner_radius=14)
            hint_frame.pack(padx=24, pady=(12, 4), fill="x")
            for hint in hints:
                ctk.CTkLabel(hint_frame, text=hint, font=("Segoe UI", 11),
                             text_color=GRN_DRK, anchor="w",
                             wraplength=300).pack(padx=14, pady=3, anchor="w")
        else:
            ctk.CTkLabel(f, text="Thử điều chỉnh ngân sách hoặc thời gian chờ",
                         font=("Segoe UI", 11), text_color=GRN_LBL).pack(pady=(6, 0))

        ctk.CTkButton(f, text="← Thay đổi & thử lại",
                      font=("Segoe UI", 14, "bold"), height=48, corner_radius=24,
                      fg_color=GRN_DRK, hover_color=GRN_MID, text_color=WHITE,
                      command=self.on_back).pack(pady=16, padx=32, fill="x")

    # ── navigate to detail ───────────────────────────────────────────────
    def _open_detail(self, food):
        from tabs.food_detail_screen import FoodDetailScreen
        self.pack_forget()
        _ref = [None]

        def on_close():
            if _ref[0]: _ref[0].destroy(); _ref[0] = None
            self.pack(fill="both", expand=True)

        d = FoodDetailScreen(self.master, food=food, on_close=on_close,
                             all_results=self._results, weather=self._weather,
                             ideal_distance=self._ideal_dist)
        _ref[0] = d
        d.pack(fill="both", expand=True)

    # ── navigate to map ──────────────────────────────────────────────────
    def _open_map_for(self, focused_food):
        from tabs.map_screen import MapScreen
        self.pack_forget()
        _ref = [None]

        def on_close():
            if _ref[0]: _ref[0].destroy(); _ref[0] = None
            self.pack(fill="both", expand=True)

        m = MapScreen(self.master, on_close=on_close,
                      results=self._results, focused_food=focused_food)
        _ref[0] = m
        m.pack(fill="both", expand=True)
