"""
Loading Screen - Màn hình chờ "Đang suy diễn"
Hiển thị 3 giây với animation phần trăm matching và bảng luật mờ
"""
import customtkinter as ctk
import tkinter as tk
import math

BG_DARK   = "#0D2B1A"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_BRIGHT= "#3CB371"
GRN_ACT   = "#6FCF97"
GRN_GLOW  = "#4CAF85"
GRN_PANEL = "#152E1E"
GRN_ROW   = "#1A3828"
WHITE     = "#FFFFFF"
TEXT_DIM  = "#7AAB8A"

RULES = [
    ("R3",  "IF mưa lớn → ưu tiên quán\ngần (nearby)",         0.85),
    ("R8",  "IF Diet AND đói cao → bữa\ncalo medium, đạm cao", 0.72),
    ("R12", "IF time ngắn → giảm meal size\n1 cấp (nhanh)",    0.68),
    ("R17", "IF nóng AND không greasy →\nưu tiên món thanh nhiệt", 0.74),
]

TOTAL_MS   = 3000   # tổng thời gian loading
TICK_MS    = 30     # interval update
N_TICKS    = TOTAL_MS // TICK_MS


class LoadingScreen(ctk.CTkFrame):
    """
    Tham số
    -------
    parent   : widget cha
    on_done  : callback gọi sau khi load xong (chuyển sang ResultScreen)
    """

    def __init__(self, parent, on_done):
        super().__init__(parent, fg_color=BG_DARK, corner_radius=0)
        self.on_done   = on_done
        self._after_ids = []
        self._tick      = 0
        self._rule_shown = [False] * len(RULES)
        self._build_ui()
        self._start_animation()

    # ── after helpers ──────────────────────────────────────────────────
    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def _cancel_all_after(self):
        for aid in self._after_ids:
            try:
                self.after_cancel(aid)
            except Exception:
                pass
        self._after_ids.clear()

    def destroy(self):
        self._cancel_all_after()
        super().destroy()

    # ── build UI ──────────────────────────────────────────────────────
    def _build_ui(self):
        # ── top section (dark bg, bubble + text)
        self.top_frame = ctk.CTkFrame(self, fg_color=BG_DARK, corner_radius=0)
        self.top_frame.pack(fill="both", expand=True)

        # status pill
        pill = ctk.CTkFrame(self.top_frame, fg_color="transparent")
        pill.pack(anchor="w", padx=22, pady=(28, 0))
        dot = ctk.CTkFrame(pill, fg_color=GRN_ACT, width=8, height=8, corner_radius=4)
        dot.pack(side="left", pady=1)
        ctk.CTkLabel(pill, text="  ĐANG SUY DIỄN",
                     font=("Segoe UI", 10, "bold"), text_color=GRN_ACT).pack(side="left")

        # headline
        title_f = ctk.CTkFrame(self.top_frame, fg_color="transparent")
        title_f.pack(anchor="w", padx=22, pady=(14, 0))
        ctk.CTkLabel(title_f, text="Đang cân nhắc",
                     font=("Georgia", 26, "bold"), text_color=WHITE,
                     anchor="w").pack(fill="x")
        count_row = ctk.CTkFrame(title_f, fg_color="transparent")
        count_row.pack(fill="x")
        self.count_lbl = ctk.CTkLabel(count_row, text="23 món",
                     font=ctk.CTkFont(family="Georgia", size=26, weight="bold", slant="italic"), text_color=GRN_ACT)
        self.count_lbl.pack(side="left")
        ctk.CTkLabel(count_row, text=" phù hợp",
                     font=("Georgia", 26, "bold"), text_color=WHITE).pack(side="left")
        ctk.CTkLabel(title_f, text="với bạn",
                     font=("Georgia", 26, "bold"), text_color=WHITE,
                     anchor="w").pack(fill="x")

        # canvas for bubble + % ring
        self.bubble_cv = tk.Canvas(self.top_frame, height=210,
                                   bg=BG_DARK, highlightthickness=0, bd=0)
        self.bubble_cv.pack(fill="x", pady=(18, 0))
        self.bubble_cv.bind("<Configure>", self._on_bubble_configure)
        self._bubble_pending = False

        # ── bottom panel (translucent dark card)
        self.panel = ctk.CTkFrame(self, fg_color=GRN_PANEL, corner_radius=0)
        self.panel.pack(fill="x", side="bottom")

        panel_inner = ctk.CTkFrame(self.panel, fg_color="transparent")
        panel_inner.pack(fill="x", padx=18, pady=(14, 6))

        hdr = ctk.CTkFrame(panel_inner, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(hdr, text="LUẬT MỜ ĐANG KÍCH HOẠT",
                     font=("Segoe UI", 9, "bold"), text_color=TEXT_DIM,
                     anchor="w").pack(side="left")
        self.rule_count_lbl = ctk.CTkLabel(hdr, text="0 Luật",
                     font=("Segoe UI", 9, "bold"), text_color=TEXT_DIM)
        self.rule_count_lbl.pack(side="right")

        # rule rows (hidden initially)
        self.rule_rows = []
        for tag, desc, val in RULES:
            row = self._make_rule_row(panel_inner, tag, desc, val)
            row.pack(fill="x", pady=2)
            row._bar_val = val
            row._bar_fill = None
            self.rule_rows.append(row)
            row.pack_forget()   # ẩn cho đến khi animate

        # footer pipeline text
        self.footer_lbl = ctk.CTkLabel(
            self.panel,
            text="fuzzifying  →  inferencing  →  defuzzifying",
            font=("Courier", 10), text_color=TEXT_DIM,
        )
        self.footer_lbl.pack(pady=(4, 14))

        self._pct = 0.0  # 0..100

    def _make_rule_row(self, parent, tag, desc, val):
        row = ctk.CTkFrame(parent, fg_color=GRN_ROW, corner_radius=8)
        inner = ctk.CTkFrame(row, fg_color="transparent")
        inner.pack(fill="x", padx=10, pady=7)

        # tag badge
        badge = ctk.CTkFrame(inner, fg_color=GRN_MID, width=32, height=20, corner_radius=4)
        badge.pack(side="left", padx=(0, 8))
        badge.pack_propagate(False)
        ctk.CTkLabel(badge, text=tag, font=("Segoe UI", 8, "bold"),
                     text_color=WHITE).place(relx=0.5, rely=0.5, anchor="center")

        # description
        ctk.CTkLabel(inner, text=desc, font=("Segoe UI", 9), text_color=GRN_ACT,
                     anchor="w", justify="left", wraplength=190).pack(side="left", fill="x", expand=True)

        # bar + value
        right = ctk.CTkFrame(inner, fg_color="transparent")
        right.pack(side="right", padx=(6, 0))

        bar_bg = ctk.CTkFrame(right, fg_color="#0D2B1A", width=60, height=6, corner_radius=3)
        bar_bg.pack(side="left")
        bar_bg.pack_propagate(False)
        bar_fill = ctk.CTkFrame(bar_bg, fg_color=GRN_BRIGHT, height=6, corner_radius=3)
        bar_fill.place(relx=0, rely=0, relwidth=0.0, relheight=1)
        row._bar_fill_widget = bar_fill

        ctk.CTkLabel(right, text=f"  {val:.2f}",
                     font=("Segoe UI", 10, "bold"), text_color=WHITE).pack(side="left")
        return row

    # ── animation ─────────────────────────────────────────────────────
    def _start_animation(self):
        self._tick = 0
        self._track_after(TICK_MS, self._tick_update)

    def _tick_update(self):
        self._tick += 1
        progress = min(self._tick / N_TICKS, 1.0)

        # eased progress (ease-out cubic)
        p = 1 - (1 - progress) ** 3

        # update % counter (counts 0 → 72)
        target_pct = 72.0
        self._pct = p * target_pct
        self._redraw_bubble()

        # reveal rules progressively
        reveal_at = [0.20, 0.38, 0.56, 0.74]
        active_count = 0
        for i, threshold in enumerate(reveal_at):
            if progress >= threshold and not self._rule_shown[i]:
                self._rule_shown[i] = True
                self.rule_rows[i].pack(fill="x", pady=2)
                # animate bar fill
                self._animate_bar(self.rule_rows[i], RULES[i][2])
            if self._rule_shown[i]:
                active_count += 1
        self.rule_count_lbl.configure(text=f"{active_count} Luật")

        # footer pipeline animation
        dots = "." * (self._tick % 4)
        stage_idx = int(progress * 2.99)
        stages = ["fuzzifying", "inferencing", "defuzzifying"]
        pipeline = "  →  ".join(
            f"[{s}]{dots}" if j == stage_idx else s
            for j, s in enumerate(stages)
        )
        elapsed = self._tick * TICK_MS / 1000
        self.footer_lbl.configure(text=f"{pipeline}  = {elapsed:.1f}s")

        if progress < 1.0:
            self._track_after(TICK_MS, self._tick_update)
        else:
            # Done – call on_done after tiny pause
            self._track_after(200, self.on_done)

    def _animate_bar(self, row, target_val, step=0, steps=20):
        """Animate bar fill from 0 → target_val over `steps` frames."""
        frac = target_val * (step / steps)
        try:
            row._bar_fill_widget.place(relwidth=frac)
        except Exception:
            return
        if step < steps:
            self._track_after(20, lambda: self._animate_bar(row, target_val, step + 1, steps))

    # ── bubble canvas ──────────────────────────────────────────────────
    def _on_bubble_configure(self, event=None):
        if self._bubble_pending:
            return
        self._bubble_pending = True
        self._track_after(16, self._redraw_bubble)

    def _redraw_bubble(self):
        self._bubble_pending = False
        c = self.bubble_cv
        try:
            if not c.winfo_ismapped():
                return
        except Exception:
            return
        w = c.winfo_width()
        h = c.winfo_height()
        if w < 10:
            return
        c.delete("all")

        # ── big decorative blob (bottom-centre)
        bx, by = w * 0.50, h * 0.90
        br = w * 0.55
        c.create_oval(bx - br, by - br, bx + br, by + br,
                      fill="#1A4A2A", outline="")

        # ── glow ring (light green big circle)
        gx, gy = w * 0.50, h * 0.52
        gr = 80
        # outer soft ring
        c.create_oval(gx - gr - 16, gy - gr - 16, gx + gr + 16, gy + gr + 16,
                      fill="#1F5C38", outline="")
        # inner bright circle
        c.create_oval(gx - gr, gy - gr, gx + gr, gy + gr,
                      fill=GRN_GLOW, outline="")

        # ── water-drop icon (white)
        self._draw_drop(c, gx, gy - 14, 22, WHITE)

        # ── % text
        pct_int = int(self._pct)
        c.create_text(gx, gy + 24,
                      text=f"{pct_int}%",
                      font=("Georgia", 28, "bold"),
                      fill=WHITE, anchor="center")
        c.create_text(gx, gy + 52,
                      text="MATCHING",
                      font=("Segoe UI", 9, "bold"),
                      fill=GRN_ACT, anchor="center")

        # ── arc progress ring (clockwise from top)
        arc_r = gr + 8
        start = 90
        extent = -(self._pct / 100) * 360
        c.create_arc(gx - arc_r, gy - arc_r, gx + arc_r, gy + arc_r,
                     start=start, extent=extent,
                     style="arc", outline=GRN_ACT, width=3)

        # ── tiny decorative dots scattered around
        dots = [
            (w * 0.12, h * 0.35, 3),
            (w * 0.85, h * 0.22, 4),
            (w * 0.78, h * 0.68, 2),
            (w * 0.22, h * 0.72, 2),
            (w * 0.92, h * 0.50, 3),
        ]
        for dx, dy, dr in dots:
            c.create_oval(dx - dr, dy - dr, dx + dr, dy + dr,
                          fill="#2E6B47", outline="")

    def _draw_drop(self, c, cx, cy, size, color):
        """Vẽ hình giọt nước (water drop) bằng polygon + oval."""
        # body oval
        c.create_oval(cx - size * 0.55, cy, cx + size * 0.55, cy + size * 1.1,
                      fill=color, outline="")
        # top triangle tip
        pts = [
            cx, cy - size * 0.85,
            cx - size * 0.55, cy + size * 0.15,
            cx + size * 0.55, cy + size * 0.15,
        ]
        c.create_polygon(pts, fill=color, outline="")
