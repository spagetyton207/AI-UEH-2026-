"""
Food Detail Screen - Chi tiết món ăn với dữ liệu thực từ backend
"""
import customtkinter as ctk
import tkinter as tk

BG        = "#F5F0E8"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_ACT   = "#6FCF97"
GRN_LIGHT = "#E8F4EE"
GRN_CARD  = "#1F4A32"
WHITE     = "#FFFFFF"
ORANGE    = "#F4845F"


class FoodDetailScreen(ctk.CTkFrame):
    DEFAULT_FOOD = {
        "food_name":    "Món ăn",
        "shop_name":    "Quán ăn",
        "cuisine":      "vie",
        "cuisine_country": "Vietnam",
        "price":        "--",
        "kcal":         "-- kcal",
        "match":        80,
        "actual_route_km": 0.0,
        "lat":          10.762622,
        "lon":          106.660172,
        "reasons":      [],
        "ingredients":  [],
        "tags":         [],
        "dot_colors":   ["#E53E3E", "#4CAF85"],
        "flag":         "🍽",
        "meal_size":    "",
        "meal_form":    "",
    }

    def __init__(self, parent, food=None, on_close=None,
                 all_results=None, weather=None, ideal_distance=0.0):
        super().__init__(parent, fg_color=BG, corner_radius=0)
        raw = {**self.DEFAULT_FOOD, **(food or {})}
        # Chuẩn hoá reasons (có thể là list[str] hoặc list[tuple])
        raw["reasons"] = [
            r[0] if isinstance(r, (list, tuple)) else r
            for r in raw.get("reasons", [])
        ]
        # Compat: name → food_name (từ result_screen cũ)
        if "name" in raw and "food_name" not in food:
            raw["food_name"] = raw["name"]
        if "shop" in raw and "shop_name" not in food:
            raw["shop_name"] = raw["shop"]

        self.food           = raw
        self.on_close       = on_close or (lambda: None)
        self.all_results    = all_results or []
        self.weather        = weather or {}
        self.ideal_distance = ideal_distance
        self._after_ids     = []
        self._build_ui()

    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def _cancel_all_after(self):
        for aid in self._after_ids:
            try: self.after_cancel(aid)
            except Exception: pass
        self._after_ids.clear()

    def destroy(self):
        self._cancel_all_after()
        super().destroy()

    # ── build ──────────────────────────────────────────────────────────
    def _build_ui(self):
        topbar = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        topbar.pack(fill="x")
        self._topbar(topbar)

        scroll = ctk.CTkScrollableFrame(
            self, fg_color=BG,
            scrollbar_button_color="#D6CFBE",
            scrollbar_button_hover_color="#B8B0A0",
        )
        scroll.pack(fill="both", expand=True)

        self._hero_card(scroll)
        self._stats_row(scroll)
        self._reasons_section(scroll)
        self._ingredients_section(scroll)
        self._tags_section(scroll)
        self._fuzzy_explanation(scroll)
        self._map_button(scroll)
        ctk.CTkFrame(scroll, fg_color="transparent", height=28).pack()

    # ── topbar ─────────────────────────────────────────────────────────
    def _topbar(self, parent):
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(14, 10))
        ctk.CTkButton(
            bar, text="←", font=("Segoe UI", 16, "bold"),
            width=36, height=36, corner_radius=18,
            fg_color="#EEEEEE", hover_color="#DDDDDD", text_color=GRN_DRK,
            command=self.on_close,
        ).pack(side="left")
        ctk.CTkLabel(bar, text="Chi tiết món ăn",
                     font=("Segoe UI", 16, "bold"), text_color=GRN_DRK,
                     ).pack(side="left", padx=14)
        if self.food.get("match"):
            pill = ctk.CTkFrame(bar, fg_color=GRN_LIGHT, corner_radius=16)
            pill.pack(side="right")
            dot = ctk.CTkFrame(pill, fg_color=GRN_MID, width=7, height=7, corner_radius=4)
            dot.pack(side="left", padx=(10, 4), pady=8)
            ctk.CTkLabel(pill, text=f"{self.food['match']}% phù hợp",
                         font=("Segoe UI", 10, "bold"), text_color=GRN_DRK,
                         padx=8).pack(side="left", pady=8)

    # ── hero card ───────────────────────────────────────────────────────
    def _hero_card(self, parent):
        f = self.food
        card = ctk.CTkFrame(parent, fg_color=GRN_DRK, corner_radius=22)
        card.pack(fill="x", padx=16, pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=18, pady=(18, 18))

        ic_size = 74
        ic = tk.Canvas(inner, width=ic_size, height=ic_size,
                       bg=GRN_CARD, highlightthickness=0, bd=0)
        ic.pack(side="left", padx=(0, 16))
        self._track_after(60, lambda: self._draw_icon(ic, ic_size))

        info = ctk.CTkFrame(inner, fg_color="transparent")
        info.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(info, text=f.get("food_name", ""),
                     font=("Georgia", 20, "bold"), text_color=WHITE,
                     anchor="w", wraplength=210, justify="left").pack(fill="x")
        sub_row = ctk.CTkFrame(info, fg_color="transparent")
        sub_row.pack(fill="x", pady=(4, 0))
        ctk.CTkLabel(sub_row, text=f.get("flag", "🍽") + "  ",
                     font=("Segoe UI Emoji", 12)).pack(side="left")
        cuisine_disp = f.get("cuisine_country", "Vietnam")
        if f.get("meal_size"):
            cuisine_disp += " · " + f["meal_size"].replace("_", " ").title()
        ctk.CTkLabel(sub_row, text=cuisine_disp,
                     font=("Segoe UI", 12), text_color=GRN_ACT, anchor="w").pack(side="left")
        # Quán
        shop = f.get("shop_name", "")
        if shop:
            ctk.CTkLabel(info, text="🏪 " + shop,
                         font=("Segoe UI", 11), text_color=GRN_ACT, anchor="w").pack(fill="x", pady=(2, 0))

    # ── stats row ───────────────────────────────────────────────────────
    def _stats_row(self, parent):
        f = self.food
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=8, pady=14)
        dist_str = f"{f.get('actual_route_km', 0):.1f} km"
        stats = [
            ("💰", f.get("price",  "--"),  "Giá"),
            ("🔥", f.get("kcal",   "--"),  "Năng lượng"),
            ("📍", dist_str,               "Khoảng cách"),
            ("🏪", f.get("shop_name", "--").split(" · ")[0][:10], "Quán"),
        ]
        for i, (icon, val, label) in enumerate(stats):
            col = ctk.CTkFrame(inner, fg_color="transparent")
            col.pack(side="left", expand=True)
            ctk.CTkLabel(col, text=icon, font=("Segoe UI Emoji", 20)).pack(pady=(0, 4))
            ctk.CTkLabel(col, text=val, font=("Segoe UI", 13, "bold"),
                         text_color=GRN_DRK).pack()
            ctk.CTkLabel(col, text=label, font=("Segoe UI", 9),
                         text_color="#AAAAAA").pack()
            if i < 3:
                ctk.CTkFrame(inner, fg_color="#EEEEEE", width=1
                             ).pack(side="left", fill="y", padx=2, pady=10)

    # ── reasons ─────────────────────────────────────────────────────────
    def _reasons_section(self, parent):
        reasons = self.food.get("reasons", [])
        if not reasons:
            return
        ctk.CTkLabel(parent, text="VÌ SAO HỢP VỚI BẠN",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(fill="x", padx=20, pady=(0, 8))
        wrap = ctk.CTkFrame(parent, fg_color="transparent")
        wrap.pack(fill="x", padx=16, pady=(0, 10))
        row = None
        for i, text in enumerate(reasons):
            if i % 2 == 0:
                row = ctk.CTkFrame(wrap, fg_color="transparent")
                row.pack(fill="x", pady=(0, 6))
            chip = ctk.CTkFrame(row, fg_color=GRN_LIGHT, corner_radius=14)
            chip.pack(side="left", padx=(0, 6))
            short = str(text)[:28]
            ctk.CTkLabel(chip, text=f"✓  {short}",
                         font=("Segoe UI", 10, "bold"), text_color=GRN_MID,
                         padx=10, pady=6).pack()

    # ── ingredients ─────────────────────────────────────────────────────
    def _ingredients_section(self, parent):
        items = self.food.get("ingredients", [])
        if not items:
            return
        ctk.CTkLabel(parent, text="NGUYÊN LIỆU",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(fill="x", padx=20, pady=(0, 8))
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=12)
        col_a = ctk.CTkFrame(inner, fg_color="transparent")
        col_a.pack(side="left", fill="both", expand=True)
        col_b = ctk.CTkFrame(inner, fg_color="transparent")
        col_b.pack(side="left", fill="both", expand=True)
        cols = [col_a, col_b]
        for i, item in enumerate(items):
            row = ctk.CTkFrame(cols[i % 2], fg_color="transparent")
            row.pack(fill="x", pady=4)
            dot = ctk.CTkFrame(row, fg_color=GRN_MID, width=6, height=6, corner_radius=3)
            dot.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=item, font=("Segoe UI", 12),
                         text_color=GRN_DRK, anchor="w").pack(side="left")

    # ── tags ────────────────────────────────────────────────────────────
    def _tags_section(self, parent):
        tags = self.food.get("tags", [])
        if not tags:
            return
        ctk.CTkLabel(parent, text="PHÂN LOẠI",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(fill="x", padx=20, pady=(0, 8))
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(0, 12))
        for tag in tags:
            chip = ctk.CTkFrame(row, fg_color=GRN_DRK, corner_radius=14)
            chip.pack(side="left", padx=(0, 6))
            ctk.CTkLabel(chip, text=tag, font=("Segoe UI", 10, "bold"),
                         text_color=GRN_ACT, padx=10, pady=5).pack()

    # ── fuzzy explanation card ───────────────────────────────────────────
    def _fuzzy_explanation(self, parent):
        """Giải thích composite scoring 5 chiều từ fuzzy logic."""
        dist       = self.food.get("actual_route_km", self.food.get("route_km", 0))
        ideal      = self.ideal_distance
        match      = self.food.get("match", 80)
        cost_score = self.food.get("cost_score", 0)
        breakdown  = self.food.get("score_breakdown", {})

        card = ctk.CTkFrame(parent, fg_color=GRN_DRK, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=14)

        ctk.CTkLabel(inner, text="🧠 FUZZY LOGIC – COMPOSITE SCORE",
                     font=("Segoe UI", 9, "bold"), text_color=GRN_ACT,
                     anchor="w").pack(fill="x", pady=(0, 10))

        # Thanh progress cho từng chiều
        dims = [
            ("📍 Khoảng cách",  breakdown.get("distance",  0), "distance"),
            ("🍽 Loại bữa ăn",  breakdown.get("meal_fit",  0), "meal_fit"),
            ("🔥 Calo phù hợp", breakdown.get("cal_fit",   0), "cal_fit"),
            ("💪 Dinh dưỡng",   breakdown.get("nutrition", 0), "nutrition"),
            ("💰 Ngân sách",     breakdown.get("budget",    0), "budget"),
            ("💎 Phân khúc giá", breakdown.get("price_fit", 0), "price_fit"),
            ("🌤 Thời tiết",     breakdown.get("weather",   0), "weather"),
        ]
        for label, val, _ in dims:
            row = ctk.CTkFrame(inner, fg_color="transparent")
            row.pack(fill="x", pady=3)
            ctk.CTkLabel(row, text=label, font=("Segoe UI", 10),
                         text_color="#A8C8B0", width=120, anchor="w").pack(side="left")
            bar_bg = ctk.CTkFrame(row, fg_color="#152E1E", height=8, corner_radius=4)
            bar_bg.pack(side="left", fill="x", expand=True, padx=(6, 8))
            # val = 0 tốt, 1 xấu → fill = 1-val
            fill_w = max(0.0, min(1.0, 1.0 - float(val)))
            color = GRN_ACT if fill_w > 0.6 else ("#F4A261" if fill_w > 0.3 else "#E53E3E")
            ctk.CTkFrame(bar_bg, fg_color=color, height=8, corner_radius=4
                         ).place(relx=0, rely=0, relwidth=fill_w, relheight=1)
            grade = "✓ Tốt" if fill_w > 0.6 else ("⚡ Vừa" if fill_w > 0.3 else "△ Kém")
            ctk.CTkLabel(row, text=grade, font=("Segoe UI", 9, "bold"),
                         text_color=color, width=42).pack(side="left")

        # Summary
        ctk.CTkFrame(inner, fg_color="#2E5240", height=1, corner_radius=0
                     ).pack(fill="x", pady=(8, 6))
        summary_row = ctk.CTkFrame(inner, fg_color="transparent")
        summary_row.pack(fill="x")
        note = f"✓ Trong tầm lý tưởng" if dist <= ideal else f"△ Cách {dist:.1f}km (lý tưởng {ideal:.1f}km)"
        ctk.CTkLabel(summary_row, text=note,
                     font=("Segoe UI", 10, "bold"), text_color=GRN_ACT).pack(side="left")
        ctk.CTkLabel(summary_row, text=f"{match}% match",
                     font=("Segoe UI", 11, "bold"), text_color=WHITE).pack(side="right")

    # ── map button ──────────────────────────────────────────────────────
    def _map_button(self, parent):
        dist = self.food.get("actual_route_km", 0)
        ctk.CTkButton(
            parent, text=f"🗺  Xem tuyến đường  ({dist:.1f} km)",
            font=("Segoe UI", 14, "bold"), height=52, corner_radius=26,
            fg_color=GRN_DRK, hover_color=GRN_MID, text_color=WHITE,
            command=self._open_map,
        ).pack(fill="x", padx=16, pady=(4, 0))

    # ── draw icon ───────────────────────────────────────────────────────
    def _draw_icon(self, c, size):
        try:
            if not c.winfo_ismapped(): return
        except Exception: return
        c.delete("all")
        cols = self.food.get("dot_colors", ["#E53E3E", "#4CAF85"])
        cx, cy = size / 2, size / 2
        r = size / 2 - 2
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill="#F5C842", outline="")
        c.create_oval(cx-r*.60, cy-r*.20, cx+r*.10, cy+r*.80,
                      fill=cols[0], outline="")
        c.create_oval(cx-r*.05, cy-r*.55, cx+r*.55, cy+r*.55,
                      fill=cols[1] if len(cols) > 1 else GRN_MID, outline="")

    # ── map ─────────────────────────────────────────────────────────────
    def _open_map(self):
        from tabs.map_screen import MapScreen
        self.pack_forget()
        _ref = [None]

        def on_map_close():
            if _ref[0]:
                _ref[0].destroy()
                _ref[0] = None
            self.pack(fill="both", expand=True)

        m = MapScreen(self.master, on_close=on_map_close,
                      results=self.all_results or [self.food],
                      focused_food=self.food)
        _ref[0] = m
        m.pack(fill="both", expand=True)
