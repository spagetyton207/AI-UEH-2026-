"""
Tab 1: Trang chủ
FIX PERFORMANCE:
- Dùng _draw_pending flag thay retry after() loop → tránh hàng nghìn callback tích lũy
- Hủy tất cả pending after() khi tab bị ẩn qua pack_forget()
- _draw_food_icon không retry nữa, dựa vào Configure event
"""
import customtkinter as ctk
import tkinter as tk
from utils.theme import COLORS, FONTS, SIZES

HERO_H    = 240
BG        = "#F5F0E8"
C1        = "#B8E0C8"
C2        = "#D4EDE0"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_LBL   = "#4A7A5A"
GRN_ACT   = "#6FCF97"
GRN_CARD  = "#9BBFAA"


class RecommendTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=BG)
        self._after_ids = []
        self._hero_draw_pending = False
        self._create_ui()

    def _track_after(self, delay, func):
        """Tạo after() và lưu ID để cancel được."""
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def _cancel_all_after(self):
        for aid in self._after_ids:
            try:
                self.after_cancel(aid)
            except Exception:
                pass
        self._after_ids.clear()
        self._hero_draw_pending = False

    def pack_forget(self):
        """Hủy tất cả callbacks khi tab bị ẩn."""
        self._cancel_all_after()
        super().pack_forget()

    # ─────────────────────────────────────────────
    def _create_ui(self):
        self._build_hero_canvas()
        self.scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent",
            scrollbar_button_color="#D6CFBE",
            scrollbar_button_hover_color="#B8B0A0",
        )
        self.scroll.pack(fill="both", expand=True)
        self._build_suggestion_card()
        self._build_main_button()
        self._build_category_section()
        ctk.CTkFrame(self.scroll, fg_color="transparent", height=20).pack()

    def _build_hero_canvas(self):
        self.cv = tk.Canvas(self, height=HERO_H, bg=BG, highlightthickness=0, bd=0)
        self.cv.pack(fill="x")
        self._btn_loc = ctk.CTkButton(
            self.cv, text="📍", font=("Segoe UI Emoji", 16),
            width=38, height=38, corner_radius=0,
            fg_color="#D4EDE0", hover_color="#D4EDE0",
            text_color=GRN_DRK, command=self._noop,
        )
        self._btn_bell = ctk.CTkButton(
            self.cv, text="🔔", font=("Segoe UI Emoji", 16),
            width=38, height=38, corner_radius=0,
            fg_color="#D4EDE0", hover_color="#D4EDE0",
            text_color=GRN_DRK, command=self._noop,
        )
        self.cv.bind("<Configure>", self._on_hero_configure)

    def _on_hero_configure(self, event=None):
        """Debounce: chỉ schedule 1 lần draw duy nhất."""
        if self._hero_draw_pending:
            return
        self._hero_draw_pending = True
        self._track_after(16, self._redraw_hero)

    def _redraw_hero(self):
        self._hero_draw_pending = False
        c = self.cv
        try:
            if not c.winfo_ismapped():
                return
        except Exception:
            return
        c.delete("all")
        w = c.winfo_width()
        h = HERO_H
        if w < 10:
            return  # Không retry loop - Configure sẽ fire khi widget sẵn sàng

        r1 = w * 0.65
        cx1, cy1 = w * 0.16, -h * 0.08
        c.create_oval(cx1-r1, cy1-r1, cx1+r1, cy1+r1, fill=C1, outline="")
        r2 = w * 0.50
        cx2, cy2 = w * 0.90, h * 0.14
        c.create_oval(cx2-r2, cy2-r2, cx2+r2, cy2+r2, fill=C2, outline="")
        c.create_text(18, 22, text="📍 TP. Hồ Chí Minh",
                      font=("Segoe UI", 12, "bold"), fill=GRN_DRK, anchor="w")
        c.create_text(18, 42, text="☀️  32°C · Nắng nóng",
                      font=("Segoe UI", 10), fill=GRN_LBL, anchor="w")
        c.create_window(w - 14, 28, window=self._btn_bell, anchor="e")
        c.create_window(w - 58, 28, window=self._btn_loc,  anchor="e")
        c.create_text(w * 0.50, h * 0.38, text="Hôm nay ăn gì nhỉ?",
                      font=("Georgia", 23, "bold"),
                      fill=GRN_DRK, justify="center", anchor="center")
        c.create_text(w * 0.50, h * 0.62,
                      text="Để AI gợi ý món ngon phù hợp nhất cho bạn ✨",
                      font=("Segoe UI", 11), fill=GRN_LBL,
                      justify="center", width=w * 0.78, anchor="center")

    # ─────────────────────────────────────────────
    def _build_suggestion_card(self):
        outer = ctk.CTkFrame(self.scroll, fg_color="transparent")
        outer.pack(fill="x", padx=16, pady=(14, 12))
        card = ctk.CTkFrame(outer, fg_color=GRN_DRK, corner_radius=20, height=130)
        card.pack(fill="x")
        card.pack_propagate(False)
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=14, pady=12)

        # ── Icon: tô bún chả vẽ trên Canvas ─────────────────────────────
        # Dùng tk.Canvas đặt thẳng vào inner (không bọc thêm CTkFrame)
        # để tránh vấn đề corner_radius che mất nội dung.
        ICON_SIZE = 96
        self._food_canvas = tk.Canvas(
            inner, width=ICON_SIZE, height=ICON_SIZE,
            bg=GRN_DRK, highlightthickness=0, bd=0,
        )
        self._food_canvas.pack(side="left", padx=(0, 12))
        # Vẽ ngay (canvas có size cố định nên không cần đợi Configure)
        self._draw_bunchả_icon(self._food_canvas, ICON_SIZE)

        col = ctk.CTkFrame(inner, fg_color="transparent")
        col.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(col, text="✦  MÓN HÔM NAY NÊN THỬ",
                     font=("Segoe UI", 8, "bold"), text_color=GRN_ACT, anchor="w").pack(fill="x")
        ctk.CTkLabel(col, text="Bún chả Hà Nội", font=("Georgia", 16, "bold"),
                     text_color="white", anchor="w", wraplength=200, justify="left").pack(fill="x")
        ctk.CTkLabel(col, text="Bún chả 36", font=("Segoe UI", 12),
                     text_color=GRN_CARD, anchor="w", wraplength=200, justify="left").pack(fill="x")
        ctk.CTkLabel(col, text="🇻🇳  ·  90.000đ  ·  20 phút",
                     font=("Segoe UI", 10), text_color=GRN_CARD, anchor="w").pack(fill="x", pady=(2, 0))

    def _draw_bunchả_icon(self, c, size):
        """Vẽ icon tô bún chả: bát tròn + bún trắng + chả nướng + rau xanh."""
        cx, cy = size / 2, size / 2

        # Bóng dưới bát
        c.create_oval(cx-38, cy+24, cx+38, cy+34, fill="#0F2A1C", outline="")

        # Vành ngoài bát (gốm trắng kem)
        c.create_oval(cx-42, cy-22, cx+42, cy+30,
                      fill="#F5E9D7", outline="#C9B89A", width=2)

        # Phần lòng bát đậm hơn (đáy bát)
        c.create_oval(cx-36, cy-16, cx+36, cy+26,
                      fill="#E8D4B0", outline="")

        # Nước dùng (nâu nhạt)
        c.create_oval(cx-34, cy-14, cx+34, cy+22,
                      fill="#D9A86B", outline="")

        # Sợi bún trắng - vẽ vài đường ovan trắng
        for dx, dy in [(-18, -2), (-6, -6), (8, -3), (16, -7), (-12, 4)]:
            c.create_oval(cx+dx-10, cy+dy-3, cx+dx+10, cy+dy+3,
                          fill="#FAF6EE", outline="")

        # Miếng chả nướng (3 viên cháy xém)
        c.create_oval(cx-22, cy+2,  cx-8,  cy+14, fill="#7A3A18", outline="#4A1F08", width=1)
        c.create_oval(cx-6,  cy+5,  cx+8,  cy+17, fill="#8A4520", outline="#4A1F08", width=1)
        c.create_oval(cx+10, cy+1,  cx+24, cy+13, fill="#7A3A18", outline="#4A1F08", width=1)
        # Highlight cháy xém
        c.create_oval(cx-19, cy+4,  cx-13, cy+8,  fill="#A85A2E", outline="")
        c.create_oval(cx+13, cy+3,  cx+19, cy+7,  fill="#A85A2E", outline="")

        # Vài cọng rau thơm xanh
        c.create_oval(cx-26, cy-10, cx-20, cy-4,  fill="#3F8A4B", outline="")
        c.create_oval(cx+20, cy-12, cx+26, cy-6,  fill="#3F8A4B", outline="")
        c.create_oval(cx-2,  cy-14, cx+4,  cy-8,  fill="#4FA85B", outline="")

        # Ớt đỏ
        c.create_oval(cx+6,  cy-4,  cx+12, cy+0,  fill="#E53E3E", outline="")

        # Highlight bóng trên vành bát
        c.create_arc(cx-40, cy-20, cx+40, cy+0,
                     start=20, extent=140, style="arc",
                     outline="#FFFFFF", width=2)

    def _build_main_button(self):
        ctk.CTkButton(
            self.scroll, text="✦   Gợi ý ngay",
            font=("Segoe UI", 16, "bold"), height=56, corner_radius=28,
            fg_color=GRN_MID, hover_color="#1A5C38",
            text_color="white", command=self.on_suggest,
        ).pack(fill="x", padx=16, pady=(0, 18))

    def _build_category_section(self):
        hdr = ctk.CTkFrame(self.scroll, fg_color="transparent")
        hdr.pack(fill="x", padx=18, pady=(0, 8))
        ctk.CTkLabel(hdr, text="HOẶC DUYỆT THEO LOẠI",
                     font=("Segoe UI", 10, "bold"), text_color="#8A9E8A", anchor="w").pack(side="left")
        ctk.CTkButton(hdr, text="Tất cả  >", font=("Segoe UI", 11, "bold"), text_color=GRN_MID,
                      fg_color="transparent", hover_color="#EAF3EA",
                      width=70, height=28, corner_radius=14, command=self._open_menu_tab).pack(side="right")

        # Đếm món thực tế trong food.csv để hiển thị
        counts = self._count_by_cuisine()
        cats = [
            ("🇻🇳", "Việt Nam",   counts.get("vie", 0), "#FFEEDD"),
            ("🇰🇷", "Hàn Quốc",   counts.get("kor", 0), "#FFE8F0"),
            ("🇯🇵", "Nhật Bản",   counts.get("jpn", 0), "#FFF0F0"),
            ("🍔", "Phương Tây", counts.get("us",  0), "#FFF8E6"),
        ]
        grid = ctk.CTkFrame(self.scroll, fg_color="transparent")
        grid.pack(fill="x", padx=14)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        for i, (emoji, name, count, bg) in enumerate(cats):
            self._make_cat_card(grid, emoji, name, f"{count} món", bg, i//2, i%2)

    def _count_by_cuisine(self):
        """Đếm số món mỗi cuisine từ food.csv (lazy load)."""
        try:
            from backend.main import FOOD_DF
            return FOOD_DF['cuisine'].value_counts().to_dict()
        except Exception:
            return {}

    def _open_menu_tab(self):
        """Chuyển sang tab Khám phá món ăn."""
        app = self._get_app()
        if app is None:
            return
        try:
            app.show_tab("menu")
        except Exception as e:
            print(f"[Open menu] {e}")

    def _make_cat_card(self, parent, emoji, name, count, bg, row, col):
        card = ctk.CTkFrame(parent, fg_color="white", corner_radius=18, cursor="hand2")
        card.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
        card.bind("<Button-1>", lambda e: self._open_menu_tab())
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(padx=16, pady=12)
        inner.bind("<Button-1>", lambda e: self._open_menu_tab())
        ebox = ctk.CTkFrame(inner, fg_color=bg, width=54, height=54, corner_radius=14)
        ebox.pack()
        ebox.pack_propagate(False)
        ctk.CTkLabel(ebox, text=emoji, font=("Segoe UI Emoji", 26)).place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(inner, text=name, font=("Segoe UI", 13, "bold"), text_color="#1A2A1A").pack(pady=(7, 0))
        ctk.CTkLabel(inner, text=count, font=("Segoe UI", 11), text_color="#8A9E8A").pack()

    def _noop(self):
        pass

    def on_suggest(self):
        from tabs.suggest_wizard import SuggestWizard
        app = self._get_app()
        if app is None:
            return
        self._cancel_all_after()
        app.bottom_nav.pack_forget()
        self.pack_forget()

        def on_done():
            wizard.destroy()
            app.bottom_nav.pack(fill="x", side="bottom")
            self.pack(fill="both", expand=True)
            self._track_after(50, lambda: self.cv.event_generate("<Configure>"))

        wizard = SuggestWizard(app.content_frame, on_done=on_done)
        wizard.pack(fill="both", expand=True)

    def _get_app(self):
        w = self
        for _ in range(20):
            w = w.master
            if w is None:
                return None
            if hasattr(w, "bottom_nav"):
                return w
        return None
