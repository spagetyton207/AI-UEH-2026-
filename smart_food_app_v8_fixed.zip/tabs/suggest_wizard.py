"""
Suggest Wizard - 2 bước nhập thông tin gợi ý món ăn
Tích hợp backend: fuzzy engine + food.csv + OSRM routing
"""
import customtkinter as ctk
import tkinter as tk
import threading

BG        = "#F5F0E8"
GRN_DRK   = "#1A3A2A"
GRN_MID   = "#2E8B57"
GRN_LBL   = "#4A7A5A"
GRN_ACT   = "#6FCF97"
GRN_LIGHT = "#E8F4EE"
WHITE     = "#FFFFFF"
ORANGE    = "#F4845F"
ORANGE_LT = "#FEE9E2"


class SuggestWizard(ctk.CTkFrame):
    def __init__(self, parent, on_done):
        super().__init__(parent, fg_color=BG, corner_radius=0)
        self.on_done = on_done
        self.step = 1
        self._after_ids = []
        self._pending_draws = set()

        self.budget_val  = tk.DoubleVar(value=0.24)
        self.hunger_val  = tk.DoubleVar(value=0.74)
        self.goal_var    = tk.StringVar(value="Cân bằng")
        self.wait_val    = tk.DoubleVar(value=0.26)

        # Cache thời tiết hiển thị (sẽ cập nhật khi gợi ý)
        self._weather_text = tk.StringVar(value="☀️  Đang tải...")

        self._build_ui()
        # Load thời tiết nền
        threading.Thread(target=self._fetch_weather_preview, daemon=True).start()

    def _fetch_weather_preview(self):
        try:
            from backend.utils import get_weather_data
            w = get_weather_data("Ho Chi Minh")
            temp = w.get('temperature', 32)
            rain = w.get('rainfall', 0)
            if rain > 5:
                icon = "🌧"
                desc = f"Mưa · {temp:.0f}°C"
            elif temp > 35:
                icon = "☀️"
                desc = f"Nắng nóng · {temp:.0f}°C"
            elif temp < 22:
                icon = "❄"
                desc = f"Mát · {temp:.0f}°C"
            else:
                icon = "⛅"
                desc = f"Bình thường · {temp:.0f}°C"
            self._weather_text.set(f"{icon}  {desc}")
        except Exception:
            self._weather_text.set("☀️  TP.HCM")

    def _track_after(self, delay, func):
        aid = self.after(delay, func)
        self._after_ids.append(aid)
        return aid

    def _cancel_all_after(self):
        for aid in self._after_ids:
            try:
                self.after_cancel(aid)
            except Exception:
                pass
        self._after_ids.clear()
        self._pending_draws.clear()

    def destroy(self):
        self._cancel_all_after()
        super().destroy()

    # ─────────────────────────────────────────────
    def _build_ui(self):
        self.page1 = self._make_page1()
        self.page2 = self._make_page2()
        self._show_step(1)

    def _show_step(self, step):
        self._cancel_all_after()
        self.step = step
        if step == 1:
            self.page2.pack_forget()
            self.page1.pack(fill="both", expand=True)
        else:
            self.page1.pack_forget()
            self.page2.pack(fill="both", expand=True)
            self._refresh_tags()

    # ─────────────────────────────────────────────
    #  PAGE 1
    # ─────────────────────────────────────────────
    def _make_page1(self):
        page = ctk.CTkScrollableFrame(self, fg_color=BG,
                                      scrollbar_button_color="#D6CFBE",
                                      scrollbar_button_hover_color="#B8B0A0")
        self._topbar(page, step=1)
        title_f = ctk.CTkFrame(page, fg_color="transparent")
        title_f.pack(fill="x", padx=20, pady=(10, 18))
        ctk.CTkLabel(title_f, text="Bạn đang ", font=("Georgia", 22, "bold"),
                     text_color=GRN_DRK).pack(side="left")
        ctk.CTkLabel(title_f, text="thế nào?", font=("Georgia", 22, "italic"),
                     text_color=GRN_MID).pack(side="left")
        ctk.CTkLabel(page, text="Kéo các thanh để mô tả tình trạng hiện tại.",
                     font=("Segoe UI", 11), text_color=GRN_LBL, anchor="w"
                     ).pack(fill="x", padx=22, pady=(0, 18))
        self._budget_card(page)
        self._hunger_card(page)
        ctk.CTkFrame(page, fg_color="transparent", height=30).pack()
        self._bottom_buttons(page,
                             left_text="Quay lại", left_cmd=self.on_done,
                             right_text="Tiếp theo →", right_cmd=lambda: self._show_step(2))
        return page

    def _budget_card(self, parent):
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=16, pady=(14, 4))
        icon_bg = ctk.CTkFrame(hdr, fg_color=GRN_LIGHT, width=32, height=32, corner_radius=8)
        icon_bg.pack(side="left")
        icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg, text="💰", font=("Segoe UI Emoji", 14)
                     ).place(relx=0.5, rely=0.5, anchor="center")
        info = ctk.CTkFrame(hdr, fg_color="transparent")
        info.pack(side="left", padx=10)
        ctk.CTkLabel(info, text="NGÂN SÁCH", font=("Segoe UI", 9, "bold"),
                     text_color="#8A9E8A").pack(anchor="w")
        self.budget_label = ctk.CTkLabel(info, text="120,000đ",
                                          font=("Segoe UI", 16, "bold"), text_color=GRN_DRK)
        self.budget_label.pack(anchor="w")
        self.budget_badge = ctk.CTkLabel(hdr, text="Trung bình",
                                          font=("Segoe UI", 11, "bold"),
                                          fg_color=GRN_LIGHT, corner_radius=12,
                                          text_color=GRN_MID, padx=10, pady=4)
        self.budget_badge.pack(side="right")
        slider_frame = ctk.CTkFrame(card, fg_color="transparent")
        slider_frame.pack(fill="x", padx=16, pady=(4, 8))
        self._draw_custom_slider(slider_frame, self.budget_val,
                                 track_color=GRN_MID, thumb_color=GRN_MID,
                                 on_change=self._on_budget_change)
        ticks = ctk.CTkFrame(card, fg_color="transparent")
        ticks.pack(fill="x", padx=14, pady=(0, 14))
        for t in ["0đ", "tiết kiệm", "vừa", "cao cấp", "500k"]:
            ctk.CTkLabel(ticks, text=t, font=("Segoe UI", 9),
                         text_color="#AAAAAA").pack(side="left", expand=True)

    def _on_budget_change(self, val):
        amount = int(val * 500000)
        self.budget_label.configure(text=f"{amount:,}đ")
        if val < 0.2:
            badge, color = "Tiết kiệm", "#F4A261"
        elif val < 0.5:
            badge, color = "Trung bình", GRN_MID
        else:
            badge, color = "Cao cấp", GRN_DRK
        self.budget_badge.configure(text=badge, text_color=color)

    def _hunger_card(self, parent):
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=16, pady=(14, 4))
        icon_bg = ctk.CTkFrame(hdr, fg_color=ORANGE_LT, width=32, height=32, corner_radius=8)
        icon_bg.pack(side="left")
        icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg, text="🔥", font=("Segoe UI Emoji", 14)
                     ).place(relx=0.5, rely=0.5, anchor="center")
        info = ctk.CTkFrame(hdr, fg_color="transparent")
        info.pack(side="left", padx=10)
        ctk.CTkLabel(info, text="ĐỘ ĐÓI", font=("Segoe UI", 9, "bold"),
                     text_color="#8A9E8A").pack(anchor="w")
        self.hunger_label = ctk.CTkLabel(info, text="Rất đói · 7.4/10",
                                          font=("Segoe UI", 16, "bold"), text_color=GRN_DRK)
        self.hunger_label.pack(anchor="w")
        self.hunger_badge = ctk.CTkLabel(hdr, text="Cao",
                                          font=("Segoe UI", 11, "bold"),
                                          fg_color=ORANGE_LT, corner_radius=12,
                                          text_color=ORANGE, padx=10, pady=4)
        self.hunger_badge.pack(side="right")
        slider_frame = ctk.CTkFrame(card, fg_color="transparent")
        slider_frame.pack(fill="x", padx=16, pady=(4, 8))
        self._draw_custom_slider(slider_frame, self.hunger_val,
                                 track_color=ORANGE, thumb_color=ORANGE,
                                 on_change=self._on_hunger_change)
        ticks = ctk.CTkFrame(card, fg_color="transparent")
        ticks.pack(fill="x", padx=14, pady=(0, 14))
        for t in ["Nhẹ", "Đói", "Rất đói", "Cực đói"]:
            ctk.CTkLabel(ticks, text=t, font=("Segoe UI", 9),
                         text_color="#AAAAAA").pack(side="left", expand=True)

    def _on_hunger_change(self, val):
        score = val * 10
        if val < 0.25:
            name, badge, bcolor = "Nhẹ", "Thấp", GRN_MID
        elif val < 0.5:
            name, badge, bcolor = "Đói", "Vừa", "#F4A261"
        elif val < 0.75:
            name, badge, bcolor = "Rất đói", "Cao", ORANGE
        else:
            name, badge, bcolor = "Cực đói", "Rất cao", "#E53E1A"
        self.hunger_label.configure(text=f"{name} · {score:.1f}/10")
        self.hunger_badge.configure(text=badge, text_color=bcolor)

    # ─────────────────────────────────────────────
    #  PAGE 2
    # ─────────────────────────────────────────────
    def _make_page2(self):
        page = ctk.CTkScrollableFrame(self, fg_color=BG,
                                      scrollbar_button_color="#D6CFBE",
                                      scrollbar_button_hover_color="#B8B0A0")
        self._topbar(page, step=2)
        title_f = ctk.CTkFrame(page, fg_color="transparent")
        title_f.pack(fill="x", padx=20, pady=(10, 6))
        ctk.CTkLabel(title_f, text="Sức khoẻ & ", font=("Georgia", 22, "bold"),
                     text_color=GRN_DRK).pack(side="left")
        ctk.CTkLabel(title_f, text="thời gian", font=("Georgia", 22, "italic"),
                     text_color=GRN_MID).pack(side="left")
        ctk.CTkLabel(page, text="Chế độ sẽ ưu tiên macro & calo phù hợp.",
                     font=("Segoe UI", 11), text_color=GRN_LBL, anchor="w"
                     ).pack(fill="x", padx=22, pady=(0, 16))
        self._goal_card(page)
        self._wait_card(page)
        self.tags_frame = ctk.CTkFrame(page, fg_color="transparent")
        self.tags_frame.pack(fill="x", padx=16, pady=(8, 0))
        ctk.CTkFrame(page, fg_color="transparent", height=30).pack()
        self._final_button(page)
        ctk.CTkFrame(page, fg_color="transparent", height=20).pack()
        return page

    def _goal_card(self, parent):
        section = ctk.CTkFrame(parent, fg_color="transparent")
        section.pack(fill="x", padx=16, pady=(0, 12))
        ctk.CTkLabel(section, text="MỤC TIÊU SỨC KHOẺ",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A",
                     anchor="w").pack(fill="x", pady=(0, 8))
        goals_row = ctk.CTkFrame(section, fg_color="transparent")
        goals_row.pack(fill="x")
        goals_row.columnconfigure(0, weight=1)
        goals_row.columnconfigure(1, weight=1)
        goals_row.columnconfigure(2, weight=1)
        goals = [
            ("🌿", "Diet",     "Ít calo, thanh\nđạm"),
            ("🤍", "Cân bằng", "Đa dạng, vừa\nđủ"),
            ("🔥", "Bulking",  "Nhiều đạm +\ncalo"),
        ]
        self.goal_btns = {}
        for col, (icon, name, desc) in enumerate(goals):
            self.goal_btns[name] = self._make_goal_btn(goals_row, icon, name, desc, col)
        self._update_goal_buttons()

    def _make_goal_btn(self, parent, icon, name, desc, col):
        btn = ctk.CTkFrame(parent, corner_radius=16, cursor="hand2")
        btn.grid(row=0, column=col, sticky="nsew", padx=4)
        icon_lbl = ctk.CTkLabel(btn, text=icon, font=("Segoe UI Emoji", 22))
        icon_lbl.pack(pady=(14, 2))
        name_lbl = ctk.CTkLabel(btn, text=name, font=("Segoe UI", 13, "bold"))
        name_lbl.pack()
        desc_lbl = ctk.CTkLabel(btn, text=desc, font=("Segoe UI", 10),
                                 wraplength=90, justify="center")
        desc_lbl.pack(pady=(2, 14))
        for w in [btn, icon_lbl, name_lbl, desc_lbl]:
            w.bind("<Button-1>", lambda e, n=name: self._select_goal(n))
        return {"frame": btn, "icon": icon_lbl, "name": name_lbl, "desc": desc_lbl}

    def _select_goal(self, name):
        self.goal_var.set(name)
        self._update_goal_buttons()
        self._refresh_tags()

    def _update_goal_buttons(self):
        active = self.goal_var.get()
        for name, widgets in self.goal_btns.items():
            if name == active:
                widgets["frame"].configure(fg_color=GRN_DRK)
                widgets["icon"].configure(text_color="white", fg_color="transparent")
                widgets["name"].configure(text_color="white", fg_color="transparent")
                widgets["desc"].configure(text_color=GRN_ACT, fg_color="transparent")
            else:
                widgets["frame"].configure(fg_color=WHITE)
                widgets["icon"].configure(text_color=GRN_DRK, fg_color="transparent")
                widgets["name"].configure(text_color=GRN_DRK, fg_color="transparent")
                widgets["desc"].configure(text_color="#8A9E8A", fg_color="transparent")

    def _wait_card(self, parent):
        card = ctk.CTkFrame(parent, fg_color=WHITE, corner_radius=18)
        card.pack(fill="x", padx=16, pady=(0, 12))
        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=16, pady=(14, 4))
        icon_bg = ctk.CTkFrame(hdr, fg_color=GRN_LIGHT, width=32, height=32, corner_radius=8)
        icon_bg.pack(side="left")
        icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg, text="⏱", font=("Segoe UI Emoji", 14)
                     ).place(relx=0.5, rely=0.5, anchor="center")
        info = ctk.CTkFrame(hdr, fg_color="transparent")
        info.pack(side="left", padx=10)
        ctk.CTkLabel(info, text="THỜI GIAN CHỜ TỐI ĐA",
                     font=("Segoe UI", 9, "bold"), text_color="#8A9E8A").pack(anchor="w")
        self.wait_label = ctk.CTkLabel(info, text="25 phút",
                                        font=("Segoe UI", 16, "bold"), text_color=GRN_DRK)
        self.wait_label.pack(anchor="w")
        self.wait_badge = ctk.CTkLabel(hdr, text="Trung bình",
                                        font=("Segoe UI", 11, "bold"),
                                        fg_color=GRN_LIGHT, corner_radius=12,
                                        text_color=GRN_MID, padx=10, pady=4)
        self.wait_badge.pack(side="right")
        slider_frame = ctk.CTkFrame(card, fg_color="transparent")
        slider_frame.pack(fill="x", padx=16, pady=(4, 8))
        self._draw_custom_slider(slider_frame, self.wait_val,
                                 track_color=GRN_MID, thumb_color=GRN_MID,
                                 on_change=self._on_wait_change)
        ticks = ctk.CTkFrame(card, fg_color="transparent")
        ticks.pack(fill="x", padx=14, pady=(0, 14))
        for t in ["5'", "15'", "30'", "60'", "90'"]:
            ctk.CTkLabel(ticks, text=t, font=("Segoe UI", 9),
                         text_color="#AAAAAA").pack(side="left", expand=True)

    def _on_wait_change(self, val):
        minutes = int(5 + val * 85)
        self.wait_label.configure(text=f"{minutes} phút")
        if minutes <= 15:
            badge, color = "Nhanh", GRN_MID
        elif minutes <= 35:
            badge, color = "Trung bình", GRN_MID
        else:
            badge, color = "Chậm", "#F4A261"
        self.wait_badge.configure(text=badge, text_color=color)
        self._refresh_tags()

    def _refresh_tags(self):
        for w in self.tags_frame.winfo_children():
            w.destroy()
        budget_amount = int(self.budget_val.get() * 500000)
        hunger_score  = self.hunger_val.get() * 10
        wait_minutes  = int(5 + self.wait_val.get() * 85)
        goal          = self.goal_var.get()
        if hunger_score < 2.5:
            hunger_text = "Nhẹ"
        elif hunger_score < 5:
            hunger_text = "Đói"
        elif hunger_score < 7.5:
            hunger_text = "Rất đói"
        else:
            hunger_text = "Cực đói"
        weather_str = self._weather_text.get()
        tags = [
            ("🌍", weather_str.split("  ", 1)[-1] if "  " in weather_str else "TP.HCM"),
            ("💰", f"{budget_amount:,}đ"),
            ("🔥", hunger_text),
            ("🎯", goal),
            ("⏱", f"{wait_minutes}'"),
        ]
        row = ctk.CTkFrame(self.tags_frame, fg_color="transparent")
        row.pack(fill="x")
        for icon, label in tags:
            chip = ctk.CTkFrame(row, fg_color=GRN_LIGHT, corner_radius=14)
            chip.pack(side="left", padx=3, pady=3)
            ctk.CTkLabel(chip, text=f"{icon} {label}", font=("Segoe UI", 11),
                         text_color=GRN_DRK, padx=10, pady=5).pack()

    def _final_button(self, parent):
        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(8, 0))
        ctk.CTkButton(
            btn_frame, text="Quay lại",
            font=("Segoe UI", 14, "bold"), height=52, corner_radius=26,
            fg_color=WHITE, hover_color="#F0F0F0",
            border_width=1, border_color="#DDDDDD", text_color=GRN_DRK,
            command=lambda: self._show_step(1), width=110,
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            btn_frame, text="✦  Gợi ý ngay",
            font=("Segoe UI", 15, "bold"), height=52, corner_radius=26,
            fg_color=GRN_DRK, hover_color="#2E8B57", text_color="white",
            command=self._show_result,
        ).pack(side="left", fill="x", expand=True)

    def _show_result(self):
        from tabs.loading_screen import LoadingScreen
        from tabs.result_screen  import ResultScreen
        import threading

        self._cancel_all_after()
        self.pack_forget()

        wizard_data = {
            "budget":  int(self.budget_val.get() * 500000),
            "hunger":  self.hunger_val.get() * 10,
            "goal":    self.goal_var.get(),
            "wait":    int(5 + self.wait_val.get() * 85),
        }

        _on_done     = self.on_done
        _result_ref  = [None]
        _backend_result = [None]   # container chia sẻ giữa thread và callback
        _loading_done   = [False]
        _backend_done   = [False]

        def _try_show_result():
            """Chỉ mở ResultScreen khi CẢ HAI LoadingScreen và backend đều xong."""
            if not (_loading_done[0] and _backend_done[0]):
                return
            # Đảm bảo chạy trong main thread
            try:
                loader.destroy()
            except Exception:
                pass
            r = ResultScreen(
                self.master,
                on_back=on_back_from_result,
                on_home=on_home_from_result,
                wizard_data=wizard_data,
                backend_result=_backend_result[0],
            )
            _result_ref[0] = r
            r.pack(fill="both", expand=True)

        def on_loading_done():
            """LoadingScreen animation xong (3 giây)."""
            _loading_done[0] = True
            if not _backend_done[0]:
                # Backend chưa xong → đợi thêm, poll mỗi 200ms tối đa 10s
                _poll_backend(0)
            else:
                _try_show_result()

        def _poll_backend(attempt: int):
            """Poll cho đến khi backend xong, tối đa 50 lần × 200ms = 10s."""
            if _backend_done[0]:
                _try_show_result()
                return
            if attempt >= 50:
                # Timeout cứng: force hiện kết quả dù có lỗi
                _backend_done[0] = True
                if _backend_result[0] is None:
                    _backend_result[0] = {
                        'results': [], 'weather': {'temperature': 33, 'rainfall': 0},
                        'weather_severity': 4.0, 'ideal_distance': 2.0,
                        'fuzzy_outputs': {'meal_score': 6.0, 'cal_score': 5.0,
                                          'expected_meal_size': 'full_meal',
                                          'expected_cal': 'medium'},
                    }
                _try_show_result()
                return
            try:
                self.master.after(200, lambda: _poll_backend(attempt + 1))
            except Exception:
                pass

        def _run_backend():
            """Chạy backend trong thread riêng song song với LoadingScreen."""
            try:
                from backend.main import get_recommendation
                from backend.utils import get_user_location
                lat, lon = get_user_location()
                result = get_recommendation(
                    user_lat=lat, user_lon=lon,
                    user_time=float(wizard_data["wait"]),
                    user_hunger=float(wizard_data["hunger"]),
                    user_budget_vnd=float(wizard_data["budget"]),
                    user_health_str=wizard_data["goal"],
                    city="Ho Chi Minh", top_n=40,
                )
                _backend_result[0] = result
            except Exception as e:
                print(f"[Backend Error] {e}")
                import traceback; traceback.print_exc()
                _backend_result[0] = {"results": [], "weather": {},
                                       "ideal_distance": 0.0, "fuzzy_outputs": {}}
            # callback về main thread
            self.master.after(0, _on_backend_done_main)

        def _on_backend_done_main():
            _backend_done[0] = True
            _try_show_result()

        def on_back_from_result():
            if _result_ref[0]:
                _result_ref[0].destroy(); _result_ref[0] = None
            self.pack(fill="both", expand=True)
            self._show_step(2)

        def on_home_from_result():
            if _result_ref[0]:
                _result_ref[0].destroy(); _result_ref[0] = None
            _on_done()

        # Hiện LoadingScreen và khởi động backend cùng lúc
        loader = LoadingScreen(self.master, on_done=on_loading_done)
        loader.pack(fill="both", expand=True)
        threading.Thread(target=_run_backend, daemon=True).start()

    # ─────────────────────────────────────────────
    #  SHARED HELPERS
    # ─────────────────────────────────────────────
    def _bottom_buttons(self, parent, left_text, left_cmd, right_text, right_cmd):
        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(8, 16))
        ctk.CTkButton(
            btn_frame, text=left_text, font=("Segoe UI", 14, "bold"),
            height=52, corner_radius=26, fg_color=WHITE, hover_color="#F0F0F0",
            border_width=1, border_color="#DDDDDD", text_color=GRN_DRK,
            command=left_cmd, width=110,
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            btn_frame, text=right_text, font=("Segoe UI", 14, "bold"),
            height=52, corner_radius=26, fg_color=GRN_DRK, hover_color=GRN_MID,
            text_color="white", command=right_cmd,
        ).pack(side="left", fill="x", expand=True)

    def _topbar(self, parent, step):
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(16, 0))
        back = ctk.CTkButton(
            bar, text="←", font=("Segoe UI", 16, "bold"),
            width=36, height=36, corner_radius=18,
            fg_color="#EEEEEE", hover_color="#DDDDDD", text_color=GRN_DRK,
            command=self.on_done if step == 1 else lambda: self._show_step(1),
        )
        back.pack(side="left")
        dots = ctk.CTkFrame(bar, fg_color="transparent")
        dots.pack(side="left", expand=True)
        for i in range(1, 3):
            color = GRN_DRK if i == step else "#CCCCCC"
            w = 24 if i == step else 8
            d = ctk.CTkFrame(dots, fg_color=color, width=w, height=8, corner_radius=4)
            d.pack(side="left", padx=3)
        # Thời tiết pill
        weather_lbl = ctk.CTkLabel(bar, textvariable=self._weather_text,
                                    font=("Segoe UI", 10), text_color=GRN_LBL)
        weather_lbl.pack(side="right")

    def _resolve_bg(self, widget, depth=0):
        if depth > 10:
            return BG
        try:
            color = widget.cget("fg_color")
            if isinstance(color, (list, tuple)):
                color = color[0]
            if color == "transparent" or not color:
                if widget.master is None:
                    return BG
                return self._resolve_bg(widget.master, depth + 1)
            return color
        except Exception:
            return BG

    def _draw_custom_slider(self, parent, var, track_color, thumb_color, on_change):
        h = 36
        bg_color = self._resolve_bg(parent)
        cv = tk.Canvas(parent, height=h, bg=bg_color, highlightthickness=0, bd=0)
        cv.pack(fill="x", pady=4)
        canvas_id = id(cv)

        def draw():
            self._pending_draws.discard(canvas_id)
            try:
                if not cv.winfo_ismapped():
                    return
            except Exception:
                return
            cv.delete("all")
            w = cv.winfo_width()
            if w < 10:
                return
            cy = h // 2
            r_thumb = 11
            pad = r_thumb
            track_w = w - 2 * pad
            cv.create_rectangle(pad, cy-4, w-pad, cy+4,
                                 fill="#E8E8E8", outline="", tags="track_bg")
            cur = var.get()
            fill_x = pad + cur * track_w
            if fill_x > pad:
                cv.create_rectangle(pad, cy-4, fill_x, cy+4,
                                     fill=track_color, outline="", tags="track_fill")
            cv.create_oval(fill_x - r_thumb, cy - r_thumb,
                            fill_x + r_thumb, cy + r_thumb,
                            fill="white", outline=thumb_color, width=3, tags="thumb")

        def schedule_draw(event=None):
            if canvas_id in self._pending_draws:
                return
            self._pending_draws.add(canvas_id)
            self._track_after(16, draw)

        def on_click(event):
            w = cv.winfo_width()
            pad = 11
            raw = (event.x - pad) / max(w - 2 * pad, 1)
            val = max(0.0, min(1.0, raw))
            var.set(val)
            on_change(val)
            draw()

        cv.bind("<Button-1>", on_click)
        cv.bind("<B1-Motion>", on_click)
        cv.bind("<Configure>", schedule_draw)
        self._track_after(50, draw)
