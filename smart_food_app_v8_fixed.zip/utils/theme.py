"""
Theme configuration - Định nghĩa màu sắc, font, cấu hình chung
Light mode với gradient trắng + xanh lá
"""

# Cấu hình app
APP_CONFIG = {
    "title": "Smart Food 🍽️",
    "width": 400,
    "height": 720,
}

# Bảng màu - Light mode (trắng + green gradient)
COLORS = {
    # Màu chủ đạo - xanh lá gradient
    "green_primary": "#2E8B57",      # Xanh lá đậm
    "green_secondary": "#3CB371",    # Xanh lá vừa
    "green_light": "#E8F5E9",        # Xanh lá rất nhạt (cho background)
    "green_pale": "#F1F8F4",         # Xanh lá cực nhạt
    "green_accent": "#4CAF50",       # Xanh lá nhấn
    "green_dark": "#1B5E20",         # Xanh lá rất đậm
    
    # Màu nền
    "bg_white": "#FFFFFF",
    "bg_off_white": "#FAFAFA",
    "bg_card": "#FFFFFF",
    
    # Màu chữ
    "text_dark": "#1A1A1A",
    "text_medium": "#424242",
    "text_gray": "#9E9E9E",
    "text_light": "#BDBDBD",
    
    # Màu phụ trợ
    "border": "#E0E0E0",
    "border_light": "#F0F0F0",
    "shadow": "#EEEEEE",
    
    # Màu trạng thái
    "warning": "#FFA726",
    "error": "#EF5350",
    "success": "#66BB6A",
    "info": "#42A5F5",
    
    # Gradient (dùng cho header)
    "gradient_start": "#2E8B57",
    "gradient_end": "#66BB6A",
}

# Fonts
FONTS = {
    "title_large": ("Segoe UI", 24, "bold"),
    "title": ("Segoe UI", 20, "bold"),
    "subtitle": ("Segoe UI", 16, "bold"),
    "heading": ("Segoe UI", 14, "bold"),
    "body": ("Segoe UI", 13),
    "body_bold": ("Segoe UI", 13, "bold"),
    "small": ("Segoe UI", 11),
    "small_bold": ("Segoe UI", 11, "bold"),
    "tiny": ("Segoe UI", 10),
    "nav": ("Segoe UI", 10),
    "nav_active": ("Segoe UI", 10, "bold"),
    "button": ("Segoe UI", 13, "bold"),
}

# Kích thước & spacing
SIZES = {
    "padding_xs": 4,
    "padding_sm": 8,
    "padding_md": 16,
    "padding_lg": 24,
    "radius_sm": 8,
    "radius_md": 12,
    "radius_lg": 16,
    "radius_xl": 20,
    "header_height": 100,
    "card_height": 90,
}
