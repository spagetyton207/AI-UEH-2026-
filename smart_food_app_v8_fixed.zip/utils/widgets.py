"""
Custom widgets - Các widget tái sử dụng trong app

FIX PERFORMANCE trong GradientHeader:
- Thay vì vẽ 100 rectangle mỗi lần Configure, dùng LinearGradient simulation
  với chỉ 20 bước (giảm 80% công việc vẽ)
- Dùng pending flag thay vì retry after() loop
- Tương tự cho ProfileTab.draw_header_gradient (xử lý trong profile_tab.py)
"""
import customtkinter as ctk
import tkinter as tk
from utils.theme import COLORS, FONTS, SIZES


class GradientHeader(ctk.CTkFrame):
    """Header có gradient xanh lá - tối ưu: chỉ vẽ 20 bước thay vì 100."""
    def __init__(self, parent, title, subtitle=None, **kwargs):
        super().__init__(
            parent,
            fg_color=COLORS["green_primary"],
            corner_radius=0,
            height=SIZES["header_height"],
            **kwargs
        )
        self.pack_propagate(False)
        self._title = title
        self._subtitle = subtitle
        self._draw_pending = False

        self.canvas = tk.Canvas(
            self,
            height=SIZES["header_height"],
            highlightthickness=0,
            bd=0
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_configure)
        # Vẽ lần đầu sau một tick ngắn
        self.after(10, self._do_draw)

    def _on_configure(self, event=None):
        """Debounce: chỉ schedule 1 lần draw."""
        if self._draw_pending:
            return
        self._draw_pending = True
        self.after(16, self._do_draw)

    def _do_draw(self):
        self._draw_pending = False
        self.draw_gradient(self._title, self._subtitle)

    def draw_gradient(self, title, subtitle):
        """
        Vẽ gradient với 20 bước thay vì 100 - giảm 80% canvas operations.
        Mắt người không phân biệt được sự khác nhau ở dải này.
        """
        self.canvas.delete("all")
        width = self.winfo_width()
        height = SIZES["header_height"]

        if width <= 1:
            if not self._draw_pending:
                self._draw_pending = True
                self.after(50, self._do_draw)
            return

        # 20 bước thay vì 100 - đủ mịn cho mắt người
        STEPS = 20
        for i in range(STEPS):
            ratio = i / STEPS
            r1, g1, b1 = 0x2E, 0x8B, 0x57
            r2, g2, b2 = 0x66, 0xBB, 0x6A
            r = int(r1 + (r2 - r1) * ratio)
            g = int(g1 + (g2 - g1) * ratio)
            b = int(b1 + (b2 - b1) * ratio)
            color = f"#{r:02x}{g:02x}{b:02x}"
            x1 = int(width * i / STEPS)
            x2 = int(width * (i + 1) / STEPS)
            self.canvas.create_rectangle(x1, 0, x2, height, fill=color, outline=color)

        y_offset = 35 if subtitle else 50
        self.canvas.create_text(
            20, y_offset, text=title,
            font=FONTS["title"], fill="white", anchor="w"
        )
        if subtitle:
            self.canvas.create_text(
                20, 65, text=subtitle,
                font=FONTS["small"], fill="white", anchor="w"
            )


class Card(ctk.CTkFrame):
    """Card có viền nhẹ và bóng"""
    def __init__(self, parent, **kwargs):
        super().__init__(
            parent,
            fg_color=COLORS["bg_card"],
            corner_radius=SIZES["radius_md"],
            border_width=1,
            border_color=COLORS["border_light"],
            **kwargs
        )


class FoodCard(ctk.CTkFrame):
    """Card hiển thị thông tin món ăn"""
    def __init__(self, parent, food_data, on_click=None, **kwargs):
        super().__init__(
            parent,
            fg_color=COLORS["bg_card"],
            corner_radius=SIZES["radius_md"],
            border_width=1,
            border_color=COLORS["border_light"],
            height=110,
            **kwargs
        )
        self.pack_propagate(False)
        self.food_data = food_data
        self.on_click = on_click
        self.create_content()

    def create_content(self):
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=12, pady=10)
        icon_frame = ctk.CTkFrame(
            container, fg_color=COLORS["green_light"],
            corner_radius=SIZES["radius_sm"], width=80, height=80
        )
        icon_frame.pack(side="left", padx=(0, 12))
        icon_frame.pack_propagate(False)
        icon_label = ctk.CTkLabel(
            icon_frame, text=self.food_data.get("emoji", "🍽️"),
            font=("Segoe UI Emoji", 40)
        )
        icon_label.place(relx=0.5, rely=0.5, anchor="center")
        info_frame = ctk.CTkFrame(container, fg_color="transparent")
        info_frame.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(
            info_frame, text=self.food_data.get("name", "Tên món"),
            font=FONTS["body_bold"], text_color=COLORS["text_dark"], anchor="w"
        ).pack(fill="x", anchor="w")
        ctk.CTkLabel(
            info_frame, text=f"🏷️ {self.food_data.get('cuisine', 'Việt Nam')}",
            font=FONTS["small"], text_color=COLORS["text_gray"], anchor="w"
        ).pack(fill="x", anchor="w", pady=(2, 0))
        bottom_frame = ctk.CTkFrame(info_frame, fg_color="transparent")
        bottom_frame.pack(fill="x", anchor="w", pady=(4, 0))
        ctk.CTkLabel(
            bottom_frame, text=f"💰 {self.food_data.get('price', '50.000đ')}",
            font=FONTS["small_bold"], text_color=COLORS["green_primary"], anchor="w"
        ).pack(side="left")
        ctk.CTkLabel(
            bottom_frame, text=f"🔥 {self.food_data.get('calo', '450')} cal",
            font=FONTS["small"], text_color=COLORS["warning"], anchor="w"
        ).pack(side="left", padx=(10, 0))


class PrimaryButton(ctk.CTkButton):
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent, text=text, command=command,
            fg_color=COLORS["green_primary"], hover_color=COLORS["green_dark"],
            text_color="white", font=FONTS["button"],
            corner_radius=SIZES["radius_md"], height=44, **kwargs
        )


class SecondaryButton(ctk.CTkButton):
    def __init__(self, parent, text, command=None, **kwargs):
        super().__init__(
            parent, text=text, command=command,
            fg_color=COLORS["bg_white"], hover_color=COLORS["green_light"],
            text_color=COLORS["green_primary"], font=FONTS["button"],
            corner_radius=SIZES["radius_md"], height=44,
            border_width=2, border_color=COLORS["green_primary"], **kwargs
        )


class InfoRow(ctk.CTkFrame):
    def __init__(self, parent, label, value, icon=None, **kwargs):
        super().__init__(parent, fg_color="transparent", height=40, **kwargs)
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="x", expand=True, padx=4, pady=4)
        left_frame = ctk.CTkFrame(container, fg_color="transparent")
        left_frame.pack(side="left")
        if icon:
            ctk.CTkLabel(
                left_frame, text=icon, font=("Segoe UI Emoji", 16),
                text_color=COLORS["green_primary"]
            ).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(
            left_frame, text=label, font=FONTS["body"], text_color=COLORS["text_medium"]
        ).pack(side="left")
        ctk.CTkLabel(
            container, text=value, font=FONTS["body_bold"], text_color=COLORS["text_dark"]
        ).pack(side="right")


class SectionTitle(ctk.CTkLabel):
    def __init__(self, parent, text, **kwargs):
        super().__init__(
            parent, text=text, font=FONTS["subtitle"],
            text_color=COLORS["text_dark"], anchor="w", **kwargs
        )


class LabeledSlider(ctk.CTkFrame):
    def __init__(self, parent, label, from_=0, to=10, default=5, unit="", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.unit = unit
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(
            header, text=label, font=FONTS["body_bold"], text_color=COLORS["text_dark"]
        ).pack(side="left")
        self.value_label = ctk.CTkLabel(
            header, text=f"{default}{unit}", font=FONTS["body_bold"],
            text_color=COLORS["green_primary"]
        )
        self.value_label.pack(side="right")
        self.slider = ctk.CTkSlider(
            self, from_=from_, to=to, number_of_steps=int(to - from_),
            button_color=COLORS["green_primary"], button_hover_color=COLORS["green_dark"],
            progress_color=COLORS["green_secondary"], fg_color=COLORS["green_light"],
            command=self.on_change
        )
        self.slider.set(default)
        self.slider.pack(fill="x")

    def on_change(self, value):
        self.value_label.configure(text=f"{int(value)}{self.unit}")

    def get(self):
        return self.slider.get()


class OptionSelector(ctk.CTkFrame):
    def __init__(self, parent, label, options, default=None, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.options = options
        self.selected = default if default else options[0]
        self.buttons = {}
        ctk.CTkLabel(
            self, text=label, font=FONTS["body_bold"],
            text_color=COLORS["text_dark"], anchor="w"
        ).pack(fill="x", pady=(0, 6))
        buttons_frame = ctk.CTkFrame(self, fg_color="transparent")
        buttons_frame.pack(fill="x")
        for i, option in enumerate(options):
            row = i // 2
            col = i % 2
            buttons_frame.grid_columnconfigure(col, weight=1)
            btn = ctk.CTkButton(
                buttons_frame, text=option, font=FONTS["small_bold"],
                height=36, corner_radius=SIZES["radius_sm"],
                command=lambda o=option: self.select(o)
            )
            btn.grid(row=row, column=col, sticky="ew", padx=3, pady=3)
            self.buttons[option] = btn
        self.update_styles()

    def select(self, option):
        self.selected = option
        self.update_styles()

    def update_styles(self):
        for option, btn in self.buttons.items():
            if option == self.selected:
                btn.configure(
                    fg_color=COLORS["green_primary"], hover_color=COLORS["green_dark"],
                    text_color="white", border_width=0
                )
            else:
                btn.configure(
                    fg_color=COLORS["bg_white"], hover_color=COLORS["green_light"],
                    text_color=COLORS["text_medium"], border_width=1,
                    border_color=COLORS["border"]
                )

    def get(self):
        return self.selected
